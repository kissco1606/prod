fs = require('fs');
fsExtra = require('fs-extra');
path = require('path');
c_process = require('child_process');
oracle = require('./src/oracle');
iconv = require('iconv-lite');
jschardet = require('jschardet');
JSZip = require("jszip");
JapaneseHolidays = require('japanese-holidays');
streamSaver = require('streamsaver');
require('array-foreach-async');
$(function () {
    init();
});
