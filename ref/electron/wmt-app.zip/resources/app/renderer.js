fs = require('fs');
fsExtra = require('fs-extra');
path = require('path');
c_process = require('child_process');
oracle = require('./src/oracle');
iconv = require('iconv-lite');
jschardet = require('jschardet');
JSZip = require("jszip");
JapaneseHolidays = require('japanese-holidays');
streamSaver = require('streamsaver');
require('array-foreach-async');
$(function () {
    init();
    const headerStyle = {
        fill: {
            patternType: "solid",
            fgColor:{ rgb: "9E9E9E" },
            bgColor:{ rgb: "9E9E9E" }
        }
    };
    const setStyle = function(R, C, cell) {
        if(R === 0) cell.s = headerStyle;
    };
    const wb = new Workbook();
    const sn = "test";
    const fileType = TYPES.file.mime.OCTET_STREAM;
    const convertedData = [[1,2,3,4],["a", "b", "c"]];
    const ws = sheetFromArrayOfArrays(convertedData, setStyle);
    wb.SheetNames.push(sn);
    wb.Sheets[sn] = ws;
    const wbout = XLSX.write(wb, { bookType: "xlsx", bookSST: true, type: "binary" });
    const fileName = "abc.xlsx";
    saveAsFile(s2ab(wbout), fileName, fileType);
});