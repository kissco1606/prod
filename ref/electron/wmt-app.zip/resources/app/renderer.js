// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// No Node.js APIs are available in this process because
// `nodeIntegration` is turned off. Use `preload.js` to
// selectively enable features needed in the rendering
// process.
fs = require('fs');
fsExtra = require('fs-extra');
path = require('path');
c_process = require('child_process');
oracle = require('./src/oracle');
XLSX = require('xlsx');
require('array-foreach-async');

const filePath = "C:\\Users\\psm37\\Desktop\\js\\test.bat";
const spawnType = TYPES.process.spawn;
// const bat = c_process.spawn('cmd.exe', ['/c', filePath]);
// bat.stdout.on('data', (data) => {
//     const str = String.fromCharCode.apply(null, data);
//     console.info(str);
// });
// bat.stderr.on('data', (data) => {
//     const str = String.fromCharCode.apply(null, data);
//     console.error(str);
// });
// bat.on('exit', (code) => {
//     const preText = `Child exited with code ${code} : `;
//     switch(code){
//         case 0:
//             console.info(preText+"Something unknown happened executing the batch.");
//             break;
//         case 1:
//             console.info(preText+"The file already exists");
//             break;
//         case 2:
//             console.info(preText+"The file doesn't exists and now is created");
//             break;
//         case 3:
//             console.info(preText+"An error ocurred while creating the file");
//             break;
//     }
// });
const bat = c_process.spawnSync('cmd.exe', ['/c', filePath], { shell: true });
console.log(bat.output);
// const bat = c_process.spawnSync(spawnType.command.cmd, [spawnType.option.c, filePath], { shell: true });
// console.log(bat.output);
// $(function () {
//     init();
// });