fs = require('fs');
fsExtra = require('fs-extra');
path = require('path');
c_process = require('child_process');
oracle = require('./src/oracle');
XLSX = require('xlsx-style');
iconv = require('iconv-lite');
jschardet = require('jschardet');
JSZip = require("jszip");
JapaneseHolidays = require('japanese-holidays');
streamSaver = require('streamsaver');
require('array-foreach-async');

// const spawnType = TYPES.process.spawn;
// const filePath = "C:\\Users\\805639\\Desktop\\js\\test.bat";
// const bat = c_process.spawn(spawnType.command.cmd, [spawnType.option.c, filePath, 'YUYU2'], { shell: true });
// bat.stdout.on('data', (data) => {
//     const str = new Encoder(data).bufferToStringWithIconv();
//     console.log(str);
// });
// bat.stderr.on('data', (data) => {
//     const str = new Encoder(data).bufferToStringWithIconv();
//     console.log(str);
// });
// bat.on('close', (code) => {
//     console.log(code);
//     // const preText = `Child exited with code ${code} : `;
//     // switch(code){
//     //     case 0:
//     //         console.info(preText+"Something unknown happened executing the batch.");
//     //         break;
//     //     case 1:
//     //         console.info(preText+"The file already exists");
//     //         break;
//     //     case 2:
//     //         console.info(preText+"The file doesn't exists and now is created");
//     //         break;
//     //     case 3:
//     //         console.info(preText+"An error ocurred while creating the file");
//     //         break;
//     // }
// });

// const bat = c_process.spawnSync('cmd.exe', ['/c', filePath], {
//     stdio: 'pipe',
//     encoding: 'utf-8'
// });
// console.log(String(bat.stdout));
// console.log(String(bat.stderr));
// const bat = c_process.spawnSync(spawnType.command.cmd, [spawnType.option.c, filePath], { shell: true });
// console.log(bat.output);
$(function () {
    init();
});