const oracledb = require("oracledb");

const oracle = {
    init: () => {
        if(!oracledb) {
            throw new Error(MESSAGES.system_error);
        }
        else {
            oracledb.autoCommit = false;
        }
        return oracledb;
    },
    getConfig: (uid, pwd, sid) => {
        return {
            user: uid,
            password: pwd,
            connectString: sid
        };
    },
    connection: (info) => {
        
    },
    close: () => {
        if(connect) {
            connect.close();
        }
        return this;
    }
};

module.exports = oracle;