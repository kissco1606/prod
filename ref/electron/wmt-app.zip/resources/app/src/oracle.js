const oracledb = require("oracledb");

const oracle = {
    init: function() {
        if(!oracledb) {
            throw new Error(MESSAGES.system_error);
        }
        else {
            oracledb.autoCommit = false;
        }
        return oracledb;
    },
    getConfig: function(uid, pwd, sid) {
        return {
            user: uid,
            password: pwd,
            connectString: sid
        };
    }
};

module.exports = oracle;