﻿const eId = ELEMENTS.id;
const eClass = ELEMENTS.class;
const eIcon = ELEMENTS.icon;
const eStyle = ELEMENTS.style;
const MI = MODULE_ID;
