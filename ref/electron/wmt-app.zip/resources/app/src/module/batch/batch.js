﻿const BatchModule = function() {
    this.Define = {
        ELEMENTS: {
            id: {
                batchHeader: "batch-header",
                batchContents: "batch-contents",
                batchMenuContainer: "batch-menu-container",
                headerToolsConfigIcon: "header-tools-config-icon",
                applicationPage: "application-page",
                exportDumpCard: "export-dump-card",
                exportDump: {
                    phase: "export-dump__phase",
                    userName: "export-dump__user-name",
                    dbName: "export-dump__db-name",
                    sysDate: "export-dump__sys-date",
                    tables: "export-dump__tables"
                },
                importDump: {
                    dumpFile: "import-dump__dump-file",
                    logPath: "import-dump__log-path",
                    fromUserName: "import-dump__from-user-name",
                    toUserName: "import-dump__to-user-name",
                    toDbName: "import-dump__to-db-name",
                    tables: "import-dump__tables"
                },
                importDumpCard: "import-dump-card",
                rateDumpCard: "rate-dump-card",
                rateDump: {
                    phase: "rate-dump__phase",
                    userName: "rate-dump__user-name",
                    dbName: "rate-dump__db-name",
                    sysDate: "rate-dump__sys-date",
                    tableName: "rate-dump__table-name",
                    syouhnCd: "rate-dump__syouhn-cd",
                    ryourituVer: "rate-dump__ryouritu-ver"
                },
                sid: "sid",
                uid: "uid",
                pwd: "pwd",
                batchScenarioCard: "batch-scenario-card"
            },
            class: {
                commandLine: "command-line",
                accessButton: "access-button",
                accessLoadButton: "access-load-button",
                contentsContainer: "contents-container",
                commandArea: "command-area",
                actionArea: "action-area",
                commandBlock: "command-block",
                commandBlockHeader: "command-block-header",
                rateDumpBlock: "rate-dump-block",
                rateDumpBlockTitle: "rate-dump-block-title",
                subLabel: "sub-label"
            },
            style: {
                backgroundColor: "#333",
                headerHeight: "50px",
                transitionDuration: 200
            }
        },
        CAPTIONS: {
            title: "Batch Management",
            exec: "exec",
            clear: "clear",
            reset: "reset",
            allExec: "all exec",
            allClear: "all clear",
            getAllTables: "get all tables",
            phase: "phase",
            userName: "user_name",
            dbName: "db_name",
            sysDate: "sys_date",
            tables: "tables",
            option: "option",
            dumpFile: "dump_file",
            logPath: "log_path",
            fromUserName: "from_user_name",
            toUserName: "to_user_name",
            toDbName: "to_db_name",
            exportDump: {
                title: "Export Dump"
            },
            importDump: {
                title: "Import Dump"
            },
            rateDump: {
                title: "Rate Dump Export",
                block: {
                    label: {
                        commonParameter: "Common Parameter",
                        exportRateByProductCode: "Rate export by product code",
                        exportRateVOnlyT210: "Rate_V export only T210",
                        exportRateByTable: "Rate export by table"
                    }
                },
                parameter: {
                    phase: "PHASE",
                    userName: "USER_NAME",
                    dbName: "DB_NAME",
                    sysDate: "SYS_DATE",
                    tableName: "TABLE_NAME",
                    syouhnCd: "SYOUHN_CD",
                    ryourituVer: "RYOURITU_VER"
                }
            },
            batchScenario: {
                title: "Batch Scenario"
            },
            export: "export",
            import: "import",
            read: "read",
            file: "file"
        },
        TYPES: {
            page: {
                application: "application"
            },
            path: {
                export: "src/module/batch/export.json"
            },
            exportDump: {
                path: {
                    log: "src/module/batch/file/exportDump/log",
                    execute: "src/module/batch/file/exportDump/",
                    dir: "src/module/batch/file/exportDump",
                    fromBatch: "src/module/batch/file/exportDump/Export_Exec_ITB.bat",
                    fromParam: "src/module/batch/file/exportDump/Export_Param_o.txt"
                }
            },
            importDump: {
                path: {
                    log: "src/module/batch/file/importDump/log",
                    execute: "src/module/batch/file/importDump/",
                    dir: "src/module/batch/file/importDump",
                    fromBatch: "src/module/batch/file/importDump/Import_Exec.bat",
                    fromParam: "src/module/batch/file/importDump/Import_Param_o.txt"
                }
            },
            rateDump: {
                parameter: {
                    common: "common",
                    exportRateByProductCode: "exportRateByProductCode",
                    exportRateVOnlyT210: "exportRateVOnlyT210",
                    exportRateByTable: "exportRateByTable"
                },
                path: {
                    log: "src/module/batch/file/rateDumpExport/log",
                    execute: "src/module/batch/file/rateDumpExport/",
                    file: "src/module/batch/file/rateDumpExport"
                },
                files: {
                    exportRateByProductCode: "Export_Exec_Rate_ProductCode.bat",
                    exportRateVOnlyT210: "Export_Exec_Rate_V_T210.bat",
                    exportRateByTable: "Export_Exec_Rate_Table.bat"
                }
            },
            batchScenario: {
                saveType: {
                    export: "export",
                    import: "import"
                },
                path: {
                    log: "src/module/batch/file/batchScenario/log",
                    execute: "src/module/batch/file/batchScenario/"
                }
            },
            design: {
                exportDump: {
                    getTablesOptionCheck: {
                        rmvLog: "rmvLog",
                        rmvHozon: "rmvHozon",
                        rmvRateV: "rmvRateV"
                    }
                }
            }
        },
        MESSAGES: {
            LOG_MSG_WARNING: "インポートは正常に終了しましたが、警告が発生しました。",
            LOG_REG_IMPORTED: "^. . 表(.+?)をインポートしています(.+?)行インポートされました。$",
            LOG_REG_TABLE: "\"(.+?)\"$"
        }
    };
    this.parameter = {
        batchScenario: {
            commandBlockContainer: "commandBlockContainer",
            commandBlockHeaderLabel: "commandBlockHeaderLabel"
        }
    };
    this.design = {
        exportDump: {
            getTablesOptionCheck: {
                name: "export-dump__get-tables-option-checkbox",
                type: {
                    rmvLog: {
                        label: "remove[%LOG]",
                        id: "export-dump__get-tables-option-cb-rmvLog",
                        value: this.Define.TYPES.design.exportDump.getTablesOptionCheck.rmvLog,
                        isChecked: false
                    },
                    rmvHozon: {
                        label: "remove[%HOZON]",
                        id: "export-dump__get-tables-option-cb-rmvHozon",
                        value: this.Define.TYPES.design.exportDump.getTablesOptionCheck.rmvHozon,
                        isChecked: false
                    },
                    rmvRateV: {
                        label: "remove[CM_RateV]",
                        id: "export-dump__get-tables-option-cb-rmvCMRateV",
                        value: this.Define.TYPES.design.exportDump.getTablesOptionCheck.rmvRateV,
                        isChecked: true
                    }
                }
            }
        }
    };
    this.state = {
        exportDump: new Object(),
        importDump: new Object(),
        rateDump: new Object(),
        batchScenario: new Object()
    };
    this.export = new Object();
};
BatchModule.prototype = {
    initBatchModule: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seStyle = _this.Define.ELEMENTS.style;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const $container = jqById(eId.container);
        $container.css({ "margin-top": seStyle.headerHeight, "background-color": seStyle.backgroundColor });
        const $header = jqNode("header", { id: getHeaderId() });
        const $contents = jqNode("div", { id: getContentsId() });
        const $headerTitle = jqNode("div", { id: eId.headerTitle });
        const $titleIcon = jqNode("i", { class: eIcon.fileCode });
        const $titleIconSpan = jqNode("span", { id: eId.titleIcon }).append($titleIcon);
        const $titleTextSpan = jqNode("span", { id: eId.titleText }).text(captions.title);
        $headerTitle.append($titleIconSpan).append($titleTextSpan);
        const $headerTools = jqNode("div", { id: eId.headerTools });
        const $ellipsisVIconSpan = jqNode("span", { class: classes(eClass.toolsIcon, eClass.iconButton) }).append(jqNode("i", { class: eIcon.ellipsisV }));
        $ellipsisVIconSpan.click(function(e) {
            e.stopPropagation();
            _this.openMenu();
        });
        [$ellipsisVIconSpan].forEach(function(item) { $headerTools.append(item); });
        const $menuContainer = jqNode("div", { id: seId.batchMenuContainer, class: eClass.menuContainer });
        [$headerTitle, $headerTools, $menuContainer].forEach(function(item) { $header.append(item); });
        const $screen = jqNode("div", { id: seId.applicationPage, class: eClass.screen });
        $contents.append($screen);
        [$header, $contents].forEach(function(item) { $container.append(item) });

        const titleIconSize = $titleIcon.width();
        const headerToolsSize = $headerTools.width();
        jqById(eId.titleIcon).css({ width: (Math.ceil(titleIconSize) + 2) + "px" });
        jqById(eId.headerTitle).css({ width: "calc(100% - " + Math.ceil(headerToolsSize) + "px)" });

        getJson(types.path.export).then((data) => {
            _this.export = data;
            _this.setPage();
            fadeIn($container);
        }).catch((e) => {
            $container.empty();
            console.log(e);
            new Notification().error().open("Failed load module");
        });
        return this;
    },
    openMenu: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const $container = jqById(eId.container);
        const $menuContainer = jqById(seId.batchMenuContainer);
        $container.click(function() { $menuContainer.removeClass(eClass.isVisible); });
        $menuContainer.empty();
        const $menu = jqNode("ul", { class: classes(eClass.menu, eClass.menuBottomRight) });
        const itemList = new Array();
        createMenuItem(itemList, eIcon.home, CAPTIONS.home, transitionMenu);
        itemList.forEach(function(item) { $menu.append(item); });
        $menuContainer.append($menu);
        setTimeout(function() { $menuContainer.addClass(eClass.isVisible); });
        return null;
    },
    setPage: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const $contents = jqById(getContentsId());
        $contents.empty();
        const $screen = jqNode("div", { id: seId.applicationPage, class: eClass.screen });
        const $cardContainer = jqNode("div", { class: eClass.cardContainer });
        const cardList = [
            {
                id: seId.exportDumpCard,
                title: captions.exportDump.title,
                contents: _this.buildExportDump()
            },
            {
                id: seId.importDumpCard,
                title: captions.importDump.title,
                contents: _this.buildImportDump()
            },
            {
                id: seId.rateDumpCard,
                title: captions.rateDump.title,
                contents: _this.buildRateDump()
            },
            {
                id: seId.batchScenarioCard,
                title: captions.batchScenario.title,
                contents: _this.buildBatchScenario()
            }
        ];
        cardList.forEach(function(item) {
            $cardContainer.append(buildCard(item));
        });
        $screen.append($cardContainer);
        $contents.append($screen);
        return null;
    },
    createInfoObject: function(value, name) {
        return {
            value: value,
            name: name
        };
    },
    getExecuteBatchPath: function(path, timeStamp) {
        const fileStamp = timeStamp ? timeStamp : getFileStamp();
        const fileName = concatString("execute_", fileStamp, TYPES.file.extension.bat);
        const executePath = getApplicationPath(concatString(path, fileName));
        return {
            fileName: fileName,
            path: executePath
        };
    },
    getExecuteParamPath: function(path, timeStamp) {
        const fileStamp = timeStamp ? timeStamp : getFileStamp();
        const fileName = concatString("Export_Param_", fileStamp, TYPES.file.extension.txt);
        const executePath = getApplicationPath(concatString(path, fileName));
        return {
            prevFileName: "Export_Param.txt",
            fileName: fileName,
            path: executePath
        };
    },
    buildRateDump: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const rateDumpTypes = types.rateDump;
        const blockLabel = captions.rateDump.block.label;
        const rateDumpExport = _this.export.rateDump;
        const parameterCaptions = captions.rateDump.parameter;
        const rateDumpState = _this.state.rateDump;
        rateDumpState.path = createMultipleObject([rateDumpTypes.parameter.exportRateByProductCode, rateDumpTypes.parameter.exportRateVOnlyT210, rateDumpTypes.parameter.exportRateByTable].map(function(key) {
            return [key, getApplicationPath(concatString(rateDumpTypes.path.file, SIGN.ssh, rateDumpTypes.files[key]))];
        }));
        rateDumpState.injector = new Object();
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: seClass.contentsContainer });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $loadButton = jqNode("button", { class: eClass.flatButton }).append(eb.getFontAwesomeIcon(eIcon.listAlt));
        const $allExecButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.allExec));
        const $allClearButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.allClear));
        $container.append(eb.listAppend($actionArea, [$loadButton, $allExecButton, $allClearButton]));
        const getElementId = function(type, id) {
            return concatString(id, "__", type);
        };
        const getParameterElements = function(type) {
            const getCommandObject = function(label, inputType, inputId, injectorKey, subLabel) {
                return {
                    label: label,
                    inputType: inputType,
                    inputId: inputId,
                    subLabel: subLabel,
                    injectorKey: injectorKey
                };
            };
            const elementStack = new Array();
            switch(type) {
                case rateDumpTypes.parameter.exportRateByProductCode: {
                    rateDumpExport.tableList.forEach(function(table, i) {
                        const subLabel = concatString("TABLE : ", table);
                        const injectorKey = [type, table, rateDumpExport.variables.syouhnCd];
                        const commandObj = getCommandObject(parameterCaptions.syouhnCd, "textarea", getElementId(type, concatString(seId.rateDump.syouhnCd, i)), injectorKey, subLabel);
                        elementStack.push(commandObj);
                    });
                    break;
                }
                case rateDumpTypes.parameter.exportRateVOnlyT210: {
                    const injectorKey = [type, rateDumpExport.variables.ryourituVer];
                    const commandObj = getCommandObject(parameterCaptions.ryourituVer, "textarea", getElementId(type, seId.rateDump.ryourituVer), injectorKey);
                    elementStack.push(commandObj);
                    break;
                }
                case rateDumpTypes.parameter.exportRateByTable: {
                    const injectorKey = [type, rateDumpExport.variables.tableName];
                    const commandObj = getCommandObject(parameterCaptions.tableName, "textarea", getElementId(type, seId.rateDump.tableName), injectorKey);
                    elementStack.push(commandObj);
                    break;
                }
            }
            return elementStack;
        };
        const blockList = [
            {
                label: blockLabel.commonParameter,
                commandArea: [
                    {
                        label: upperCase(captions.phase),
                        inputType: "input",
                        inputId: seId.rateDump.phase,
                        injectorKey: ["common", rateDumpExport.variables.phase],
                        injectId: null
                    },
                    {
                        label: upperCase(captions.userName),
                        inputType: "input",
                        inputId: seId.rateDump.userName,
                        injectorKey: ["common", rateDumpExport.variables.userName],
                        injectId: seId.uid
                    },
                    {
                        label: upperCase(captions.dbName),
                        inputType: "input",
                        inputId: seId.rateDump.dbName,
                        injectorKey: ["common", rateDumpExport.variables.dbName],
                        injectId: seId.sid
                    },
                    {
                        label: upperCase(captions.sysDate),
                        inputType: "input",
                        inputId: seId.rateDump.sysDate,
                        injectorKey: ["common", rateDumpExport.variables.sysDate],
                        injectId: null
                    }
                ],
                execType: null
            },
            {
                label: blockLabel.exportRateByProductCode,
                commandArea: getParameterElements(rateDumpTypes.parameter.exportRateByProductCode),
                execType: rateDumpTypes.parameter.exportRateByProductCode
            },
            {
                label: blockLabel.exportRateVOnlyT210,
                commandArea: getParameterElements(rateDumpTypes.parameter.exportRateVOnlyT210),
                execType: rateDumpTypes.parameter.exportRateVOnlyT210
            },
            {
                label: blockLabel.exportRateByTable,
                commandArea: getParameterElements(rateDumpTypes.parameter.exportRateByTable),
                execType: rateDumpTypes.parameter.exportRateByTable
            }
        ];
        const injector = new Object();
        blockList.forEach(function(blockItem) {
            const $commandBlock = jqNode("div", { class: classes(seClass.commandBlock, seClass.rateDumpBlock) });
            const $title = jqNode("label").text(blockItem.label);
            const labelStack = [$title];
            const execType = blockItem.execType;
            if(execType) {
                const $buttonContainer = jqNode("div");
                const $execButton = jqNode("button", { class: eClass.buttonColorPositive }).text(upperCase(captions.exec));
                const $clearButton = jqNode("button", { class: eClass.buttonColorOrange }).text(upperCase(captions.clear));
                labelStack.push(eb.listAppend($buttonContainer, [$execButton, $clearButton]));
                $execButton.click(function() {
                    _this.rateDumpExport(execType);
                });
                $clearButton.click(function() {
                    _this.rateDumpClear(execType);
                });
            }
            const $label = eb.listAppend(jqNode("div", { class: seClass.rateDumpBlockTitle }), labelStack);
            $commandBlock.append($label);
            blockItem.commandArea.forEach(function(areaItem) {
                const $commandArea = jqNode("div", { class: seClass.commandArea });
                const $multiLabel = areaItem.subLabel ? eb.listAppend(jqNode("label"), [jqNode("div").text(areaItem.label), jqNode("div", { class: seClass.subLabel }).text(areaItem.subLabel)]) : null;
                const $label = $multiLabel ? $multiLabel : jqNode("label").text(areaItem.label);
                const $input = jqNode(areaItem.inputType, { id: areaItem.inputId });
                if(areaItem.injectId) injector[areaItem.injectId] = $input;
                setObject(rateDumpState.injector, areaItem.injectorKey, $input);
                $commandArea.append($label).append($input);
                $commandBlock.append($commandArea);
            });
            $container.append($commandBlock);
        });
        $loadButton.click(function() {
            new SqlModule().openAccessTemplate(injector);
        });
        $allExecButton.click(function() {
            _this.rateDumpExport();
        });
        $allClearButton.click(function() {
            _this.rateDumpClear();
        });
        return $container;
    },
    rateDumpExport: function(execType) {
        const _this = this;
        const types = _this.Define.TYPES;
        const captions = _this.Define.CAPTIONS;
        const blockLabel = captions.rateDump.block.label;
        const parameterCaptions = captions.rateDump.parameter;
        const rateDumpTypes = types.rateDump;
        const rateDumpState = _this.state.rateDump;
        const rateDumpExport = _this.export.rateDump;
        const fileStamp = getFileStamp();
        const filePath = getApplicationPath(rateDumpTypes.path.file);
        const executeBatchObj = _this.getExecuteBatchPath(rateDumpTypes.path.execute, fileStamp);
        const executeFilePath = executeBatchObj.path;
        const tfe = TYPES.file.extension;
        const logFileName = concatString(fileStamp, tfe.log);
        let logId = 1;
        const outputPathList = ["rateDumpExport", "log", fileStamp];
        const logInfo = {
            tempLogPath: getApplicationPath(rateDumpTypes.path.log),
            tempLogFilePath: getApplicationPath(concatString(rateDumpTypes.path.log, SIGN.ssh, logFileName)),
            logPath: getOutputPath(SIGN.none, outputPathList).modulePath
        };
        const parameterSet = new Object();
        const allTypesStack = [rateDumpTypes.parameter.exportRateByProductCode, rateDumpTypes.parameter.exportRateVOnlyT210, rateDumpTypes.parameter.exportRateByTable];
        const injector = rateDumpState.injector;
        const phase = _this.createInfoObject(injector.common[rateDumpExport.variables.phase].val(), parameterCaptions.phase);
        const userName = _this.createInfoObject(injector.common[rateDumpExport.variables.userName].val(), parameterCaptions.userName);
        const dbName = _this.createInfoObject(injector.common[rateDumpExport.variables.dbName].val(), parameterCaptions.dbName);
        const sysDate = _this.createInfoObject(injector.common[rateDumpExport.variables.sysDate].val(), parameterCaptions.sysDate);
        parameterSet.common = [
            { variable: rateDumpExport.variables.phase, value: null, bind: null },
            { variable: rateDumpExport.variables.userName, value: null, bind: null },
            { variable: rateDumpExport.variables.dbName, value: null, bind: null },
            { variable: rateDumpExport.variables.sysDate, value: null, bind: null }
        ];
        const checkAllResult = {
            error: false,
            messageList: new Array()
        };
        const deleteTemp = function() {
            try {
                new FileSystem(executeFilePath).deleteFile();
                new FileSystem(logInfo.tempLogFilePath).deleteFile();
            }
            catch(e) {}
        };
        const deleteTempLog = function(logFilePath) {
            try {
                new FileSystem(logFilePath).deleteFile();
            }
            catch(e) {}
        };
        const loading = new Loading();
        loading.on().then(function() {
            const createExecuteBatchFile = function(ps, execType, fromPath) {
                const common = ps.common;
                const self = ps[execType];
                const convertList = common.concat(self);
                const data = new FileSystem(fromPath).read().getData();
                const pauseRegExp = new RegExp("^pause", "g");
                let parameterCounter = 1;
                const stringArray = data.split(SIGN.crlf);
                stringArray.forEach(function(line, i) {
                    const isPause = !(new RegExpUtil(line).isNot(pauseRegExp));
                    if(isPause) {
                        stringArray[i] = "rem pause";
                        return;
                    }
                    convertList.some(function(item, j) {
                        const variableRegExp = new RegExp(concatString("^(set )", item.variable, "(=).+?$"), "g");
                        const isSetVariable = !(new RegExpUtil(line).isNot(variableRegExp));
                        if(isSetVariable) {
                            let value = item.value;
                            if(!value) {
                                value = concatString("%", parameterCounter);
                                if(j < common.length) {
                                    parameterSet.common[j].bind = parameterCounter;
                                }
                                else {
                                    parameterSet[execType][j - common.length].bind = parameterCounter;
                                }
                                parameterCounter++;
                            }
                            stringArray[i] = concatString("set ", item.variable, "=", value);
                            return true;
                        }
                    });
                });
                const batchData = stringArray.join(SIGN.crlf);
                new FileSystem(executeFilePath).write(batchData, true);
            };
            const execBatch = function(execType) {
                const ps = parameterSet;
                const psoPhase = find(rateDumpExport.variables.phase, ps.common, ["variable"]).data[0];
                const psoUserName = find(rateDumpExport.variables.userName, ps.common, ["variable"]).data[0];
                const psoDbName = find(rateDumpExport.variables.dbName, ps.common, ["variable"]).data[0];
                const psoSysDate = find(rateDumpExport.variables.sysDate, ps.common, ["variable"]).data[0];
                const mappingObjBase = [[psoPhase.variable, phase.value], [psoUserName.variable, userName.value], [psoDbName.variable, dbName.value], [psoSysDate.variable, sysDate.value]];
                const getBindParameter = function(setList, vm) {
                    const bindParameter = new Array();
                    setList.forEach(function(pso) {
                        const v = pso.variable;
                        const b = pso.bind;
                        bindParameter[b] = vm[v];
                    });
                    bindParameter.shift();
                    return bindParameter;
                };
                const runBatch = function(parameter) {
                    const logFile = concatString(fileStamp, SIGN.ub, logId, TYPES.file.extension.log);
                    const logFilePath = getApplicationPath(concatString(rateDumpTypes.path.log, SIGN.ssh, logFile));
                    const bat = new BatchUtil();
                    const windowStyle = bat.getIntWindowStyle();
                    const result = bat.run(executeFilePath, parameter, windowStyle.showShellMinSize, true, logFilePath);
                    if(result !== 0) throw new Error("Occurred error on a batch");
                    const logFs = new FileSystem(logFilePath);
                    const logData = logFs.read().getData();
                    const exp = new RegExp("LOG=(.*?).log", "g");
                    const consoleLogPathArray = exp.exec(logData);
                    const consoleLogPath = concatString(consoleLogPathArray[1], TYPES.file.extension.log);
                    const consoleLogData = new FileSystem(consoleLogPath).read().getData();
                    const consoleLogDataArray = getExistArray(consoleLogData.split(SIGN.crlf));
                    const hasError = !new RegExpUtil(consoleLogData).isNot(new RegExp("エラー", "g"));
                    const fileMessage = consoleLogDataArray.join(SIGN.crlf);
                    const dialogMessage = consoleLogDataArray.join(SIGN.br);
                    if(hasError) {
                        throw new Error(dialogMessage);
                    }
                    rateDumpState.log[execType].push(fileMessage);
                    logId++;
                    deleteTempLog(logFilePath);
                };
                switch(execType) {
                    case rateDumpTypes.parameter.exportRateByProductCode: {
                        const psoTableName = find(rateDumpExport.variables.tableName, ps[execType], ["variable"]).data[0];
                        const psoSyouhnCd = find(rateDumpExport.variables.syouhnCd, ps[execType], ["variable"]).data[0];
                        rateDumpExport.tableList.forEach(function(table) {
                            const syouhnCd = _this.createInfoObject(injector[execType][table][rateDumpExport.variables.syouhnCd].val(), parameterCaptions.syouhnCd);
                            const scArray = getExistArray(syouhnCd.value.split(SIGN.nl));
                            if(isVoid(scArray)) return;
                            scArray.forEach(function(sc) {
                                const valueMap = createMultipleObject(mappingObjBase.concat([[psoTableName.variable, table], [psoSyouhnCd.variable, sc]]));
                                const bindParameter = getBindParameter([psoPhase, psoUserName, psoDbName, psoSysDate, psoTableName, psoSyouhnCd], valueMap);
                                runBatch(bindParameter);
                            });
                        });
                        break;
                    }
                    case rateDumpTypes.parameter.exportRateVOnlyT210: {
                        const psoTableName = find(rateDumpExport.variables.tableName, ps[execType], ["variable"]).data[0];
                        const psoSyouhnCd = find(rateDumpExport.variables.syouhnCd, ps[execType], ["variable"]).data[0];
                        const psoRyourituVer = find(rateDumpExport.variables.ryourituVer, ps[execType], ["variable"]).data[0];
                        const ryourituVer = _this.createInfoObject(injector[execType][rateDumpExport.variables.ryourituVer].val(), parameterCaptions.ryourituVer);
                        const rvArray = getExistArray(ryourituVer.value.split(SIGN.nl));
                        if(isVoid(rvArray)) break;
                        rvArray.forEach(function(rv) {
                            const valueMap = createMultipleObject(mappingObjBase.concat([[psoRyourituVer.variable, rv]]));
                            const bindParameter = getBindParameter([psoPhase, psoUserName, psoDbName, psoSysDate, psoRyourituVer], valueMap);
                            runBatch(bindParameter);
                        });
                        break;
                    }
                    case rateDumpTypes.parameter.exportRateByTable: {
                        const psoTableName = find(rateDumpExport.variables.tableName, ps[execType], ["variable"]).data[0];
                        const tableName = _this.createInfoObject(injector[execType][rateDumpExport.variables.tableName].val(), parameterCaptions.tableName);
                        const tnArray = getExistArray(tableName.value.split(SIGN.nl));
                        if(isVoid(tnArray)) break;
                        tnArray.forEach(function(tn) {
                            const valueMap = createMultipleObject(mappingObjBase.concat([[psoTableName.variable, tn]]));
                            const bindParameter = getBindParameter([psoPhase, psoUserName, psoDbName, psoSysDate, psoTableName], valueMap);
                            runBatch(bindParameter);
                        });
                        break;
                    }
                }
            };
            const executeList = execType ? [execType] : allTypesStack;
            const v = new Validation();
            const vTypes = v.getTypes();
            const phaseLayout = v.getLayout(v.initLayout(phase.value, phase.name), [vTypes.required]);
            const userNameLayout = v.getLayout(v.initLayout(userName.value, userName.name), [vTypes.required, vTypes.notSpace]);
            const dbNameLayout = v.getLayout(v.initLayout(dbName.value, dbName.name), [vTypes.required, vTypes.notSpace]);
            const formatValidate = function(layout) {
                const actionLayout = v.getActionLayout();
                const exp = new RegExpUtil(layout.value);
                if(!exp.isYYYYMMDD()) {
                    actionLayout.error = true;
                    actionLayout.message = concatString(layout.label, " format is not valid");
                }
                return actionLayout;
            };
            const actionObj = { "format": formatValidate };
            const sysDateLayout = v.getLayout(v.initLayout(sysDate.value, sysDate.name), [vTypes.required, vTypes.notSpace, "format"], actionObj);
            v.reset().appendList([phaseLayout, userNameLayout, dbNameLayout, sysDateLayout]);
            const commonResult = v.exec();
            if(commonResult.error) {
                const message = concatString(concatString(SIGN.abs, blockLabel.commonParameter, SIGN.abe), SIGN.br, commonResult.message);
                checkAllResult.error = true;
                checkAllResult.messageList.push(message);
            }
            const setParameterLog = function(params, isCommonParam) {
                const resultStack = new Array();
                if(isVoid(params)) return resultStack;
                if(isCommonParam) {
                    params.forEach(function(data) {
                        resultStack.push(concatString(data.name, SIGN.equal, data.value));
                    });
                }
                else {
                    params.forEach(function(data) {
                        resultStack.push(concatString(data.name, SIGN.equal, SIGN.bs, SIGN.crlf, getExistArray(data.value.split(SIGN.nl)).join(SIGN.crlf), SIGN.crlf, SIGN.be));
                    });
                }
                return resultStack;
            };
            rateDumpState.log = new Object();
            executeList.forEach(function(execType) {
                const label = blockLabel[execType];
                const injector = rateDumpState.injector[execType];
                const path = rateDumpState.path[execType];
                const updateCheckResult = function(result) {
                    checkAllResult.error = true;
                    checkAllResult.messageList.push(concatString(concatString(SIGN.abs, label, SIGN.abe), SIGN.br, result.message));
                };
                rateDumpState.log[execType] = setParameterLog([phase, userName, dbName, sysDate], true);
                switch(execType) {
                    case rateDumpTypes.parameter.exportRateByProductCode: {
                        const ratePSyouhnCd = _this.createInfoObject(injector[rateDumpExport.tableObject.rateP][rateDumpExport.variables.syouhnCd].val(), parameterCaptions.syouhnCd);
                        const rateVSyouhnCd = _this.createInfoObject(injector[rateDumpExport.tableObject.rateV][rateDumpExport.variables.syouhnCd].val(), parameterCaptions.syouhnCd);
                        const rateWSyouhnCd = _this.createInfoObject(injector[rateDumpExport.tableObject.rateW][rateDumpExport.variables.syouhnCd].val(), parameterCaptions.syouhnCd);
                        const combineValue = [ratePSyouhnCd.value, rateVSyouhnCd.value, rateWSyouhnCd.value].join(SIGN.nl);
                        const combineLayout = v.getLayout(v.initLayout(combineValue, parameterCaptions.syouhnCd), [vTypes.requiredWithLineBreak]);
                        v.reset().appendList([combineLayout]);
                        const requiredResult = v.exec();
                        if(requiredResult.error) {
                            updateCheckResult(requiredResult);
                        }
                        else {
                            const rpscLayout = v.getLayout(v.initLayout(ratePSyouhnCd.value, ratePSyouhnCd.name), [vTypes.notSpace]);
                            const rvscLayout = v.getLayout(v.initLayout(rateVSyouhnCd.value, rateVSyouhnCd.name), [vTypes.notSpace]);
                            const rwscLayout = v.getLayout(v.initLayout(rateWSyouhnCd.value, rateWSyouhnCd.name), [vTypes.notSpace]);
                            v.reset().appendList([rpscLayout, rvscLayout, rwscLayout]);
                            const result = v.exec();
                            if(result.error) {
                                updateCheckResult(result);
                            }
                        }
                        const plRateP = {
                            name: concatString(ratePSyouhnCd.name, SIGN.bs, rateDumpExport.tableObject.rateP, SIGN.be),
                            value: ratePSyouhnCd.value
                        };
                        const plRateV = {
                            name: concatString(rateVSyouhnCd.name, SIGN.bs, rateDumpExport.tableObject.rateV, SIGN.be),
                            value: rateVSyouhnCd.value
                        };
                        const plRateW = {
                            name: concatString(rateWSyouhnCd.name, SIGN.bs, rateDumpExport.tableObject.rateW, SIGN.be),
                            value: rateWSyouhnCd.value
                        };
                        rateDumpState.log[execType] = rateDumpState.log[execType].concat(setParameterLog([plRateP, plRateV, plRateW]));
                        break;
                    }
                    case rateDumpTypes.parameter.exportRateVOnlyT210: {
                        const ryourituVer = _this.createInfoObject(injector[rateDumpExport.variables.ryourituVer].val(), parameterCaptions.ryourituVer);
                        const ryourituVerLayout = v.getLayout(v.initLayout(ryourituVer.value, ryourituVer.name), [vTypes.requiredWithLineBreak, vTypes.notSpace]);
                        v.reset().appendList([ryourituVerLayout]);
                        const result = v.exec();
                        if(result.error) {
                            updateCheckResult(result);
                        }
                        rateDumpState.log[execType] = rateDumpState.log[execType].concat(setParameterLog([ryourituVer]));
                        break;
                    }
                    case rateDumpTypes.parameter.exportRateByTable: {
                        const tableName = _this.createInfoObject(injector[rateDumpExport.variables.tableName].val(), parameterCaptions.tableName);
                        const tableNameLayout = v.getLayout(v.initLayout(tableName.value, tableName.name), [vTypes.requiredWithLineBreak, vTypes.notSpace]);
                        v.reset().appendList([tableNameLayout]);
                        const result = v.exec();
                        if(result.error) {
                            updateCheckResult(result);
                        }
                        rateDumpState.log[execType] = rateDumpState.log[execType].concat(setParameterLog([tableName]));
                        break;
                    }
                }
            });
            if(checkAllResult.error) {
                throw new Error(checkAllResult.messageList.join(concatString(SIGN.br, SIGN.br)));
            }
            new FileSystem(logInfo.tempLogPath).createFolder();
            new FileSystem(logInfo.logPath).createFolder();
            executeList.forEach(function(execType) {
                const path = rateDumpState.path[execType];
                const injector = rateDumpState.injector[execType];
                const logFileName = concatString(execType, TYPES.file.extension.log);
                switch(execType) {
                    case rateDumpTypes.parameter.exportRateByProductCode: {
                        parameterSet[execType] = [
                            { variable: rateDumpExport.variables.tableName, value: null, bind: null },
                            { variable: rateDumpExport.variables.syouhnCd, value: null, bind: null }
                        ];
                        createExecuteBatchFile(parameterSet, execType, path);
                        execBatch(execType);
                        break;
                    }
                    case rateDumpTypes.parameter.exportRateVOnlyT210: {
                        parameterSet[execType] = [
                            { variable: rateDumpExport.variables.tableName, value: rateDumpExport.tableObject.rateV, bind: null, isUserCommand: false },
                            { variable: rateDumpExport.variables.syouhnCd, value: "T210", bind: null },
                            { variable: rateDumpExport.variables.ryourituVer, value: null, bind: null }
                        ];
                        createExecuteBatchFile(parameterSet, execType, path);
                        execBatch(execType);
                        break;
                    }
                    case rateDumpTypes.parameter.exportRateByTable: {
                        parameterSet[execType] = [
                            { variable: rateDumpExport.variables.tableName, value: null, bind: null }
                        ];
                        createExecuteBatchFile(parameterSet, execType, path);
                        execBatch(execType);
                        break;
                    }
                }
                const outputLogData = rateDumpState.log[execType].join(SIGN.crlf);
                const outputLogFilePath = getOutputPath(logFileName, outputPathList).filePath;
                new FileSystem(outputLogFilePath).write(outputLogData, true);
            });
            deleteTemp();
            new Notification().complete().open("Rate dump file exported successfully");
            loading.off();
        }).catch(function(e) {
            deleteTemp();
            loading.onError(e);
        });
    },
    rateDumpClear: function(execType) {
        const _this = this;
        const types = _this.Define.TYPES;
        const rateDumpTypes = types.rateDump;
        const rateDumpState = _this.state.rateDump;
        const injector = rateDumpState.injector;
        const clear = function(obj, ak) {
            Object.keys(obj).forEach(function(key) {
                const target = obj[key];
                const isElement = target.jquery;
                if(!isElement) {
                    clear(target, ak);
                }
                else {
                    target.val(SIGN.none);
                }
            });
        };
        Object.keys(injector).forEach(function(key) {
            let ak = null;
            if(isVoid(execType)) {
                ak = key;
            }
            else if(key === execType) {
                ak = execType;
            }
            else {
                return;
            }
            const obj = accessObject(injector, [ak]);
            clear(obj, ak);
        });
    },
    buildExportDump: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const exportDumpState = _this.state.exportDump;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: seClass.contentsContainer });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $loadButton = jqNode("button", { class: eClass.flatButton }).append(eb.getFontAwesomeIcon(eIcon.listAlt));
        const $getAllTablesButton = jqNode("button", { class: eClass.buttonColorOrange }).text(upperCase(captions.getAllTables));
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        const $clearButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.clear));
        eb.listAppend($actionArea, [$loadButton, $getAllTablesButton, $execButton, $clearButton]);
        $container.append($actionArea);
        exportDumpState.forms = new Array();
        const itemList = [
            {
                label: upperCase(captions.phase),
                inputType: "input",
                inputId: seId.exportDump.phase,
                injectId: null
            },
            {
                label: upperCase(captions.userName),
                inputType: "input",
                inputId: seId.exportDump.userName,
                injectId: seId.uid
            },
            {
                label: upperCase(captions.dbName),
                inputType: "input",
                inputId: seId.exportDump.dbName,
                injectId: seId.sid
            },
            {
                label: upperCase(captions.sysDate),
                inputType: "input",
                inputId: seId.exportDump.sysDate,
                injectId: null
            },
            {
                label: upperCase(captions.tables),
                inputType: "textarea",
                inputId: seId.exportDump.tables,
                injectId: seId.exportDump.tables
            }
        ];
        const injector = new Object();
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: seClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            $commandArea.append($label).append($input);
            $container.append($commandArea);
            if(item.injectId) injector[item.injectId] = $input;
            exportDumpState.forms.push($input);
        });
        $loadButton.click(function() {
            new SqlModule().openAccessTemplate(injector);
        });
        $getAllTablesButton.click(function() {
            const $tables = injector[seId.exportDump.tables];
            const sid = _this.createInfoObject(injector[seId.sid].val(), upperCase(captions.dbName));
            const uid = _this.createInfoObject(injector[seId.uid].val(), upperCase(captions.userName));
            const info = { sid: sid, uid: uid, pwd: uid };
            _this.setAllTables(info, $tables);
        });
        $execButton.click(function() {
            _this.exportDump();
        });
        $clearButton.click(function() {
            _this.clearExportDump();
        });
        return $container;
    },
    clearExportDump: function() {
        const _this = this;
        const exportDumpState = _this.state.exportDump;
        if(!isVoid(exportDumpState.forms)) {
            exportDumpState.forms.forEach(function($element) {
                $element.val(SIGN.none);
            });
        }
        return null;
    },
    setAllTables: function(info, $element) {
        const seClass = this.Define.ELEMENTS.class;
        const captions = this.Define.CAPTIONS;
        const types = this.Define.TYPES;
        const exportDumpDesign = this.design.exportDump;
        const eddt = types.design.exportDump;
        const eddtGtoc = eddt.getTablesOptionCheck;
        const gtoc = exportDumpDesign.getTablesOptionCheck;
        const eb = new ElementBuilder();
        const sb = new StringBuilder();
        const subOption = { "width": "360px", "max-height": "470px" };
        const title = upperCase(captions.option, 0);
        const buildSubContents = function() {
            const $container = jqNode("div", { class: eClass.interfaceListAddContainer });
            const getTablesOptionCheckItemList = [getItemListObject(gtoc, eddtGtoc.rmvLog), getItemListObject(gtoc, eddtGtoc.rmvHozon), getItemListObject(gtoc, eddtGtoc.rmvRateV)];
            const $gtocCommandArea = jqNode("div", { class: seClass.commandArea });
            const $gtocItem = eb.createCheckbox(getTablesOptionCheckItemList).getItem();
            const $gtocMain = jqNode("div", { class: eClass.fullWidth }).append($gtocItem);
            eb.listAppend($gtocCommandArea, [$gtocMain]);
            $container.append($gtocCommandArea);
            return $container;
        };
        const okIcon = eb.getFontAwesomeIcon(eIcon.check);
        const closeIcon = eb.getFontAwesomeIcon(eIcon.times);
        const callback = function(dialogClose) {
            const optionStack = new Array();
            const $getTablesOption = jqByGroupName(gtoc.name, true);
            $getTablesOption.each(function() {
                optionStack.push($(this).val());
            });
            const db = new DBUtils();
            const loading = new Loading();
            loading.on().then(async() => {
                const v = new Validation();
                const vTypes = v.getTypes();
                const uidLayout = v.getLayout(v.initLayout(info.uid.value, info.uid.name), [vTypes.required, vTypes.notSpace]);
                const sidLayout = v.getLayout(v.initLayout(info.sid.value, info.sid.name), [vTypes.required, vTypes.notSpace]);
                v.reset().appendList([uidLayout, sidLayout]);
                const result = v.exec();
                if(result.error) {
                    throw new Error(result.message);
                }
                await db.connection(info);
                const layout = "TABLE_NAME";
                const tableName = "USER_TABLES";
                const query = sb.setQuery(["SELECT", layout, "FROM", tableName, "ORDER BY", layout]);
                const dataSet = await db.select(query);
                db.close();
                if(dataSet.count >= 1) {
                    const reg1 = new RegExp(optionStack.indexOf(eddtGtoc.rmvLog) >= 0 ? "(^.*LOG$)" : null);
                    const reg2 = new RegExp(optionStack.indexOf(eddtGtoc.rmvHozon) >= 0 ? "(^.*HOZON$)" : null);
                    const except = optionStack.indexOf(eddtGtoc.rmvRateV) >= 0 ? ["CM_RATEV"] : [];
                    const include = ["WFT_PDFHOZON"];
                    const data = db.getDataByIndex(dataSet, 0);
                    const n = data.filter((item) => {
                        const uci = upperCase(item);
                        return include.indexOf(uci) >= 0 || (!reg1.test(uci) && !reg2.test(uci) && except.indexOf(uci) < 0);
                    });
                    $element.val(n.join(SIGN.nl));
                }
                dialogClose();
                loading.off();
            }).catch((e) => {
                db.close();
                loading.onError(e);
            });
        };
        new SubDialog().setContents(title, buildSubContents(), subOption).setUserButton(okIcon, closeIcon).open(callback);
        return null;
    },
    exportDump: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const types = _this.Define.TYPES;
        const captions = _this.Define.CAPTIONS;
        const exportDumpTypes = types.exportDump;
        const exportDumpState = _this.state.exportDump;
        const exportDumpExport = _this.export.exportDump;
        const fileStamp = getFileStamp();
        const fromBatchFilePath = getApplicationPath(exportDumpTypes.path.fromBatch);
        const fromParamFilePath = getApplicationPath(exportDumpTypes.path.fromParam);
        const executeBatchObj = _this.getExecuteBatchPath(exportDumpTypes.path.execute, fileStamp);
        const executeParamObj = _this.getExecuteParamPath(exportDumpTypes.path.execute, fileStamp);
        const executeBatchFilePath = executeBatchObj.path;
        const executeParamFilePath = executeParamObj.path;
        const tfe = TYPES.file.extension;
        const logFileName = concatString(fileStamp, tfe.log);
        const outputPath = getOutputPath(logFileName, ["exportDump", "log"]);
        const logInfo = {
            tempLogPath: getApplicationPath(exportDumpTypes.path.log),
            tempLogFilePath: getApplicationPath(concatString(exportDumpTypes.path.log, SIGN.ssh, logFileName)),
            logPath: outputPath.modulePath,
            logFilePath: outputPath.filePath
        };
        const phase = _this.createInfoObject(jqById(seId.exportDump.phase).val(), upperCase(captions.phase));
        const userName = _this.createInfoObject(jqById(seId.exportDump.userName).val(), upperCase(captions.userName));
        const dbName = _this.createInfoObject(jqById(seId.exportDump.dbName).val(), upperCase(captions.dbName));
        const sysDate = _this.createInfoObject(jqById(seId.exportDump.sysDate).val(), upperCase(captions.sysDate));
        const tables = _this.createInfoObject(jqById(seId.exportDump.tables).val(), upperCase(captions.tables));
        const parameterSet = {
            common: [
                { variable: exportDumpExport.variables.phase, value: phase.value, bind: null },
                { variable: exportDumpExport.variables.userName, value: userName.value, bind: null },
                { variable: exportDumpExport.variables.dbName, value: dbName.value, bind: null },
                { variable: exportDumpExport.variables.sysDate, value: sysDate.value, bind: null }
            ],
            param: [
                { variable: exportDumpExport.variables.tables, value: tables.value, bind: null }
            ]
        };
        const sb = new StringBuilder();
        const deleteTemp = function() {
            try {
                new FileSystem(executeBatchFilePath).deleteFile();
                new FileSystem(executeParamFilePath).deleteFile();
                new FileSystem(logInfo.tempLogFilePath).deleteFile();
            }
            catch(e) {}
        };
        const stateInit = function() {
            exportDumpState.log = new Array();
        };
        stateInit();
        const loading = new Loading();
        loading.on().then(function() {
            const v = new Validation();
            const vTypes = v.getTypes();
            const phaseLayout = v.getLayout(v.initLayout(phase.value, phase.name), [vTypes.required]);
            const userNameLayout = v.getLayout(v.initLayout(userName.value, userName.name), [vTypes.required, vTypes.notSpace]);
            const dbNameLayout = v.getLayout(v.initLayout(dbName.value, dbName.name), [vTypes.required, vTypes.notSpace]);
            const formatValidate = function(layout) {
                const actionLayout = v.getActionLayout();
                const exp = new RegExpUtil(layout.value);
                if(!exp.isYYYYMMDD()) {
                    actionLayout.error = true;
                    actionLayout.message = concatString(layout.label, " format is not valid");
                }
                return actionLayout;
            };
            const actionObj = { "format": formatValidate };
            const sysDateLayout = v.getLayout(v.initLayout(sysDate.value, sysDate.name), [vTypes.required, vTypes.notSpace, "format"], actionObj);
            const tablesLayout = v.getLayout(v.initLayout(tables.value, tables.name), [vTypes.requiredWithLineBreak, vTypes.notSpace]);
            v.reset().appendList([phaseLayout, userNameLayout, dbNameLayout, sysDateLayout, tablesLayout]);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            const createType = { batch: 0, param: 1 };
            const createExecuteFile = function(type, ps, fromPath, toPath) {
                const convertList = ps;
                const data = new FileSystem(fromPath).read().getData();
                const pauseRegExp = new RegExp("^pause", "g");
                const expRegExp = new RegExp("^exp", "g");
                const stringArray = data.split(SIGN.crlf);
                if(type === createType.batch) {
                    stringArray.forEach(function(line, i) {
                        const isPause = !(new RegExpUtil(line).isNot(pauseRegExp));
                        const isExp = !(new RegExpUtil(line).isNot(expRegExp));
                        if(isPause) {
                            stringArray[i] = "rem pause";
                            return;
                        }
                        else if(isExp) {
                            stringArray[i] = line.replace(executeParamObj.prevFileName, executeParamObj.fileName);
                            return;
                        }
                        convertList.some(function(item, j) {
                            const variableRegExp = new RegExp(concatString("^(set )", item.variable, "(=)(.+?|)$"), "g");
                            const isSetVariable = !(new RegExpUtil(line).isNot(variableRegExp));
                            if(isSetVariable) {
                                let value = item.value;
                                if(value) {
                                    stringArray[i] = concatString("set ", item.variable, "=", value);
                                }
                                else {
                                    stringArray[i] = line;
                                }
                                return true;
                            }
                        });
                    });
                }
                else if(type === createType.param) {
                    const tableValue = convertList[0].value;
                    if(!isVoid(tableValue)) {
                        const list = tableValue.split(SIGN.nl).map(function(item) { return sb.sq(item); });
                        list.unshift(SIGN.bs);
                        list.push(SIGN.be);
                        stringArray.push(list.join(SIGN.crlf));
                    }
                }
                const outputData = stringArray.join(SIGN.crlf);
                new FileSystem(toPath).write(outputData, true);
                exportDumpState.log.push(outputData);
            };
            createExecuteFile(createType.batch, parameterSet.common, fromBatchFilePath, executeBatchFilePath);
            createExecuteFile(createType.param, parameterSet.param, fromParamFilePath, executeParamFilePath);
            new FileSystem(logInfo.tempLogPath).createFolder();
            const runBatch = function(execFilePath) {
                const errorMsg = "Occurred error on a batch";
                const bat = new BatchUtil();
                const windowStyle = bat.getIntWindowStyle();
                const result = bat.run(execFilePath, null, windowStyle.showShellMinSize, true, logInfo.tempLogFilePath);
                if(result !== 0) {
                    throw new Error(errorMsg);
                }
                const tempLogData = new FileSystem(logInfo.tempLogFilePath).read().getData();
                const exp = new RegExp("LOG=(.*?).log", "g");
                const consoleLogPathArray = exp.exec(tempLogData);
                const consoleLogPath = concatString(consoleLogPathArray[1], tfe.log);
                const consoleLogData = new FileSystem(consoleLogPath).read().getData();
                const hasError = !new RegExpUtil(consoleLogData).isNot(new RegExp("エラー", "g"));
                if(hasError) {
                    throw new Error(errorMsg);
                }
                exportDumpState.log.push(consoleLogData);
            };
            runBatch(executeBatchFilePath);
            deleteTemp();
            new FileSystem(logInfo.logPath).createFolder();
            new FileSystem(logInfo.logFilePath).write(exportDumpState.log.join(sb.copy(SIGN.crlf, 2)), true);
            new Notification().complete().open("Dump file exported successfully");
            stateInit();
            loading.off();
        }).catch(function(e) {
            deleteTemp();
            stateInit();
            loading.onError(e);
        });
        return null;
    },
    buildImportDump: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const importDumpState = _this.state.importDump;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: seClass.contentsContainer });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $loadButton = jqNode("button", { class: eClass.flatButton }).append(eb.getFontAwesomeIcon(eIcon.listAlt));
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        const $clearButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.clear));
        eb.listAppend($actionArea, [$loadButton, $execButton, $clearButton]);
        $container.append($actionArea);
        importDumpState.forms = new Array();
        const itemList = [
            {
                label: upperCase(captions.dumpFile),
                inputType: "input",
                inputId: seId.importDump.dumpFile,
                injectId: null
            },
            {
                label: upperCase(captions.logPath),
                inputType: "input",
                inputId: seId.importDump.logPath,
                injectId: null
            },
            {
                label: upperCase(captions.fromUserName),
                inputType: "input",
                inputId: seId.importDump.fromUserName,
                injectId: null
            },
            {
                label: upperCase(captions.toUserName),
                inputType: "input",
                inputId: seId.importDump.toUserName,
                injectId: seId.uid
            },
            {
                label: upperCase(captions.toDbName),
                inputType: "input",
                inputId: seId.importDump.toDbName,
                injectId: seId.sid
            },
            {
                label: upperCase(captions.tables),
                inputType: "textarea",
                inputId: seId.importDump.tables,
                injectId: null
            }
        ];
        const injector = new Object();
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: seClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            $commandArea.append($label).append($input);
            $container.append($commandArea);
            if(item.injectId) injector[item.injectId] = $input;
            importDumpState.forms.push($input);
        });
        $loadButton.click(function() {
            new SqlModule().openAccessTemplate(injector);
        });
        $execButton.click(function() {
            _this.importDump();
        });
        $clearButton.click(function() {
            _this.clearImportDump();
        });
        return $container;
    },
    clearImportDump: function() {
        const _this = this;
        const importDumpState = _this.state.importDump;
        if(!isVoid(importDumpState.forms)) {
            importDumpState.forms.forEach(function($element) {
                $element.val(SIGN.none);
            });
        }
        return null;
    },
    importDump: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const types = _this.Define.TYPES;
        const captions = _this.Define.CAPTIONS;
        const messages = _this.Define.MESSAGES;
        const importDumpTypes = types.importDump;
        const importDumpState = _this.state.importDump;
        const importDumpExport = _this.export.importDump;
        const fileStamp = getFileStamp();
        const fromBatchFilePath = getApplicationPath(importDumpTypes.path.fromBatch);
        const fromParamFilePath = getApplicationPath(importDumpTypes.path.fromParam);
        const executeBatchObj = _this.getExecuteBatchPath(importDumpTypes.path.execute, fileStamp);
        const executeParamObj = _this.getExecuteParamPath(importDumpTypes.path.execute, fileStamp);
        const executeBatchFilePath = executeBatchObj.path;
        const executeParamFilePath = executeParamObj.path;
        const tfe = TYPES.file.extension;
        const logFileName = concatString(fileStamp, tfe.log);
        const outputPath = getOutputPath(logFileName, ["importDump", "log"]);
        const logInfo = {
            tempLogPath: getApplicationPath(importDumpTypes.path.log),
            tempLogFilePath: getApplicationPath(concatString(importDumpTypes.path.log, SIGN.ssh, logFileName)),
            logPath: outputPath.modulePath,
            logFilePath: outputPath.filePath
        };
        const dumpFile = _this.createInfoObject(jqById(seId.importDump.dumpFile).val(), upperCase(captions.dumpFile));
        const logPath = _this.createInfoObject(jqById(seId.importDump.logPath).val(), upperCase(captions.logPath));
        const fromUserName = _this.createInfoObject(jqById(seId.importDump.fromUserName).val(), upperCase(captions.fromUserName));
        const toUserName = _this.createInfoObject(jqById(seId.importDump.toUserName).val(), upperCase(captions.toUserName));
        const toDbName = _this.createInfoObject(jqById(seId.importDump.toDbName).val(), upperCase(captions.toDbName));
        const tables = _this.createInfoObject(jqById(seId.importDump.tables).val(), upperCase(captions.tables));
        const parameterSet = {
            batch: [
                { variable: importDumpExport.variables.impParFile, value: executeParamObj.fileName, bind: null }
            ],
            param: [
                { variable: importDumpExport.variables.userId, value: null, bind: null },
                { variable: importDumpExport.variables.file, value: null, bind: null },
                { variable: importDumpExport.variables.fromUser, value: null, bind: null },
                { variable: importDumpExport.variables.toUser, value: null, bind: null },
                { variable: importDumpExport.variables.log, value: null, bind: null },
                { variable: importDumpExport.variables.tables, value: null, bind: null }
            ]
        };
        const sb = new StringBuilder();
        const deleteTemp = function() {
            try {
                new FileSystem(executeBatchFilePath).deleteFile();
                new FileSystem(executeParamFilePath).deleteFile();
            }
            catch(e) {}
        };
        const stateInit = function() {
            importDumpState.log = new Array();
            importDumpState.completeTables = new Array();
            importDumpState.failedTables = new Array();
            importDumpState.hasWarning = false;
            importDumpState.importTryLimit = 10;
            importDumpState.logInfo = new Object();
        };
        stateInit();
        const loading = new Loading();
        loading.on().then(function() {
            const v = new Validation();
            const vTypes = v.getTypes();
            const dumpFileLayout = v.getLayout(v.initLayout(dumpFile.value, dumpFile.name), [vTypes.required]);
            const logPathLayout = v.getLayout(v.initLayout(logPath.value, logPath.name), [vTypes.required]);
            const fromUserNameLayout = v.getLayout(v.initLayout(fromUserName.value, fromUserName.name), [vTypes.required, vTypes.notSpace]);
            const toUserNameLayout = v.getLayout(v.initLayout(toUserName.value, toUserName.name), [vTypes.required, vTypes.notSpace]);
            const toDbNameLayout = v.getLayout(v.initLayout(toDbName.value, toDbName.name), [vTypes.required, vTypes.notSpace]);
            const tablesLayout = v.getLayout(v.initLayout(tables.value, tables.name), [vTypes.requiredWithLineBreak, vTypes.notSpace]);
            v.reset().appendList([dumpFileLayout, logPathLayout, fromUserNameLayout, toUserNameLayout, toDbNameLayout, tablesLayout]);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            let initCount = 0;
            const parameterInit = function(isRec) {
                parameterSet.param.forEach(function(item) {
                    switch(item.variable) {
                        case importDumpExport.variables.userId: {
                            if(!isRec) item.value = concatString(toUserName.value, SIGN.ssh, toUserName.value, "@", toDbName.value);
                            break;
                        }
                        case importDumpExport.variables.file: {
                            if(!isRec) item.value = dumpFile.value;
                            break;
                        }
                        case importDumpExport.variables.fromUser: {
                            if(!isRec) item.value = fromUserName.value;
                            break;
                        }
                        case importDumpExport.variables.toUser: {
                            if(!isRec) if(!isRec) item.value = toUserName.value;
                            break;
                        }
                        case importDumpExport.variables.log: {
                            initCount++;
                            const folderName = concatString(logPath.value, sb.copy(SIGN.rssh, 2), fileStamp);
                            const fileName = concatString("IMPORT_", toUserName.value, SIGN.ub, initCount, tfe.log);
                            const logFilePath = concatString(folderName, sb.copy(SIGN.rssh, 2), fileName);
                            item.value = logFilePath;
                            importDumpState.logInfo = {
                                folderName: folderName,
                                fileName: fileName,
                                filePath: logFilePath
                            };
                            break;
                        }
                        case importDumpExport.variables.tables: {
                            let list = new Array();
                            if(!isRec) {
                                list = tables.value.split(SIGN.nl).map(function(item) { return sb.sq(item); });
                            }
                            else {
                                list = importDumpState.failedTables.map(function(item) { return sb.sq(item); });
                            }
                            list.unshift(concatString(SIGN.crlf, SIGN.bs));
                            list.push(SIGN.be);
                            item.value = list.join(SIGN.crlf);
                            break;
                        }
                    }
                });
            };
            parameterInit();
            const createType = { batch: 0, param: 1 };
            const createExecuteFile = function(type, ps, fromPath, toPath) {
                const convertList = ps;
                const data = new FileSystem(fromPath).read().getData();
                const stringArray = data.split(SIGN.crlf);
                stringArray.forEach(function(line, i) {
                    convertList.some(function(item, j) {
                        const variableRegExp = new RegExp(concatString("^", item.variable, "(=)(.+?|)$"), "g");
                        const isSetVariable = !(new RegExpUtil(line).isNot(variableRegExp));
                        if(isSetVariable) {
                            let value = item.value;
                            if(value) {
                                stringArray[i] = concatString(item.variable, "=", value);
                            }
                            else {
                                stringArray[i] = line;
                            }
                            return true;
                        }
                    });
                });
                if(type === createType.batch) {
                    const cd = concatString("cd /d ", getApplicationPath(importDumpTypes.path.dir));
                    stringArray.unshift(cd);
                }
                const outputData = stringArray.join(SIGN.crlf);
                new FileSystem(toPath).write(outputData, true);
                importDumpState.log.push(outputData);
            };
            createExecuteFile(createType.batch, parameterSet.batch, fromBatchFilePath, executeBatchFilePath);
            createExecuteFile(createType.param, parameterSet.param, fromParamFilePath, executeParamFilePath);
            new FileSystem(importDumpState.logInfo.folderName).createFolder();
            const logDataAnalysis = function(data) {
                const reg1 = new RegExp(messages.LOG_REG_IMPORTED, "g");
                const reg2 = new RegExp(messages.LOG_REG_TABLE, "g");
                data.split(SIGN.crlf).forEach(function(line) {
                    if(reg1.test(line)) {
                        const importedTable = reg2.exec(reg1.exec(line)[1])[1];
                        importDumpState.completeTables.push(importedTable);
                    }
                });
                if(importDumpState.completeTables.length >= 1) {
                    importDumpState.failedTables = tables.value.split(SIGN.nl).filter(function(item) {
                        return importDumpState.completeTables.indexOf(item) < 0;
                    });
                }
            };
            const isThrowError = function(consoleLogData) {
                let flag = false;
                TYPES.oracle.throwErrorList.some(function(obj) {
                    const regExp = new RegExp(obj.id, "g");
                    if(regExp.test(consoleLogData)) {
                        flag = true;
                        return true;
                    }
                });
                return flag;
            };
            const recursiveRunBatch = function(consoleLogData) {
                importDumpState.importTryLimit--;
                logDataAnalysis(consoleLogData);
                parameterInit(true);
                createExecuteFile(createType.param, parameterSet.param, fromParamFilePath, executeParamFilePath);
                runBatch(executeBatchFilePath);
            };
            const runBatch = function(execFilePath) {
                const errorMsg = "Occurred error on a batch";
                const bat = new BatchUtil();
                const windowStyle = bat.getIntWindowStyle();
                const result = bat.run(execFilePath, null, windowStyle.showShellMinSize, true);
                if(result !== 0) {
                    throw new Error(errorMsg);
                }
                const consoleLogData = new FileSystem(importDumpState.logInfo.filePath).read().getData();
                importDumpState.log.push(consoleLogData);
                const hasError = !new RegExpUtil(consoleLogData).isNot(new RegExp("エラー", "g"));
                if(hasError) {
                    if(isThrowError(consoleLogData) || importDumpState.importTryLimit < 0) {
                        throw new Error(errorMsg);
                    }
                    else {
                        recursiveRunBatch(consoleLogData);
                    }
                }
                else {
                    importDumpState.hasWarning = !new RegExpUtil(consoleLogData).isNot(new RegExp(messages.LOG_MSG_WARNING, "g"));
                }
            };
            runBatch(executeBatchFilePath);
            deleteTemp();
            new FileSystem(logInfo.logPath).createFolder();
            new FileSystem(logInfo.logFilePath).write(importDumpState.log.join(sb.copy(SIGN.crlf, 2)), true);
            if(importDumpState.hasWarning) {
                new Notification().warning().open("Dump file imported successfully. But has warning");
            }
            else {
                new Notification().complete().open("Dump file imported successfully");
            }
            stateInit();
            loading.off();
        }).catch(function(e) {
            deleteTemp();
            stateInit();
            loading.onError(e);
        });
        return null;
    },
    getBatchScenarioStructure: function() {
        const _this = this;
        const state = _this.state.batchScenario;
        const getIndex = function() {
            let index = 1;
            if(!isVoid(state.data)) {
                const indexStack = state.data.map(function(item) { return item.index; });
                index = getMaxNumInArray(indexStack) + 1;
            }
            return index;
        };
        return {
            dataScript_o: SIGN.none,
            dataScript: SIGN.none,
            path: SIGN.none,
            parameters: new Array(),
            index: getIndex(),
            displayIndex: state.data.length + 1
        };
    },
    setBatchScenarioCommandBlock: function() {
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const parameter = _this.parameter.batchScenario;
        const state = _this.state.batchScenario;
        const eb = new ElementBuilder();
        state.injector[parameter.commandBlockHeaderLabel] = new Array();
        const $commandBlockContainer = state.injector[parameter.commandBlockContainer];
        const createCommandBlock = function(item) {
            const $commandBlock = jqNode("div", { class: eClass.commandBlock });
            const $commandBlockHeader = jqNode("div", { class: eClass.commandBlockHeader });
            const $commandBlockHeaderLabel = jqNode("label").text(concatString("No.", item.displayIndex));
            const $commandBlockAction = jqNode("div", { class: eClass.commandBlockAction });
            const $copyButton = jqNode("button", { class: eClass.buttonColorPositive }).append(eb.getFontAwesomeIcon(eIcon.copy));
            const $removeButton = jqNode("button", { class: eClass.buttonColorAssertive }).append(eb.getFontAwesomeIcon(eIcon.trash));
            $copyButton.click(function() {
                const structure = _this.getBatchScenarioStructure();
                const cloneItem = cloneJS(item);
                cloneItem.index = structure.index;
                cloneItem.displayIndex = structure.displayIndex;
                state.data.push(cloneItem);
                _this.setBatchScenarioCommandBlock();
            });
            $removeButton.click(function() {
                const indexList = state.data.map(function(o) { return o.index; });
                const deleteIndex = indexList.indexOf(item.index);
                state.data.splice(deleteIndex, 1);
                state.injector[parameter.commandBlockHeaderLabel].splice(deleteIndex, 1);
                state.data.forEach(function(r, j) {
                    r.displayIndex = j + 1;
                    const $displayLabel = state.injector[parameter.commandBlockHeaderLabel][j];
                    $displayLabel.text(concatString("No.", r.displayIndex));
                });
                $commandBlock.remove();
            });
            eb.listAppend($commandBlockAction, [$copyButton, $removeButton]);
            eb.listAppend($commandBlockHeader, [$commandBlockHeaderLabel, $commandBlockAction]);
            const $commandBlockBody = jqNode("div", { class: eClass.commandBlockBody });
            const $bFileCommandArea = jqNode("div", { class: eClass.commandArea });
            const $bFileLabel = jqNode("label").text(upperCase(captions.file, 0));
            const $bFileInput = eb.getAttachLabel();
            const $commandAreaGroup = jqNode("div", { class: eClass.commandAreaGroup });
            const setCommandAreaGroup = function(paramObj) {
                if(!isVoid(paramObj)) {
                    $commandAreaGroup.empty();
                    paramObj.forEach(function(pm) {
                        const $paramCommandArea = jqNode("div", { class: eClass.commandArea });
                        const $label = jqNode("label").text(pm.label);
                        const $input = jqNode("textarea").val(pm.value);
                        new EventHandler($input).addEvent("change", function(e) {
                            const target = e.target;
                            pm.value = target.value;
                        });
                        eb.listAppend($paramCommandArea, [$label, $input]);
                        $commandAreaGroup.append($paramCommandArea);
                    });
                }
            };
            setCommandAreaGroup(item.parameters);
            $bFileInput.click(function(e) {
                const onReadFile = function(data, path, fileInfo) {
                    const encodedData = new Encoder(data).SJISArrayBufferToString();
                    const dataList = encodedData.split(SIGN.crlf);
                    const parameterRegExp = new RegExp("^  set /p ", "g");
                    const pauseRegExp = new RegExp("pause", "g");
                    const parameterMap = new Array();
                    const execDataStack = new Array();
                    let parameterIndex = 1;
                    dataList.forEach(function(line) {
                        let setData = line;
                        if(parameterRegExp.test(line)) {
                            const param1 = line.replace(parameterRegExp, SIGN.none).replace("：", SIGN.none);
                            const param2 = param1.split("=");
                            const paramObj = {
                                key: param2[0],
                                label: param2[1],
                                value: SIGN.none
                            };
                            parameterMap.push(paramObj);
                            setData = concatString("  set ", paramObj.key, "=", "%", parameterIndex);
                            parameterIndex++;
                        }
                        else if(pauseRegExp.test(line)) {
                            setData = line.replace(pauseRegExp, "rem pause");
                        }
                        execDataStack.push(setData);
                    });
                    setCommandAreaGroup(parameterMap);
                    $bFileInput.find("span").text(path);
                    item.dataScript_o = encodedData;
                    item.dataScript = execDataStack.join(SIGN.crlf);
                    item.path = path;
                    item.parameters = parameterMap;
                };
                new FileController()
                .setListener()
                .setReadType(TYPES.file.readType.arrayBuffer)
                .allowedExtensions([TYPES.file.extension.bat])
                .access(onReadFile);
            });
            if(!isVoid(item.path)) {
                $bFileInput.find("span").text(item.path);
            }
            eb.listAppend($bFileCommandArea, [$bFileLabel, $bFileInput]);
            eb.listAppend($commandBlockBody, [$bFileCommandArea, $commandAreaGroup]);
            eb.listAppend($commandBlock, [$commandBlockHeader, $commandBlockBody]);
            state.injector[parameter.commandBlockHeaderLabel].push($commandBlockHeaderLabel);
            return $commandBlock;
        };
        const commandBlockList = new Array();
        state.data.forEach(function(item) {
            const $commandBlock = createCommandBlock(item);
            commandBlockList.push($commandBlock);
        });
        $commandBlockContainer.empty();
        eb.listAppend($commandBlockContainer, commandBlockList);
        return null;
    },
    buildBatchScenario: function() {
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const bst = types.batchScenario;
        const parameter = _this.parameter.batchScenario;
        const state = _this.state.batchScenario;
        state.data = new Array();
        state.injector = new Object();
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: eClass.appContentsContainer });
        const $actionArea = jqNode("div", { class: eClass.actionArea });
        const $addIcon = eb.getFontAwesomeIcon(eIcon.plus).css({ "width": "40px" });
        const $addButton = jqNode("button", { class: eClass.buttonColorDark }).append($addIcon);
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        const $exportButton = jqNode("button", { class: eClass.buttonColorCalm }).text(upperCase(captions.export));
        const $importButton = jqNode("button", { class: eClass.buttonColorCyan }).text(upperCase(captions.import));
        const $resetButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.reset));
        eb.listAppend($actionArea, [$addButton, $execButton, $exportButton, $importButton, $resetButton]);
        const $commandBlockContainer = jqNode("div", { class: eClass.commandBlockContainer });
        state.injector[parameter.commandBlockContainer] = $commandBlockContainer;
        eb.listAppend($container, [$actionArea, $commandBlockContainer]);
        $addButton.click(function() {
            const dataObj = _this.getBatchScenarioStructure();
            state.data.push(dataObj);
            _this.setBatchScenarioCommandBlock();
        });
        $execButton.click(function() {
            _this.execBatchScenario();
        });
        $exportButton.click(function() {
            _this.fileTrasactionBatchScenario(bst.saveType.export);
        });
        $importButton.click(function() {
            _this.fileTrasactionBatchScenario(bst.saveType.import);
        });
        $resetButton.click(function() {
            state.data = new Array();
            $commandBlockContainer.empty();
        });
        return $container;
    },
    fileTrasactionBatchScenario: function(saveType) {
        const _this = this;
        const types = _this.Define.TYPES;
        const bst = types.batchScenario;
        const state = _this.state.batchScenario;
        const bu = new BinaryUtil();
        const mime = TYPES.file.mime;
        const extension = TYPES.file.extension;
        const loading = new Loading();
        loading.on().then(function() {
            switch(saveType) {
                case bst.saveType.export: {
                    if(isVoid(state.data)) {
                        throw new Error(MESSAGES.nothing_data);
                    }
                    const data = JSON.stringify(state.data);
                    const enc = bu.arrayBufferToBase64(bu.stringToArrayBuffer(data));
                    const fileName = concatString(getFileStamp("BatchScenario"), extension.txt);
                    saveAsFile(enc, mime.TEXT_UFT8, fileName);
                    break;
                }
                case bst.saveType.import: {
                    const onReadFile = function(data, path, fileInfo) {
                        try {
                            const dec = bu.arrayBufferToStringL(bu.base64ToArrayBuffer(data));
                            const jsData = JSON.parse(dec);
                            state.data = jsData;
                            _this.setBatchScenarioCommandBlock();
                        }
                        catch(e) {
                            new Notification().error().open(e.message);
                        }
                    };
                    new FileController().setListener().allowedExtensions([mime.TEXT]).access(onReadFile);
                    break;
                }
            }
            loading.off();
        }).catch(function(e) {
            loading.onError(e);
        });
        return null;
    },
    execBatchScenario: function() {
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const bst = types.batchScenario;
        const state = _this.state.batchScenario;
        const logStack = new Array();
        const fileStamp = getFileStamp();
        const executeBatchObj = _this.getExecuteBatchPath(bst.path.execute, fileStamp);
        const executeFilePath = executeBatchObj.path;
        const outputPathList = ["batchScenario", "log"];
        const outputPath = getOutputPath(concatString(fileStamp, TYPES.file.extension.log), outputPathList);
        const logInfo = {
            tempLogPath: getApplicationPathByList(bst.path.log, fileStamp),
            logPath: outputPath.modulePath,
            logFilePath: outputPath.filePath
        };
        const logId = {
            head: SIGN.none,
            paramNum: 0,
            paramInfo: SIGN.none
        };
        const deleteTemp = function() {
            try {
                new FileSystem(executeFilePath).deleteFile();
                new FileSystem(logInfo.tempLogPath).deleteFolder();
            }
            catch(e) {}
        };
        const endPhase = {
            checkNG: 0,
            checkOK: 1
        };
        const status = {
            error: false,
            message: new Array(),
            endPhase: endPhase.checkNG
        };
        const onEnd = function(phase, hasError) {
            if(phase === endPhase.checkOK) {
                deleteTemp();
                new FileSystem(logInfo.logPath).createFolder();
                new FileSystem(logInfo.logFilePath).write(logStack.join(SIGN.crlf), true);
                if(!hasError) {
                    new Notification().complete().open("Batch Scenario executed successfully");
                }
            }
        };
        const loading = new Loading();
        loading.on().then(function() {
            const v = new Validation();
            const vTypes = v.getTypes();
            const checkValidation = function() {
                if(isVoid(state.data)) {
                    status.error  = true;
                    status.message = [MESSAGES.nothing_data];
                }
                state.data.forEach(function(dataObj) {
                    const blockLabel = concatString("No.", dataObj.displayIndex);
                    if(isVoid(dataObj.dataScript)) {
                        const errorLabel = concatString("[", blockLabel, "]", upperCase(captions.file, 0));
                        const message = concatString(errorLabel, " : Not found file data");
                        status.error = true;
                        status.message.push(message);
                    }
                    else if(!isVoid(dataObj.parameters)) {
                        const layoutStack = new Array();
                        dataObj.parameters.forEach(function(param) {
                            const errorLabel = concatString("[", blockLabel, "]", param.label);
                            const paramLayout = v.getLayout(v.initLayout(param.value, errorLabel), [vTypes.requiredWithLineBreak, vTypes.notSpace]);
                            layoutStack.push(paramLayout);
                        });
                        v.reset().appendList(layoutStack);
                        const result1 = v.exec();
                        if(result1.error) {
                            status.error = true;
                            status.message.push(result1.message);
                        }
                        else {
                            const result2 = v.balanceCheck();
                            if(result2.error) {
                                status.error = true;
                                status.message.push(result2.message);
                            }
                        }
                    }
                });
                if(status.error) {
                    status.message = status.message.join(SIGN.br);
                }
                else {
                    status.endPhase = endPhase.checkOK;
                }
                return status;
            };
            checkValidation();
            if(status.error) {
                throw new Error(status.message);
            }
            const runBatch = function(dataObj, parameter) {
                const logFile = concatString(fileStamp, SIGN.ub, logId.head, logId.paramNum, TYPES.file.extension.log);
                const logFilePath = getFilePathByList(logInfo.tempLogPath, logFile);
                const tempLogStack = new Array();
                tempLogStack.push(logId.head);
                tempLogStack.push(concatString(upperCase(captions.file, 0), " : ",  dataObj.path));
                tempLogStack.push(concatString("Parameter : ", logId.paramInfo));
                const batchErrorMsgStack = [
                    "Occurred error",
                    concatString(SIGN.br, logId.head, "Parameter : ", logId.paramInfo)
                ];
                const bat = new BatchUtil();
                const windowStyle = bat.getIntWindowStyle();
                const result = bat.run(executeFilePath, parameter, windowStyle.showShellMinSize, true, logFilePath);
                if(result !== 0) {
                    const errorMsg = "Occurred error on a batch";
                    batchErrorMsgStack[0] = errorMSg;
                    tempLogStack.push(batchErrorMsgStack[0]);
                    logStack.push(tempLogStack.join(SIGN.crlf));
                    const batchErrorMsg = batchErrorMsgStack.join(SIGN.br);
                    throw new Error(batchErrorMsg);
                }
                const logFs = new FileSystem(logFilePath);
                const logData = logFs.read().getData();
                const batchStatus = new BatchUtil().getBatchStatus(logData);
                if(batchStatus.resStatus !== 0) {
                    tempLogStack.push(batchErrorMsgStack[0]);
                    logStack.push(tempLogStack.join(SIGN.crlf));
                    const batchErrorMsg = batchErrorMsgStack.join(SIGN.br);
                    throw new Error(batchErrorMsg);
                }
                logStack.push(tempLogStack.join(SIGN.crlf));
            };
            new FileSystem(logInfo.tempLogPath).createFolder();
            state.data.forEach(function(dataObj) {
                const blockLabel = concatString("No.", dataObj.displayIndex);
                const logLabel = concatString("[", blockLabel, "]");
                logId.head = logLabel;
                const batchData = dataObj.dataScript;
                new FileSystem(executeFilePath).write(batchData, true);
                if(!isVoid(dataObj.parameters)) {
                    const paramDefObj = {
                        values: new Array(),
                        info: new Array()
                    };
                    dataObj.parameters.forEach(function(paramObj, colIdx) {
                        getExistArray(paramObj.value.split(SIGN.nl)).forEach(function(pv, rowIdx) {
                            if(isVoid(paramDefObj.values[rowIdx])) {
                                paramDefObj.values[rowIdx] = new Array();
                                paramDefObj.info[rowIdx] = new Array();
                            }
                            paramDefObj.values[rowIdx][colIdx] = pv;
                            paramDefObj.info[rowIdx][colIdx] = concatString(paramObj.label, SIGN.equal, pv);
                        });
                    });
                    paramDefObj.values.forEach(function(param, i) {
                        logId.paramNum = i + 1;
                        logId.paramInfo = paramDefObj.info[i].join(SIGN.cw);
                        runBatch(dataObj, param);
                    });
                }
                else {
                    runBatch(dataObj, SIGN.none);
                }
            });
            onEnd(status.endPhase, false);
            loading.off();
        }).catch(function(e) {
            onEnd(status.endPhase, true);
            loading.onError(e);
        });
        return null;
    }
};

const BatchUtil = function() {
    this.WSH = "WScript.Shell";
    this.intWindowStyle = {
        hideShellActiveOtherWindow: 0,
        activeShellResetSize: 1,
        activeShellMinSize: 2,
        activeShellMaxSize: 3,
        showShellLatestSize: 4,
        activeShellCurrentSize: 5,
        setWindowMinSizeActiveZorder: 6,
        showShellMinSize: 7,
        showShellCurrentSet: 8,
        activeShellResetSizePosition: 9,
        applicationSet: 10
    };
    // https://stackoverflow.com/questions/55328916/electron-run-shell-commands-with-arguments
};
BatchUtil.prototype = {
    init: function() {
       const shell = new ActiveXObject(this.WSH);
       return shell;
    },
    getIntWindowStyle: function() {
        return this.intWindowStyle;
    },
    run: function(exePath, parameter, windowStyle, wait, logPath) {
        const shell = this.init();
        let commandList = [exePath];
        if(!isVoid(parameter) && typeIs(parameter).array) commandList = commandList.concat(parameter);
        if(!isVoid(logPath)) commandList.push(concatString("> ", logPath));
        const strCommand = commandList.join(SIGN.ws);
        return shell.Run(strCommand, windowStyle, wait);
    },
    getBatchStatus: function(data) {
        const resultObj = {
            resStatus: SIGN.none,
            funcId: SIGN.none,
            display: SIGN.none
        };
        const dataList = getExistArray(data.split(SIGN.crlf));
        const resStatusLabel = "処理状態区分：";
        const resStatusLabelRegExp = new RegExp(resStatusLabel);
        const execBatchFileLineReg = new RegExp("SQL = INSERT INTO IT_BatchLog", "g");
        const resultStack = new Array();
        const reverseDataList = dataList.reverse();
        for(let i = 0; i < reverseDataList.length; i++) {
            const item = reverseDataList[i];
            if(resStatusLabelRegExp.test(item)) {
                const resStatusList = item.split(resStatusLabel);
                resultObj.resStatus = Number(resStatusList[resStatusList.length - 1]);
                break;
            }
        }
        for(let i = 0; i < reverseDataList.length; i++) {
            const item = reverseDataList[i];
            if(execBatchFileLineReg.test(item)) {
                const tempList = item.split(", ");
                const bFuncId = tempList[tempList.length - 1];
                const funcId = bFuncId.replace(/\)/g, SIGN.none).replace(/\'/g, SIGN.none);
                if(!isVoid(funcId)) {
                    resultStack.push(concatString("【", funcId, "】"));
                    resultObj.funcId = funcId;
                }
                break;
            }
        }
        resultStack.push(concatString(resStatusLabel, resultObj.resStatus));
        resultObj.display = resultStack.join(SIGN.none);
        return resultObj;
    }
};
