importScripts("../../../js/define.js");
importScripts("../../../js/services.js");
fs = require('fs');
path = require('path');

self.onmessage = function(e) {
    const wData = e.data;
    const svFs = new FileSystem(wData.path);
    const fileListObj = wData.isWithSubFolder ? svFs.getAllFileList() : svFs.getFileList();
    const result = {
        count: fileListObj.count,
        name: fileListObj.name.join(SIGN.nl),
        path: fileListObj.path.join(SIGN.nl)
    };
    self.postMessage(result);
    self.close();
};