﻿importScripts("../../../js/define.js");
importScripts("../../../js/services.js");
fs = require('fs');
path = require('path');

self.onmessage = function(e) {
    const wData = e.data;
    const printStack = new Array();
    const c = SIGN.c;
    const u = "\\";
    const fileTree = new FileTree(wData.path).build();
    const tree = fileTree.tree;
    const treeSize = fileTree.size;
    const sb = new StringBuilder();
    Object.keys(tree).forEach((key) => {
        const self = tree[key];
        self.files.forEach((file) => {
            const root = key.split(u);
            const paddingSize = treeSize - root.length;
            const p = getIterator(paddingSize).map(() => SIGN.dash);
            const fileArray = file.indexOf(c) < 0 ? [file] : [sb.dq(file)];
            const lineString = root.concat(p).concat(fileArray).join(c);
            printStack.push(lineString);
        });
    });
    const fileTreeData = printStack.join(SIGN.nl);
    const result = {
        fileTree: fileTree,
        downloadData: fileTreeData
    };
    self.postMessage(result);
    self.close();
};
