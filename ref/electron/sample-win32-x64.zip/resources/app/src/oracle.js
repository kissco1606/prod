const oracledb = require("oracledb");
let connect = null;

function getConfig(uid, pwd, sid) {
    return {
        user: uid,
        password: pwd,
        connectString: sid
    };
};

const oracle = {
    connection: (info) => {
        return new Promise((resolve, reject) => {
            const config = getConfig(info.uid.value, info.pwd.value, info.sid.value);
            oracledb.getConnection(config).then((conn) => {
                connect = conn;
                return resolve();
            }).catch((err) => {
                console.log(err);
                return reject(err);
            });
        });
    },
    close: () => {
        if(connect) {
            connect.close();
        }
        return this;
    },
};

module.exports = oracle;