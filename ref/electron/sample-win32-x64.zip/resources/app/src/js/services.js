﻿function jqNode(tag, option) {
    return $("<" + tag + " />", option);
};

function jqById(id) {
    return $("#" + id);
};

function jqByClass(className) {
    return $("." + className);
};

function jqByTag(tagName) {
    return $(tagName);
};

function jqByGroupName(name, isChecked) {
    const item = concatString("input[name=", name, "]", (isChecked ? ":checked" : SIGN.none));
    return $(item);
};

function classes() {
    const argumentsList = Array.prototype.slice.call(arguments);
    const classes = new Array();
    argumentsList.forEach(function(item) {
        classes.push(item);
    });
    const size = classes.length;
    return size >= 1 ? classes.join(SIGN.ws) : "";
};

function fadeOut(element) {
    return new Promise(function(resolve, reject) {
        const $header = jqByTag("header");
        if($header) {
            $header.css({ opacity: 0 });
        }
        element.css({ opacity: 0 });
        setTimeout(function() {
            resolve();
        }, eStyle.transitionDuration);
    });
};

function fadeIn(element) {
    return new Promise(function(resolve, reject) {
        const $header = jqByTag("header");
        if($header) {
            $header.css({ opacity: 1 });
        }
        element.css({ opacity: 1 });
        setTimeout(function() {
            resolve();
        }, eStyle.transitionDuration);
    });
};

function getHeaderId() {
    return appState.module.id + "-" + eId.header;
};

function getContentsId() {
    return appState.module.id + "-" + eId.contents;
};

function overflowHide() {
    appState.overflow.push(1);
    if(appState.overflow.length <= 1) jqByTag("body").addClass(eClass.overflowHidden);
};

function overflowShow() {
    appState.overflow.pop();
    if(appState.overflow.length <= 0) jqByTag("body").removeClass(eClass.overflowHidden);
};

function typeIs(data) {
    const typeObject = new Object;
    const typeString = Object.prototype.toString.call(data).slice(8, -1);
    Object.keys(TYPES.variable).forEach(function(key) {
        const variableType = TYPES.variable[key];
        let result = variableType === typeString
        if(variableType === TYPES.variable.number && isNaN(data)) result = false;
        typeObject[key] = result;
    });
    return typeObject;
};

function upperCase(str, position) {
    if (!typeIs(position).number) {
        return str.toUpperCase();
    };
    const ahead = str.slice(0, position);
    const middle = str.charAt(position).toUpperCase();
    const behind = str.slice(position + 1);
    return  concatString(ahead, middle, behind);
};

function lowerCase(str, position) {
    if (!typeIs(position).number) {
        return str.toLowerCase();
    };
    return str.charAt(position).toLowerCase() + str.slice(position + 1);
};

function mapUpperCase(str) {
    return str.toUpperCase();
};

function mapLowerCase(str) {
    return str.toLowerCase();
};

function compareIndexOf(list, value) {
    return list.map(mapUpperCase).indexOf(upperCase(value));
};

function toString(value) {
    return String(value);
};

function toNumber(value) {
    return Number(value);
};

function toFullWidth(str) {
    return str.replace(/[A-Za-z0-9]/g, function(s) {
        return String.fromCharCode(s.charCodeAt(0) + 65248);
    });
};
function toHalfWidth(str) {
    return str.replace(/[Ａ-Ｚａ-ｚ０-９]/g, function(s) {
        return String.fromCharCode(s.charCodeAt(0) - 65248);
    });
};

function repetitive(char, size) {
    let setChar = "";
    for (let i = 0; i < size; i++) {
        setChar += setChar + char;
    }
    return setChar;
};

function setCharPadding(char, len, fillChar, fillPos) {
    fillChar = fillChar ? fillChar : "0";
    fillPos = fillPos ? fillPos : TYPES.syntax.left;
    const strChar = String(char);
    const repetition = repetitive(fillChar, len);
    const getFilled = function() {
        let mergedChar = "";
        switch (fillPos) {
            case TYPES.syntax.left: {
                mergedChar = concatString(repetition, strChar).slice(len * -1);
                break;
            }
            case TYPES.syntax.right: {
                mergedChar = concatString(strChar, repetition).slice(0, len);
                break;
            }
            default: {
                mergedChar = strChar;
                break;
            }
        }
        return mergedChar;
    };
    return strChar[len - 1] ? strChar : getFilled();
};

function concatString() {
    const argumentsList = Array.prototype.slice.call(arguments);
    const stack = new Array();
    argumentsList.forEach(function(item) {
        stack.push(item);
    });
    return stack.join(SIGN.none);
};

function escape(str) {
    return str.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/\//g, '\\/').replace(/</g, '\\x3c').replace(/>/g, '\\x3e').replace(/(0x0D)/g, '\r').replace(/(0x0A)/g, '\n');
};

function queryEscape(str) {
    return str.replace(/'/g, SIGN.none);
};

function getFileStamp(fileName) {
    const d = new Date();
    const year = String(d.getFullYear());
    const month = setCharPadding(String(d.getMonth() + 1), 2);
    const date = setCharPadding(String(d.getDate()), 2);
    const hours = setCharPadding(String(d.getHours()), 2);
    const minutes = setCharPadding(String(d.getMinutes()), 2);
    const seconds = setCharPadding(String(d.getSeconds()), 2);
    const timeStamp = concatString(year, month, date, hours,minutes, seconds);
    return isVoid(fileName) ? timeStamp : [fileName, timeStamp].join(SIGN.ub);
};

function convertPath(path) {
    return path.replace(new RegExp("\\\\", "g"), "\\\\");
};

function cloneJS(data) {
    const type = typeIs(data);
    if(type.object) {
        return $.extend(true, {}, data);
    }
    else if(type.array) {
        return new Array().concat(data);
    }
    return data;
};

function isVoid(val) {
    const type = typeof (val);
    const isArray = Array.isArray(val);
    if (isArray) {
        const size = val.length;
        return size <= 0;
    }
    else if ((!val && val !== 0) || val === null || type === undefined) {
        return true;
    }
    else {
        switch (type) {
            case 'object': {
                const objSize = Object.keys(val).length;
                return objSize <= 0;
            }
            default: {
                return false;
            }
        }
    }
};

function createObject(key, value) {
    const obj = new Object();
    obj[key] = value;
    return obj;
};

function createMultipleObject(setter) {
    let flag = true;
    const obj = new Object();
    setter.some(function(item) {
        const key = item[0];
        const value = item[1];
        if(isVoid(key)) {
            flag = false;
            return true;
        }
        obj[key] = value;
    });
    return flag ? obj : null;
};

function getObjectKeyByValue(obj, value) {
    let key = null;
    Object.keys(obj).some(function(k) {
        if(obj[k] === value) {
            key = k;
            return true;
        }
    });
    return key;
};

function accessObject(obj, keys) {
    try {
        return keys.reduce(function(prev, curr) {
            return prev[curr];
        }, obj);
    }
    catch(e) {
        return null;
    }
};

function accessObjectProperty(obj, keys) {
    try {
        return keys.reduce(function(prev, curr) {
            return getProperty(prev, curr);
        }, obj);
    }
    catch(e) {
        return null;
    }
};

function setObject(obj, keys, value) {
    return keys.reduce(function(prev, curr, i, a) {
        if(a.length === i + 1) return prev[curr] = value;
        if(isVoid(prev[curr])) return prev[curr] = new Object();
        return prev[curr];
    }, obj);
};

function mergeObject(objA, objB) {
    try {
        const imfoA = Immutable.fromJS(objA);
        const imfoB = Immutable.fromJS(objB);
        const objMap = imfoA.merge(imfoB);
        return objMap.toJS();
    }
    catch(e) {
        return new Object();
    }
};

function getProperty(obj, key) {
    let accessKey = null;
    Object.keys(obj).some(function(k) {
        if(upperCase(k) === upperCase(key)) {
            accessKey = k;
            return true;
        }
    });
    return obj[accessKey];
};

function getObjectMaxOrder(o, orderKey) {
    try {
        const oKey = orderKey ? orderKey : "order";
        const result = Object.keys(o).map(function(key) { return o[key] }).reduce(function(prev, curr) {
            return prev[oKey] >= curr[oKey] ? prev : curr;
        });
        return result[oKey];
    }
    catch(e) {
        return -1;
    }
};

function getObjectOrderList(o, orderKey) {
    const oKey = orderKey ? orderKey : "order";
    const orderList = Object.keys(o).sort(function(a, b) {
        const ao = o[a][oKey];
        const bo = o[b][oKey];
        if(ao < bo) return -1;
        else if(ao > bo) return 1;
        return 0;
    });
    return orderList;
};

function sortObjectByOrder(o, orderKey) {
    const newObject = new Object();
    const orderList = getObjectOrderList(o, orderKey);
    orderList.forEach(function(key) {
        newObject[key] = o[key];
    });
    return newObject;
};

function removeNullObject(obj) {
    if(!typeIs(obj).object) return false;
    Object.keys(obj).forEach(function(key) {
        if(isVoid(obj[key])) delete obj[key];
        else removeNullObject(obj[key]);
    });
};

function isListAllEqual(list) {
    return list.every(function(val, i, arry) {
        return val === arry[0];
    });
};

function getExistArray(list) {
    return list.filter(function(item) { return item; });
};

function getMaxNumInArray(list) {
    return list.reduce(function(prev, curr) {
        return prev >= curr ? prev : curr;
    });
};

function getMinNumInArray(list) {
    return list.reduce(function(prev, curr) {
        return prev >= curr ? curr : prev;
    });
};

function find(value, array, keys, matchFunc) {
    const match = function(a, b) {
        if(matchFunc && typeIs(matchFunc).function) {
            return matchFunc(a) === matchFunc(b);
        }
        return a === b;
    };
    const data = array.filter(function(item) {
        if(!isVoid(keys)) {
            return match(accessObject(item, keys), value);
        }
        return match(item, value);
    });
    return {
        isExist: data.length >= 1,
        data: data
    };
};

function getSelectionCustom(e) {
    const noneObj = {
        start: e.value.length,
        end: e.value.length,
        length: 0,
        text: SIGN.none
    };
    if("selectionStart" in e) {
        const l = e.selectionEnd - e.selectionStart;
        return {
            start: e.selectionStart,
            end: e.selectionEnd,
            length: l,
            text: e.value.substr(e.selectionStart, l)
        };
    }
    else if(document.selection) {
        e.focus();
        const r = document.selection.createRange();
        const tr = e.createTextRange();
        const tr2 = tr.duplicate();
        tr2.moveToBookmark(r.getBookmark());
        tr.setEndPoint("EndToStart", tr2);
        if (r == null || tr == null) return noneObj;
        const text_part = r.text.replace(/[\r\n]/g, ".");
        const text_whole = e.value.replace(/[\r\n]/g, ".");
        const the_start = text_whole.indexOf(text_part, tr.text.length);
        return {
            start: the_start,
            end: the_start + text_part.length,
            length: text_part.length,
            text: r.text
        };
    }
    return noneObj;
};
function getSelectionById(id) {
    const e = document.getElementById(id);
    return getSelection(e);
};
function getSelectionByClass(className) {
    const e = document.getElementsByClassName(className)[0];
    return getSelection(e);
};

function getIterator(size) {
    return Array.apply(null, new Array(size));
};

function getBinary(data) {
    const bytes = new Uint8Array(data);
    let binary = new String();
    const size = bytes.byteLength;
    for(let i = 0; i < size; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return binary;
};

function getNextChar(c) {
    return String.fromCharCode(c.charCodeAt(0) + 1);
};

function calcAlphabet(int) {
    const a = "A";
    return String.fromCharCode(a.charCodeAt(0) + int);
};

function createMenuItem(itemList, icon, text, func) {
    const $item = jqNode("li", { class: eClass.menuItem });
    const $icon = jqNode("span", { class: eClass.menuItemIcon }).append(jqNode("i", { class: icon }));
    const $text = jqNode("span", { class: eClass.menuItemText }).text(upperCase(text, 0));
    $item.click(function() {
        if(typeIs(func).function) {
            func();
        }
    });
    $item.append($icon).append($text);
    itemList.push($item);
};

function createMenuInfo(itemList, info) {
    if(typeIs(info).object && Object.keys(info).length >= 1) {
        const $devider = jqNode("li", { class: classes(eClass.menuItem, eClass.menuItemDevider) });
        $devider.append(jqNode("span").append(jqNode("hr")));
        itemList.push($devider);
        Object.keys(info).forEach(function(key) {
            const obj = info[key];
            const $item = jqNode("li", { class: classes(eClass.menuItem, eClass.menuItemInfo) });
            const $text = jqNode("span").text(concatString(obj.name, " : ", obj.value));
            $item.append($text);
            itemList.push($item);
        });
    }
};

function copyToClipboard(data) {
    const result = {
        error: false,
        message: SIGN.none
    };
    try {
        window.clipboardData.setData('Text', data);
        result.error = false;
    }
    catch(e) {
        result.error = true;
        result.message = e.message;
    }
    return result;
};

function buildCard(cardInfo) {
    const $card = jqNode("div", { id: cardInfo.id, class: eClass.card });
    const $cardTitle = jqNode("div", { class: eClass.cardTitle });
    const $titleIcon = jqNode("span", { class: eClass.cardTitleIcon }).append(jqNode("i", { class: eIcon.wrench }));
    const $titleText = jqNode("span", { class: eClass.cardTitleText }).text(cardInfo.title);
    $cardTitle.append($titleIcon).append($titleText);
    const $cardContentsContainer = jqNode("div", { class: eClass.cardContentsContainer });
    const $cardContents = jqNode("div", { class: eClass.cardContents }).html(cardInfo.contents);
    const $cardActions = jqNode("div", { class: eClass.cardActions });
    const $openIcon = jqNode("i", { class: eIcon.chevronCircleDown });
    $openIcon.click(function() {
        const isOpenned = $card.hasClass(eClass.cardContentsOpenned);
        if(isOpenned) {
            $card.removeClass(eClass.cardContentsOpenned);
        }
        else {
            $card.addClass(eClass.cardContentsOpenned);
        }
    });
    $cardContentsContainer.append($cardContents);
    $cardActions.append($openIcon);
    $card.append($cardTitle).append($cardContentsContainer).append($cardActions);
    return $card;
};

function getDialogHeader(type) {
    let caption, titleClass, icon;
    switch(type) {
        case TYPES.dialog.complete: {
            caption = upperCase(CAPTIONS.complete, 0);
            titleClass = classes(eClass.dialogIconTitleContainer, eClass.completeColor);
            icon = eIcon.checkCircle;
            break;
        }
        case TYPES.dialog.error: {
            caption = upperCase(CAPTIONS.error, 0);
            titleClass = classes(eClass.dialogIconTitleContainer, eClass.errorColor);
            icon = eIcon.timesCircle;
            break;
        }
        case TYPES.dialog.warning: {
            caption = upperCase(CAPTIONS.warning, 0);
            titleClass = classes(eClass.dialogIconTitleContainer, eClass.warningColor);
            icon = eIcon.exclamationTriangle;
            break;
        }
    }
    const $container = jqNode("div", { class: titleClass });
    const $icon = jqNode("span", { class: eClass.dialogTitleIcon }).append(jqNode("i", { class: icon }));
    const $titleText = jqNode("span", { class: eClass.dialogTitleText }).text(caption);
    $container.append($icon).append($titleText);
    return $container;
};

function getItemListObject(ds, type, optionClass) {
    return {
        label: ds.type[type].label,
        attributes: {
            id: ds.type[type].id,
            name: ds.name,
            value: ds.type[type].value
        },
        isChecked: ds.type[type].isChecked,
        optionClass: optionClass ? optionClass : SIGN.none
    };
};

const Notification = function () {
    this.dialogContainer = jqById(eId.notificationContainer);
    this.dialog = null;
    this.type = null;
    this.okButton = null;
    this.callback = null;
};
Notification.prototype = {
    setContents: function(title, contents) {
        const _this = this;
        const isWarningType = _this.type === TYPES.dialog.warning;
        const $dialog = jqNode("div", { id: eId.notification, class: eClass.dialog });
        const $title = jqNode("div", { class: eClass.dialogHeader });
        const $contents = jqNode("div", { class: eClass.dialogContents });
        const $actions = jqNode("div", { class: eClass.dialogActions });
        const actionStack = new Array();
        const $okButton = jqNode("button", { id: eId.notificationOk, class: eClass.dialogButton }).text(upperCase(CAPTIONS.ok));
        const close = function() { _this.close(); };
        const isCallbackFunc = typeIs(_this.callback).function;
        $okButton.click(function() {
            if(isWarningType && isCallbackFunc) {
                _this.callback(close);
            }
            else {
                _this.close();
            }
        });
        actionStack.push($okButton);
        if(isWarningType && isCallbackFunc) {
            const $cancelButton = jqNode("button", { id: eId.dialogClose, class: eClass.dialogButton }).text(upperCase(CAPTIONS.cancel));
            $cancelButton.click(function() {
                _this.close();
            });
            actionStack.push($cancelButton);
        }
        const eb = new ElementBuilder();
        eb.listAppend($actions, actionStack);
        $title.html(title);
        $contents.html(contents);
        [$title, $contents, $actions].forEach(function(item) {
            $dialog.append(item);
        });
        $contents.css({ "max-height": "600px" });
        this.dialog = $dialog;
        this.okButton = $okButton;
        return this;
    },
    complete: function() {
        this.type = TYPES.dialog.complete;
        return this;
    },
    error: function() {
        this.type = TYPES.dialog.error;
        return this;
    },
    warning: function(callback) {
        this.type = TYPES.dialog.warning;
        this.callback = callback;
        return this;
    },
    open: function (message) {
        const _this = this;
        _this.setContents(getDialogHeader(_this.type), message);
        if (!_this.dialog) return null;
        _this.dialogContainer.addClass(eClass.mostTop);
        _this.dialogContainer.removeClass(eClass.hide);
        _this.dialogContainer.append(_this.dialog);
        _this.okButton.focus();
        return this;
    },
    close: function () {
        const _this = this;
        if (_this.dialogContainer) {
            _this.dialogContainer.removeClass(eClass.mostTop);
            _this.dialogContainer.addClass(eClass.hide);
            _this.dialogContainer.empty();
        }
        return null;
    },
    exit: function (consoleMsg) {
        throw new Error(consoleMsg);
    }
};

const Dialog = function () {
    this.dialogContainer = jqById(eId.dialogContainer);
    this.dialog = null;
    this.contents = null;
    this.okButton = null;
    this.actions = null;
};
Dialog.prototype = {
    setContents: function (title, contents, option) {
        const _this = this;
        const $dialog = jqNode("div", { id: eId.dialog, class: eClass.dialog });
        const $title = jqNode("div", { class: eClass.dialogHeader });
        const $contents = jqNode("div", { class: eClass.dialogContents });
        const $actions = jqNode("div", { class: eClass.dialogActions });
        const $titleContainer = jqNode("div", { class: eClass.dialogIconTitleContainer });
        const $titleText = jqNode("span", { class: eClass.dialogTitleText }).text(title);
        $titleContainer.append($titleText);
        const $okButton = jqNode("button", { id: eId.dialogOk, class: eClass.dialogButton }).text(upperCase(CAPTIONS.ok));
        const $cancelButton = jqNode("button", { id: eId.dialogClose, class: eClass.dialogButton }).text(upperCase(CAPTIONS.cancel));
        [$okButton, $cancelButton].forEach(function(item) {
            $actions.append(item);
        });
        $cancelButton.click(function() {
            _this.close();
        });
        $title.html($titleContainer);
        $contents.html(contents);
        [$title, $contents, $actions].forEach(function(item) {
            $dialog.append(item);
        });
        if(option) $contents.css(option);
        this.dialog = $dialog;
        this.contents = $contents;
        this.okButton = $okButton;
        this.actions = $actions;
        return this;
    },
    setButton: function(buttonItems) {
        const _this = this;
        if(_this.actions) {
            buttonItems.forEach(function(item) {
                item.addClass(eClass.dialogButton);
                _this.actions.append(item);
            });
        }
        return this;
    },
    disableOkButton: function() {
        this.okButton.remove();
        return this;
    },
    open: function (callback) {
        const _this = this;
        if (!_this.dialog) return null;
        const close = function() {
            _this.close();
        };
        _this.okButton.click(function() {
            callback(close);
        });
        _this.dialogContainer.addClass(classes(eClass.dialogBackdrop, eClass.subTop));
        _this.dialogContainer.removeClass(eClass.hide);
        _this.dialogContainer.append(_this.dialog);
        overflowHide();
        return this;
    },
    close: function () {
        const _this = this;
        if (_this.dialogContainer) {
            _this.dialogContainer.removeClass(classes(eClass.dialogBackdrop, eClass.subTop));
            _this.dialogContainer.addClass(eClass.hide);
            _this.dialogContainer.empty();
            overflowShow();
        }
        return null;
    },
    render: function(contents) {
        this.contents.html(contents);
        return null;
    }
};

const SubDialog = function () {
    this.dialogContainer = jqNode("div", { class: eClass.subDialogContainer });
    this.dialog = jqNode("div", { class: eClass.subDialog });
    this.header = jqNode("div", { class: eClass.subDialogHeader });
    this.contents = jqNode("div", { class: eClass.subDialogContents });
    this.actionsVisible = true;
    this.actions = jqNode("div", { class: eClass.dialogActions });
    this.okButton = null;
    this.closeButton = null;
};
SubDialog.prototype = {
    setContents: function(title, contents, option) {
        const _this = this;
        const eb = new ElementBuilder();
        const $title = jqNode("span").text(title);
        _this.header.append($title);
        _this.contents.html(contents);
        const $okButton = jqNode("button", { class: eClass.dialogButton }).text(upperCase(CAPTIONS.ok));
        const $closeButton = jqNode("button", { class: eClass.dialogButton }).text(upperCase(CAPTIONS.cancel));
        [$okButton, $closeButton].forEach(function(item) {
            _this.actions.append(item);
        });
        $closeButton.click(function() { _this.close(); });
        _this.okButton = $okButton;
        _this.closeButton = $closeButton;
        if(option) _this.contents.css(option);
        eb.listAppend(_this.dialog, [_this.header, _this.contents, _this.actions]);
        _this.dialogContainer.append(_this.dialog);
        return this;
    },
    setUserButton: function(okButton, closeButton) {
        this.okButton.html(okButton);
        this.closeButton.html(closeButton);
        return this;
    },
    setButton: function(buttonItems) {
        const _this = this;
        if(_this.actions) {
            buttonItems.forEach(function(item) {
                item.addClass(eClass.dialogButton);
                _this.actions.append(item);
            });
        }
        return this;
    },
    hideActions: function() {
        this.actionsVisible = false;
        return this;
    },
    disableOkButton: function() {
        this.okButton.remove();
        return this;
    },
    open: function (callback) {
        const _this = this;
        const close = function() {
            _this.close();
        };
        _this.okButton.click(function() {
            callback(close);
        });
        if(!_this.actionsVisible) _this.actions.remove();
        jqByTag("body").append(_this.dialogContainer);
        return null;
    },
    close: function () {
        this.dialogContainer.remove();
        return null;
    }
};

const Loading = function() {
    this.container = jqById(eId.loadingContainer);
};
Loading.prototype = {
    on: function() {
        const _this = this;
        return new Promise(function(resolve, reject) {
            _this.container.empty();
            _this.container.append(jqNode("div", { class: eClass.loader }));
            _this.container.addClass(eClass.isVisible);
            setTimeout(function() {
                return resolve();
            });
        });
    },
    off: function() {
        this.container.removeClass(eClass.isVisible);
        this.container.empty();
    }
};

const FileController = function () {
    this.readType =  TYPES.file.readType.text;
    this.listener = null;
    this.allowed = null;
};
FileController.prototype = {
    setListener: function () {
        const $listener = jqNode("input", { type: "file", id: eId.fileListener, class: eClass.hide });
        jqById(eId.fileListener).remove();
        $("body").append($listener);
        this.listener = $listener;
        return this;
    },
    setListenerById: function (listenerId) {
        this.listener = jqById(listenerId);
        return this;
    },
    setReadType: function (type) {
        this.readType = type ? type : TYPES.file.readType.text;
        return this;
    },
    allowedExtensions: function (allowed) {
        this.allowed = allowed;
        return this;
    },
    access: function (func) {
        const _this = this;
        const allowed = _this.allowed;
        const $listener = _this.listener;
        if ($listener) {
            $listener.change(function(e) {
                e.stopPropagation();
                const files = e.target.files;
                if (files && files.length >= 1) {
                    const path = e.target.value;
                    const file = files[0];
                    const fileType = !isVoid(file.type) ? file.type : new FileSystem(path).getExtension();
                    if (isNotAllowed(allowed, fileType)) {
                        $listener.val(SIGN.none);
                        new Notification().error().open(MESSAGES.not_allowed_extension);
                        return false;
                    }
                    try {
                        _this.loadFile(file, func, path);
                    }
                    catch(e) {
                        new Notification().error().open(e.message);
                    }
                    finally {
                        $listener.val(SIGN.none);
                    }
                }
                $listener.val(SIGN.none);
                return false;
            });
            $listener.click();
        }
        return this;
    },
    loadFile: function (file, func, path) {
        const _this = this;
        const fr = new FileReader();
        fr.onload = function(e) {
            const result = e.target.result;
            func(result, path, file);
            if(!isVoid(_this.listener)) {
                _this.listener.remove();
            }
        };
        readFile(fr, this.readType, file);
    }
};

function isNotAllowed(allowed, fileType) {
    if (!typeIs(allowed).array) return false;
    let result = true;
    allowed.some(function(item) {
        if (item === fileType) {
            result = false;
            return true;
        }
    });
    return result;
};

function readFile(fr, type, file) {
    if (!file) {
        return false;
    }
    const readType = TYPES.file.readType;
    switch (type) {
        case readType.arrayBuffer: {
            fr.readAsArrayBuffer(file);
            break;
        }
        case readType.binaryString: {
            fr.readAsBinaryString(file);
            break;
        }
        case readType.dataUrl: {
            fr.readAsDataURL(file);
            break;
        }
        default: {
            fr.readAsText(file);
            break;
        }
    }
};

function saveAsFile(parts, type, fileName, isNotMs) {
    try {
        const mime = TYPES.file.mime;
        switch(type) {
            case mime.CSV: {
                parts = concatString("\ufeff", parts);
                break;
            }
            case mime.CSV_SJIS: {
                type = mime.CSV;
                const unicodeList = new BinaryUtil().stringToUnicodeList(parts);
                parts = new Uint8Array(Encoding.convert(unicodeList, 'sjis', 'unicode'));
                break;
            }
        }
        const blob = new Blob([parts], { tpye: type });
        if(!isNotMs) {
            window.navigator.msSaveBlob(blob, fileName);
        }
        else {
            saveAs(blob, fileName);
        }
    }
    catch (e) {
        new Notification().error().open(MESSAGES.faild_download_file);
    }
};

function saveAsZipFile(blob, fileName) {
    try {
        saveAs(blob, fileName);
    }
    catch (e) {
        new Notification().error().open(MESSAGES.faild_download_file);
    }
};

function s2ab(s) {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i < s.length; i++) {
        view[i] = s.charCodeAt(i) & 0xFF;
    }
    return buf;
};

function Workbook() {
    if(!(this instanceof Workbook)) return new Workbook();
    this.SheetNames = [];
    this.Sheets = {};
};

function sheetFromArrayOfArrays(data, callback, parameter) {
    const ws = new Object();
    const range = {
        s: { c: 10000000, r: 10000000 },
        e: { c: 0, r: 0 }
    };
    for(let R = 0; R != data.length; ++R) {
        for(let C = 0; C != data[R].length; ++C) {
            if(range.s.r > R) range.s.r = R;
            if(range.s.c > C) range.s.c = C;
            if(range.e.r < R) range.e.r = R;
            if(range.e.c < C) range.e.c = C;
            const cell = { v: data[R][C] };
            if(cell.v == null) cell.v = SIGN.none;
            const cell_ref = XLSX.utils.encode_cell({ c: C, r: R });
            if(typeof cell.v === "number") cell.t = "n";
            else if(typeof cell.v === "boolean") cell.t = "b";
            else if(cell.v instanceof Date) {
                cell.t = "n";
                cell.z = XLSX.SSF._table[14];
                cell.v = datenum(cell.v);
            }
            else cell.t = "s";
            if(typeIs(callback).function) callback(R, C, cell, parameter);
            ws[cell_ref] = cell;
        }
    }
    if(range.s.c < 10000000) ws['!ref'] = XLSX.utils.encode_range(range);
    return ws;
};

function datenum(v, date1904) {
    if(date1904) v += 1462;
    const epoch = Date.parse(v);
    return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000);
};

function duplicationCheckForArray(list) {
    const stack = new Array();
    const duplicated = new Array();
    const duplicatedIdx = new Array();
    list.forEach(function(item, i) {
        if(stack.indexOf(item) >= 0) {
            if(duplicated.indexOf(item) < 0) {
                duplicated.push(item);
                duplicatedIdx.push(i);
            }
            return;
        }
        stack.push(item);
    });
    return {
        hasError: duplicated.length >= 1,
        data: duplicated,
        index: duplicatedIdx
    };
};

function removeDuplicationArray(list) {
    return isVoid(list) ? list : list.filter(function(item, i) {
        return list.indexOf(item) === i;
    });
};

function bindQuery(query, mapping) {
    let resultQuery = query;
    const getBinder = function(key) {
        return concatString("\\${", key, "}");
    };
    Object.keys(mapping).forEach(function(key) {
        const value = mapping[key];
        const binder = getBinder(key);
        resultQuery = resultQuery.replace(new RegExp(binder, "g"), value);
    });
    return resultQuery;
};

const WorkerBuilder = function() {
    this.windowURL = window.URL || window.webkitURL;
    this.worker = null;
    this.blob = null;
};
WorkerBuilder.prototype = {
    stringifyFunction: function(func) {
        if(!typeIs(func).function) return null;
        return concatString("(", func.toString(), ")();");
    },
    process: function(func) {
        const code = this.stringifyFunction(func);
        try {
            this.blob = new Blob([code], { type: TYPES.file.mime.JAVASCRIPT });
        }
        catch(e) {
            window.BlobBuilder = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder;
            this.blob = new BlobBuilder();
            this.blob.append(code);
            this.blob = this.blob.getBlob();
        }
        const objectURL = this.windowURL.createObjectURL(this.blob);
        this.worker = new Worker(objectURL);
        return this;
    }
};

function threadMessage(module, actionType, params) {
    return {
        module: module,
        type: actionType,
        params: params
    };
};

function convertInputPath(path) {
    const pathList = getExistArray(path.split(SIGN.ssh));
    return pathList.join("\\\\");
};

function getApplicationPath(relativePath) {
    const rootPath = window.location.pathname;
    const rootPathList = getExistArray(rootPath.split(SIGN.ssh));
    rootPathList.pop();
    const relativePathList = getExistArray(relativePath.split(SIGN.ssh));
    const pathCollection = rootPathList.concat(relativePathList);
    return pathCollection.join("\\\\");
};

function getRootPath(path) {
    const rootPathList = getExistArray(path.split("\\"));
    rootPathList.pop();
    return rootPathList.join("\\");
};

function getOutputPath(fileName, subPath) {
    const root = [TYPES.path.output, appState.module.id];
    const sub = !isVoid(subPath) ? subPath : new Array();
    const moduleList = root.concat(sub);
    return {
        modulePath: getApplicationPath(moduleList.join(SIGN.ssh)),
        filePath: getApplicationPath(moduleList.concat([fileName]).join(SIGN.ssh))
    };
};

const ActiveXMLHttpRequest = function() {
    this.req = null;
    this.contentType = TYPES.file.mime.TEXT_UTF8;
    try {
        this.req = new ActiveXObject(TYPES.client.msxml2);
    } catch (e) {
        this.req = new XMLHttpRequest();
    }
};
ActiveXMLHttpRequest.prototype = {
    setContentType: function(type) {
        this.contentType = type;
        return this;
    },
    get: function(path, async) {
        const req = this.req;
        const contentType = this.contentType;
        return new Promise(function(resolve, reject) {
            try {
                req.open("GET", path, async);
                if(contentType) req.setRequestHeader("Content-Type", contentType);
                req.onreadystatechange = function() {
                    if(req.readyState === 4) {
                        const data = req.responseText;
                        return resolve(data);
                    }
                }
                req.send();
            }
            catch(e) {
                return reject(e);
            }
        });
    }
};

function getJson(path) {
    return new Promise(function(resolve, reject) {
        const typeJSON = TYPES.file.mime.JSON;
        const xhr = new ActiveXMLHttpRequest();
        xhr.setContentType(typeJSON);
        xhr.get(path, true).then(function(data) {
            try {
                const jsonData = JSON.parse(data);
                return resolve(jsonData);
            }
            catch(e) {
                return reject(e);
            }
        }).catch(function(e) {
            return reject(e);
        });
    });
};

const FileTree = function(path) {
    this.absolutePath = null;
    this.path = path;
    this.tree = new Object();
    this.treeSize = 0;
    this.u = "\\";
};
FileTree.prototype = {
    getAbsolutePath: function() {
        const path = this.path.split(this.u).filter(function(item, i, a) { return a.length > i + 1; }).join(this.u);
        return path + this.u;
    },
    getRootPath: function(path) {
        const oPath = path.replace(this.absolutePath, "");
        const pathList = oPath.split(this.u);
        const size = pathList.length;
        const rootObj = { key: oPath, reference: "", size: size };
        if(size >= 1) rootObj.reference = pathList.slice(0, size - 1).join(this.u);
        return rootObj;
    },
    getAccessKey: function(path) {
        return getExistArray(path.replace(this.absolutePath, "").split(this.u));
    },
    setTreeObject: function(obj, root, fileName) {
        const key = root.key;
        const reference = root.reference;
        if(!obj[key]) {
            obj[key] = { root: reference, files: [fileName] };
        }
        else {
            obj[key].files.push(fileName);
        }
    },
    setFilesTree: function(fileObj, _this) {
        const folder = fileObj.folder;
        const path = fileObj.path;
        const file = fileObj.file;
        const root = _this.getRootPath(path);
        const key = root.key;
        const reference = root.reference;
        const rootSize = root.size;
        _this.treeSize = _this.treeSize >= rootSize ? _this.treeSize : rootSize;
        const obj = _this.tree;
        if(!obj[key]) {
            obj[key] = { root: reference, folder: folder, files: [file.Name] };
        }
        else {
            obj[key].files.push(file.Name);
        }
    },
    iterateFiles: function(path, folder, recursive, actionPerFileCallback) {
        const _this = this;
        const fso = new ActiveXObject(TYPES.client.fileSystemObject);
        const folderObj = fso.GetFolder(path);
        const fileEnum = new Enumerator(folderObj.Files);
        for(; !fileEnum.atEnd(); fileEnum.moveNext()){
            const fileObj = {
                path: path,
                folder: folder ? folder : "",
                file: fso.GetFile(fileEnum.item())
            };
            actionPerFileCallback(fileObj, _this);
        }
        if(recursive){
            const subFolderEnum = new Enumerator(folderObj.SubFolders);
            for(; !subFolderEnum.atEnd(); subFolderEnum.moveNext()){
                var subFolderObj = fso.GetFolder(subFolderEnum.item());
                this.iterateFiles(subFolderObj.Path, subFolderObj.Name, true, actionPerFileCallback);
            }
        }
    },
    build: function() {
        this.absolutePath = this.getAbsolutePath(this.path);
        this.iterateFiles(this.path, null, true, this.setFilesTree);
        const target = this.path.replace(this.absolutePath, SIGN.none);
        return {
            tree: this.tree,
            size: this.treeSize,
            target: target
        };
    }
};

const FileSystem = function(path) {
    const io = TYPES.file.io;
    this.path = path;
    this.mode = io.mode.forWriting;
    this.option = false;
    this.format = io.format.os;
    this.data = null;
    this.u = "\\";
};
FileSystem.prototype = {
    init: function() {
        const fso = new ActiveXObject(TYPES.client.fileSystemObject);
        return fso;
    },
    toJsonPath: function() {
        if(typeIs(this.path).string) this.path = this.path.replace(new RegExp("\\\\", "g"), "/");
        return this;
    },
    toFilePath: function() {
        if(typeIs(this.path).string) this.path = this.path.replace(new RegExp("/", "g"), "\\");
        return this;
    },
    toSystemPath: function() {
        if(typeIs(this.path).string) this.path = this.path.replace(new RegExp("\\\\", "g"), "\\\\");
        return this;
    },
    getPath: function() {
        return this.path;
    },
    getExtension: function() {
        try {
            const path = this.path;
            const pathArray = path.split(this.u);
            const pathSize = pathArray.length;
            const target = pathArray[pathSize - 1];
            const targetArray = target.split(".");
            const targetSize = targetArray.length;
            const extension = concatString(".", targetArray[targetSize - 1]);
            return extension;
        }
        catch(e) {
            return SIGN.none;
        }
    },
    getFileList: function() {
        const fso = this.init();
        const folderObj = fso.GetFolder(this.path);
        const fileObj = folderObj.Files;
        const fileEnum = new Enumerator(fileObj);
        const result = {
            count: fileObj.Count,
            name: new Array(),
            path: new Array(),
        };
        for(; !fileEnum.atEnd(); fileEnum.moveNext()){
            const item = fileEnum.item();
            result.name.push(item.Name);
            result.path.push(item.Path);
        }
        return result;
    },
    setFormat: function(format) {
        this.format = format;
        return this;
    },
    createNotExists: function() {
        this.option = true;
        return this;
    },
    setData: function(data) {
        this.data = data;
        return this;
    },
    getData: function() {
        return this.data;
    },
    read: function() {
        const fileTypes = TYPES.file.io;
        const mode = fileTypes.mode;
        const fso = this.init();
        const stream = fso.OpenTextFile(this.path, mode.forReading, this.option, this.format);
        this.data = stream.ReadAll();
        stream.Close();
        return this;
    },
    write: function(data) {
        const fileTypes = TYPES.file.io;
        const mode = fileTypes.mode;
        const fso = this.init();
        const stream = fso.OpenTextFile(this.path, mode.forWriting, this.option, this.format);
        stream.Write(data);
        stream.Close();
        return this;
    },
    createFile: function(overwrite, unicode) {
        overwrite = overwrite ? true : false;
        unicode = unicode ? true : false;
        const fso = this.init();
        const stream = fso.CreateTextFile(this.path, overwrite, unicode);
        stream.Close();
        return this;
    },
    deleteFile: function() {
        const fso = this.init();
        const file = fso.GetFile(this.path);
        file.Delete();
        return this;
    },
    createFolder: function(existCheck) {
        const fso = this.init();
        const exec = function(path, isRecursiveFunc) {
            if(!fso.FolderExists(path)) {
                const parentPath = fso.GetParentFolderName(path);
                if(parentPath) {
                    exec(parentPath, true);
                    fso.CreateFolder(path);
                }
                else if(!isRecursiveFunc) {
                    throw new Error("Invalid path");
                }
            }
            else if(!isRecursiveFunc && existCheck) {
                throw new Error("Already exists folder");
            }
        };
        exec(this.path);
        return this;
    },
    deleteFolder: function(force) {
        const fso = this.init();
        fso.DeleteFolder(this.path, force ? force : false);
        return this;
    },
    copyFile: function(source, destination, isOverwrite) {
        const fso = this.init();
        fso.CopyFile(source, destination, isOverwrite);
        return this;
    },
    copyFolder: function(source, destination, isOverwrite) {
        const fso = this.init();
        fso.CopyFolder(source, destination, isOverwrite);
        return this;
    }
};

const ElementBuilder = function(element) {
    this.elements = new Array();
    this.element = element;
    this.vertical = false;
};
ElementBuilder.prototype = {
    setVertical: function() {
        this.vertical = true;
        return this;
    },
    setHorizontal: function() {
        this.vertical = false;
        return this;
    },
    setListener: function(listener) {
        this.listener = listener;
        return this;
    },
    getItem: function() {
        const _this = this;
        const arrayStack = new Array();
        _this.elements.forEach(function(itemUnit) {
            if(_this.vertical) {
                const $div = jqNode("div");
                itemUnit.forEach(function(item) { $div.append(item); });
                arrayStack.push($div);
            }
            else {
                itemUnit.forEach(function(item) {
                    arrayStack.push(item);
                });
            }
        });
        return arrayStack;
    },
    getPropOptionLayout: function() {
        return {
            disableList: new Array(),
            readonlyList: new Array()
        };
    },
    setItem: function($container) {
        const elements = this.getItem();
        elements.forEach(function(item) {
            $container.append(item);
        });
        return null;
    },
    createRadio: function(itemList) {
        const _this = this;
        _this.elements = new Array();
        const builder = function(label, attributes, isChecked, optionClass) {
            optionClass = optionClass ? optionsClass : eClass.rcColorDefault;
            const $input = jqNode("input", { type: "radio", name: attributes.name, id: attributes.id, value: attributes.value });
            if(isChecked) $input.prop({ checked: true });
            const $label = jqNode("label", { for: attributes.id, class: classes(eClass.radio, optionClass) }).text(label);
            return [$input, $label];
        }
        itemList.forEach(function(item) {
            const elm = builder(item.label, item.attributes, item.isChecked, item.optionClass);
            _this.elements.push(elm);
        });
        return this;
    },
    createCheckbox: function(itemList) {
        const _this = this;
        _this.elements = new Array();
        const builder = function(label, attributes, isChecked, optionClass) {
            optionClass = optionClass ? optionsClass : eClass.rcColorDefault;
            const $input = jqNode("input", { type: "checkbox", name: attributes.name, id: attributes.id, value: attributes.value });
            if(isChecked) $input.prop({ checked: true });
            const $label = jqNode("label", { for: attributes.id, class: classes(eClass.checkbox, optionClass) }).text(label);
            return [$input, $label];
        }
        itemList.forEach(function(item) {
            const elm = builder(item.label, item.attributes, item.isChecked, item.optionClass);
            _this.elements.push(elm);
        });
        return this;
    },
    getAttachLabel: function() {
        const $item = jqNode("div", { class: classes(eClass.attachLabel) });
        const $icon = this.getFontAwesomeIcon(eIcon.paperClip).css({ "padding-left": "4px", "margin-top": "4px" });
        const $span = jqNode("span", { class: eClass.breakWord });
        this.listAppend($item, [$icon, $span]);
        return $item;
    },
    getFontAwesomeIcon: function(icon, classOption) {
        const $icon = jqNode("i", { class: icon });
        if(classes) $icon.addClass(classOption);
        return $icon;
    },
    listAppend: function(target, list) {
        list.forEach(function(item) {
            target.append(item);
        });
        return target;
    },
    setHidden: function() {
        this.element.addClass(eClass.hide);
        return this;
    },
    removeHidden: function() {
        this.element.removeClass(eClass.hide);
        return this;
    },
    setReadonly: function() {
        this.element.addClass(eClass.readonly);
        this.element.prop("readonly", true);
        return this;
    },
    removeReadonly: function() {
        this.element.removeClass(eClass.readonly);
        this.element.prop("readonly", false);
        return this;
    },
    setDisable: function() {
        this.element.addClass(eClass.disable);
        this.element.prop("disabled", true);
        return this;
    },
    removeDisable: function() {
        this.element.removeClass(eClass.disable);
        this.element.prop("disabled", false);
        return this;
    },
    setElementDisable: function(e, prop) {
        const _this = this;
        const disableList = prop.disableList;
        const readonlyList = prop.readonlyList;
        const convert = function(elementString) {
            return $(elementString);
        };
        Object.keys(e).forEach(function(key) {
            if(disableList.indexOf(key) < 0 && readonlyList.indexOf(key) < 0) return;
            if(disableList.indexOf(key) >= 0) {
                const item = convert(e[key]);
                _this.element = item;
                _this.setDisable();
            }
            else {
                const item = e[key];
                _this.element = item;
                _this.setReadonly();
            }
        });
        return null;
    },
    setRadioCheck: function(designType, setObj) {
        const element = this.element;
        const option = new Object();
        const keyStack = new Array();
        Object.keys(setObj).forEach(function(key) {
            const id = designType[key].id;
            option[id] = setObj[key];
            keyStack.push(id);
        });
        element.each(function(i, item) {
            const id = item[0].id;
            if(keyStack.indexOf(id) >= 0) {
                item.prop("checked", option[id]);
            }
        });
        return null;
    }
};

const EventHandler = function(listener) {
    this.listener = listener;
    this.stateValue = "";
};
EventHandler.prototype = {
    addEvent: function(eventType, callback) {
        this.listener.on(eventType, callback);
        return this;
    },
    addInputEvent: function(callback) {
        const _this = this;
        this.listener.on("input", function(e) {
            const result = callback(e, this.value);
            if(typeIs(result).boolean && result === false) {
                this.value = _this.stateValue;
            }
            else {
                _this.stateValue = this.value;
            }
        });
    },
};

const Encryption = function() {
    this.data = null;
};
Encryption.prototype = {
    getSerialNumber: function() {
        const seed = SERIAL.seed;
        const size = SERIAL.size;
        const seedLength = seed.length;
        let serialNumber = SIGN.none;
        for (var i = 0; i < size; i++) {
            serialNumber += seed[Math.floor(Math.random() * seedLength)];
        }
        return serialNumber;
    },
    getData: function() {
        return this.data;
    },
    encode: function(data) {
        const serialNumber = this.getSerialNumber();
        this.data = CryptoJS.AES.encrypt(data, serialNumber).toString();
        this.data = this.data + serialNumber;
        return this;
    },
    decode: function(data) {
        const size = SERIAL.size;
        const pos = data.length - size;
        const serialNumber = data.substr(pos);
        const trueData = data.substring(0, pos);
        const bytes = CryptoJS.AES.decrypt(trueData, serialNumber);
        this.data = bytes.toString(CryptoJS.enc.Utf8);
        this.data = this.data.replace(new RegExp("\\\\\"", "g"), "\"");
        this.data = this.data.replace(new RegExp("âª", "g"), SIGN.none);
        return this;
    },
    decodeN: function(data) {
        const size = SERIAL.size;
        const pos = data.length - size;
        const serialNumber = data.substr(pos);
        const trueData = data.substring(0, pos);
        const bytes = CryptoJS.AES.decrypt(trueData, serialNumber);
        this.data = bytes.toString();
        this.data = this.data.replace(new RegExp("\\\\\"", "g"), "\"");
        this.data = this.data.replace(new RegExp("âª", "g"), SIGN.none);
        return this;
    }
};

const Store = function(state) {
    this.path = "storage/db.dat";
    this.toState = state;
    this.fromState = state.data;
    this.state = null;
    this.map = new Array();
};
Store.prototype = {
    load: function() {
        const _this = this;
        return new Promise(function(resolve, reject) {
            const xhr = new ActiveXMLHttpRequest();
            xhr.get(_this.path, true).then(function(data) {
                if(!isVoid(data)) {
                    const aes = new Encryption();
                    const dec = aes.decode(data).getData();
                    const jsData = JSON.parse(dec);
                    _this.toState.data = jsData;
                }
                return resolve();
            }).catch(function(e) {
                return reject(e);
            });
        });
    },
    init: function() {
        return this.fromState;
    },
    connect: function(map) {
        this.state = Immutable.fromJS(this.fromState);
        this.map = map ? map : new Array();
        return this;
    },
    select: function() {
        if (!this.fromState) return null;
        return Immutable.fromJS(this.fromState).getIn(this.map).toJS();
    },
    set: function(data) {
        if (!this.fromState || !this.state || !this.map) return null;
        const modified = this.state.setIn(this.map, data);
        this.fromState = modified.toJS();
        return this;
    },
    update: function(data) {
        if (!this.fromState || !this.state || !this.map) return null;
        const updated = this.state.updateIn(this.map, function(item) {
            const itemType = typeIs(item);
            if(itemType.object) {
                return item.merge(data);
            }
            else if(itemType.array) {
                return item.push(data);
            }
            else {
                return data;
            }
        });
        this.fromState = updated.toJS();
        return this;
    },
    delete: function() {
        if (!this.fromState || !this.state || !this.map) return null;
        const deleted = this.state.deleteIn(this.map);
        this.fromState = deleted.toJS();
        removeNullObject(this.fromState);
        return this;
    },
    apply: function() {
        this.toState.data = this.fromState;
        return this;
    },
    sync: function() {
        const data = JSON.stringify(this.toState.data);
        const aes = new Encryption();
        const enc = aes.encode(data).getData();
        const fs = new FileSystem(getApplicationPath(this.path));
        fs.write(enc);
        return null;
    }
};

const Interface = function(structure) {
    this.structure = structure;
    this.root = null;
};
Interface.prototype = {
    setRoot: function(root) {
        this.root = root;
        return this;
    },
    getKey: function() {
        return this.structure.key;
    },
    getType: function() {
        return this.structure.type;
    },
    getData: function() {
        return this.structure.data;
    },
    create: function(store) {
        const _this = this;
        store.connect([_this.getKey()]).set(_this.getType()).apply();
        return this;
    },
    getInjectData: function() {
        const argumentsList = Array.prototype.slice.call(arguments);
        const applied = this.getData().apply(null, argumentsList);
        return applied;
    },
    inject: function(store, injectData, key) {
        const _this = this;
        if(isVoid(store.init()[_this.getKey()])) _this.create(store);
        store.connect([_this.getKey(), key]).set(injectData).apply();
        return null;
    }
};

const Calendar = function() {
    this.def = {
        mode: {
            ymd: "ymd",
            ym: "ym",
            y: "y",
            s: "s"
        },
        days: [
            { id: 0, en: "sun", jp: "日" },
            { id: 1, en: "mon", jp: "月" },
            { id: 2, en: "tue", jp: "火" },
            { id: 3, en: "wed", jp: "水" },
            { id: 4, en: "thu", jp: "木" },
            { id: 5, en: "fri", jp: "金" },
            { id: 6, en: "sat", jp: "土" }
        ],
        year: {
            start: 1900,
            end: 2199
        },
        month: {
            start: 0,
            end: 11
        },
        date: {
            start: 1,
            col: 7,
            row: 6
        },
        col: 4,
        pagePer: 12
    };
    this.elements = {
        year: null,
        month: null,
        calendar: null,
        container: jqNode("div")
    };
    this.state = {
        mode: null,
        year: null,
        month: null,
        date: null,
        pages: new Array(),
        currentPage: 0,
        selected: new Object()
    };
    this.callback = null;
};
Calendar.prototype = {
    setYear: function(year) {
        this.state.year = year;
        return this;
    },
    setMonth: function(month) {
        this.state.month = month;
        return this;
    },
    setDate: function(date) {
        this.state.date = date;
        return this;
    },
    setMode: function(mode) {
        this.state.mode = mode;
        return this;
    },
    setCallback: function(callback) {
        this.callback = callback;
        return this;
    },
    initDateObj: function(dateObj) {
        this.setYear(dateObj.y);
        this.setMonth(dateObj.m);
        this.setDate(dateObj.d);
        this.state.selected = dateObj;
        return this;
    },
    createMonth: function() {
        const _this = this;
        const def = _this.def;
        const $table = jqNode("div", { class: classes(eClass.table, eClass.calendarPlate) });
        const col = def.col;
        let m = def.month.start;
        const getRow = function() { return jqNode("div", { class: eClass.tableRow }); };
        let $row = getRow();
        while(m <= def.month.end) {
            const monthString = setCharPadding(m + 1, 2);
            const $cell = jqNode("div", { class: classes(eClass.tableCell, eClass.calendarPannel) }).text(monthString);
            $cell.click(function() {
                _this.setMonth(monthString).setMode(def.mode.ymd).build();
            });
            $cell.css({ width: "50px" });
            $row.append($cell);
            m++;
            if(m % col === 0) {
                $table.append($row);
                $row = getRow();
            }
        }
        _this.elements.month = $table;
        return this;
    },
    getMonthElement: function() {
        return this.elements.month;
    },
    createYear: function() {
        const _this = this;
        const def = _this.def;
        const $tab = jqNode("div", { class: eClass.calendarTab });
        const pagePer = def.pagePer;
        const col = def.col;
        let y = def.year.start;
        let p = 0;
        let page = 1;
        const getTable = function() {
            const pageId = _this.getPageId(page);
            const $table = jqNode("div", { id: pageId, class: classes(eClass.table, eClass.calendarPlate, eClass.hide) });
            page++;
            _this.state.pages.push({ id: pageId, node: $table });
            return $table;
        };
        const getRow = function() { return jqNode("div", { class: eClass.tableRow }); };
        let $table = getTable();
        let $row = getRow();
        while(y <= def.year.end) {
            const yearString = String(y);
            const $cell = jqNode("div", { class: classes(eClass.tableCell, eClass.calendarPannel) }).text(yearString);
            $cell.click(function() {
                _this.setYear(yearString).setMode(def.mode.y).build();
            });
            $cell.css({ width: "50px" });
            $row.append($cell);
            y++;
            p++;
            if(y > def.year.end) {
                $table.append($row).appendTo($tab);
                continue;
            }
            if(p % col === 0) {
                $table.append($row);
                $row = getRow();
            }
            if(p === pagePer) {
                p = 0;
                $tab.append($table);
                $table = getTable();
            }
        }
        _this.elements.year = $tab;
        return this;
    },
    getYearElement: function() {
        return this.elements.year;
    },
    getPageId: function(page) {
        return concatString("calendar-page-", page);
    },
    setPage: function(page) {
        this.state.currentPage = page;
        return this;
    },
    paging: function() {
        const def = this.def;
        const state = this.state;
        const pages = state.pages;
        if(state.currentPage < 1 || state.currentPage > pages.length) {
            const page = Math.ceil((Number(state.year ? state.year : 0) - (def.year.start - 1)) / def.pagePer);
            if(page < 1) return false;
            this.setPage(page);
        }
        const currentPageId = this.getPageId(state.currentPage);
        pages.forEach(function(po) {
            if(currentPageId === po.id) po.node.removeClass(eClass.hide);
            else po.node.addClass(eClass.hide);
        });
        return this;
    },
    checkHoliday: function(date, lieuDay) {
        const holidayData = JapaneseHolidays.isHoliday(date, lieuDay);
        const holidayObj = {
            holidayName: isVoid(holidayData) ? SIGN.none : holidayData,
            isHoliday: !isVoid(holidayData)
        };
        return holidayObj;
    },
    createCalendarApi: function() {
        const _this = this;
        const def = _this.def;
        const state = _this.state;
        const eb = new ElementBuilder();
        const y = state.year;
        const m = state.month;
        const col = def.date.col;
        const row = def.date.row;
        const setStyle = function(target, dayIndex, isHoliday, isPreview) {
            if(isPreview) target.addClass(eClass.greyColor);
            else if(isHoliday) target.addClass(eClass.redColor);
            else if(dayIndex === 0) target.addClass(eClass.redColor);
            else if(dayIndex === 6) target.addClass(eClass.blueColor);
            else target.addClass(eClass.whiteColor);
        };
        const isSelected = function(d, isPreview) {
            const selected = state.selected;
            if(isVoid(selected) || isPreview || !(state.mode == def.mode.ymd || state.mode === null)) return false;
            return selected.y === state.year && selected.m === state.month && Number(selected.d) === d;
        };
        const $table = jqNode("div", { class: classes(eClass.table, eClass.calendarApi) });
        const $tableHeader = jqNode("div", { class: eClass.tableHeader });
        const $tableBody = jqNode("div", { class: eClass.tableBody });
        const $headerRow = jqNode("div", { class: eClass.tableRow });
        def.days.forEach(function(item) {
            const $cell = jqNode("div", { class: eClass.tableCell }).text(upperCase(item.en));
            setStyle($cell, item.id);
            $headerRow.append($cell);
        });
        $tableHeader.append($headerRow);
        const startDay = new Date(y, Number(m) - 1, 1).getDay();
        const startDiff = col - (col - startDay);
        const prevEnd = new Date(y, Number(m) - 1, 0).getDate();
        const endDate = new Date(y, m, 0).getDate();
        let nextDate = 1;
        let dateCount = def.date.start;
        const moveDate = function() { dateCount++; };
        const getDateObj = function(date, pass) {
            const dateObj = {
                date: date,
                dayIndex: -1,
                isSaturday: false,
                isSunday: false,
                isHoliday: false,
                holidayName: SIGN.none,
                name_en: SIGN.none,
                name_jp: SIGN.none,
                isPreview: pass
            };
            if(pass) return dateObj;
            const systemDate = new Date(y, Number(m) - 1, date);
            const day = systemDate.getDay();
            const fd = find(day, def.days, ["id"]).data[0];
            const holidayObj = _this.checkHoliday(systemDate, true);
            dateObj.dayIndex = fd.id;
            dateObj.isSaturday = fd.id === 6;
            dateObj.isSunday = fd.id === 0;
            dateObj.isHoliday = holidayObj.isHoliday;
            dateObj.holidayName = holidayObj.holidayName;
            dateObj.name_en = fd.en;
            dateObj.name_jp = fd.jp;
            return dateObj;
        };
        const getRow = function() { return jqNode("div", { class: eClass.tableRow }); };
        let $row = getRow();
        getIterator(col * row).forEach(function(c, i) {
            c = i + 1;
            const subtraction = startDiff - i;
            let vd;
            let isPreview = false;
            if(subtraction > 0) {
                vd = prevEnd - subtraction + 1;
                isPreview = true;
            }
            else if(dateCount > endDate) {
                vd = nextDate;
                nextDate++;
                isPreview = true;
            }
            else {
                vd = dateCount;
                moveDate();
                isPreview = false;
            }
            const dateObj = getDateObj(vd, isPreview);
            const $cell = jqNode("div", { class: eClass.tableCell }).text(dateObj.date);
            setStyle($cell, dateObj.dayIndex, dateObj.isHoliday, dateObj.isPreview);
            if(isSelected(dateObj.date, dateObj.isPreview)) $cell.addClass(eClass.calendarSelected);
            $row.append($cell);
            if(!dateObj.isPreview) {
                $cell.click(function() {
                    _this.setDate(setCharPadding(dateObj.date, 2));
                    if(typeIs(_this.callback).function) _this.callback(_this.getDateStamp());
                });
            }
            if(c % col === 0) {
                $tableBody.append($row);
                $row = getRow();
            }
        });
        eb.listAppend($table, [$tableHeader, $tableBody]);
        _this.elements.calendar = $table;
        return this;
    },
    getCalendar: function() {
        return this.elements.calendar;
    },
    getLabel: function() {
        const def = this.def;
        const state = this.state;
        if(state.mode === def.mode.y) {
            return state.year;
        }
        else {
            return [state.year, state.month].join(SIGN.ssh);
        }
    },
    build: function() {
        const _this = this;
        const def = _this.def;
        const state = _this.state;
        const elements = _this.elements;
        const $container = elements.container;
        $container.empty();
        const eb = new ElementBuilder();
        const $label = jqNode("div", { class: eClass.calendarLabel });
        let $contents = null;
        if(state.mode === def.mode.s) {
            _this.createYear().paging();
            const getLabel = function() {
                const rate = def.pagePer * state.currentPage - 1;
                const maxYearPerPage = def.year.start + rate;
                const minYearPerPage = maxYearPerPage - (def.pagePer - 1);
                const label = [minYearPerPage, maxYearPerPage].join(SIGN.dash);
                return label;
            };
            const $labelText = jqNode("div");
            const $actions = jqNode("div");
            const $up = jqNode("div").addClass(eClass.calendarLabelEvent).append(eb.getFontAwesomeIcon(eIcon.chevronUp));
            const $down = jqNode("div").addClass(eClass.calendarLabelEvent).append(eb.getFontAwesomeIcon(eIcon.chevronDown));
            const initActions = function() {
                if(state.currentPage <= 1) $up.addClass(eClass.hide);
                else if(state.currentPage >= state.pages.length) $down.addClass(eClass.hide);
                else {
                    $up.removeClass(eClass.hide);
                    $down.removeClass(eClass.hide);
                }
                $labelText.text(getLabel());
            };
            initActions();
            $up.click(function() {
                _this.setPage(state.currentPage - 1).paging();
                initActions();
            });
            $down.click(function() {
                _this.setPage(state.currentPage + 1).paging();
                initActions();
            });
            eb.listAppend($label, [$labelText, eb.listAppend($actions, [$up, $down])]);
            $contents = _this.getYearElement();
        }
        else if(state.mode === def.mode.y) {
            const $labelText = jqNode("div").addClass(eClass.calendarLabelEvent);
            $labelText.click(function() {
                _this.setMode(def.mode.s);
                _this.build();
            });
            const $actions = jqNode("div");
            const $up = jqNode("div").addClass(eClass.calendarLabelEvent).append(eb.getFontAwesomeIcon(eIcon.chevronUp));
            const $down = jqNode("div").addClass(eClass.calendarLabelEvent).append(eb.getFontAwesomeIcon(eIcon.chevronDown));
            const initActions = function() {
                if(state.year <= def.year.start) $up.addClass(eClass.hide);
                else if(state.year >= def.year.end) $down.addClass(eClass.hide);
                else {
                    $up.removeClass(eClass.hide);
                    $down.removeClass(eClass.hide);
                }
                $labelText.text(state.year);
            };
            initActions();
            $up.click(function() {
                const year = String(Number(state.year) - 1);
                _this.setYear(year).build();
            });
            $down.click(function() {
                const year = String(Number(state.year) + 1);
                _this.setYear(year).build();
            });
            eb.listAppend($label, [$labelText, eb.listAppend($actions, [$up, $down])]);
            $contents = _this.createMonth().getMonthElement();
        }
        else {
            const $labelText = jqNode("div").addClass(eClass.calendarLabelEvent);
            $labelText.click(function() {
                _this.setMode(def.mode.y);
                _this.build();
            });
            const $actions = jqNode("div");
            const $up = jqNode("div").addClass(eClass.calendarLabelEvent).append(eb.getFontAwesomeIcon(eIcon.chevronUp));
            const $down = jqNode("div").addClass(eClass.calendarLabelEvent).append(eb.getFontAwesomeIcon(eIcon.chevronDown));
            const initActions = function() {
                if(state.year <= def.year.start && Number(state.month) <= def.month.start + 1) $up.addClass(eClass.hide);
                else if(state.year >= def.year.end && Number(state.month) >= def.month.end + 1) $down.addClass(eClass.hide);
                else {
                    $up.removeClass(eClass.hide);
                    $down.removeClass(eClass.hide);
                }
                const label = [state.year, state.month].join(SIGN.ssh);
                $labelText.text(label);
            };
            initActions();
            $up.click(function() {
                const systemDate = new Date(state.year, Number(state.month) - 2, 1);
                const year = String(systemDate.getFullYear());
                const month = setCharPadding(systemDate.getMonth() + 1, 2);
                _this.setYear(year).setMonth(month).build();
            });
            $down.click(function() {
                const systemDate = new Date(state.year, Number(state.month), 1);
                const year = String(systemDate.getFullYear());
                const month = setCharPadding(systemDate.getMonth() + 1, 2);
                _this.setYear(year).setMonth(month).build();
            });
            eb.listAppend($label, [$labelText, eb.listAppend($actions, [$up, $down])]);
            $contents = _this.createCalendarApi().getCalendar();
        }
        eb.listAppend($container, [$label, $contents]);
        return this;
    },
    getContents: function() {
        return this.elements.container;
    },
    getDateStamp: function() {
        const state = this.state;
        return [state.year, state.month, state.date].join(SIGN.ssh);
    }
};

const Viewer = function() {
    this.viewer = jqNode("div", { id: eId.viewerContainer });
    this.title = null;
    this.contents = null;
    this.tools = new Array();
    this.executerVisible = true;
    this.done = null;
};
Viewer.prototype = {
    setContents: function(title, contents) {
        this.title = title;
        this.contents = contents;
        return this;
    },
    setTools: function() {
        const argumentsList = Array.prototype.slice.call(arguments);
        this.tools = argumentsList;
        return this;
    },
    hideExecuter: function() {
        this.executerVisible = false;
        return this;
    },
    open: function(callback) {
        const _this = this;
        const eb = new ElementBuilder();
        const $header = jqNode("div", { class: eClass.viewerHeader });
        const $headerWrapper = jqNode("div", { class: eClass.viewerHeaderWrapper });
        const $headerContext = jqNode("div", { class: eClass.viewerHeaderContext });
        const $closer = jqNode("div", { class: eClass.viewerHeaderCloser }).append(eb.getFontAwesomeIcon(eIcon.arrowLeft));
        $closer.click(function() { _this.close(); });
        const $title = jqNode("div", { class: eClass.viewerHeaderTitle }).text(_this.title);
        eb.listAppend($headerContext, [$closer, $title]);
        const $headerTools = jqNode("div", { class: eClass.viewerHeaderTools });
        const getToolsItem = function(item) {
            const $toolsItem = jqNode("div", { class: eClass.viewerToolsItem });
            $toolsItem.append(item);
            return $toolsItem;
        };
        if(_this.executerVisible) {
            const $executer = jqNode("div", { class: eClass.toolsItemDone }).text(upperCase(CAPTIONS.done));
            const close = function() { _this.close(); };
            $executer.click(function() {
                if(typeIs(callback).function) callback(close);
            });
            _this.tools.unshift($executer);
        }
        _this.tools.forEach(function(item) {
            $headerTools.append(getToolsItem(item));
        });
        eb.listAppend($headerWrapper, [$headerContext, $headerTools]);
        $header.append($headerWrapper);
        const $contentsWrapper = jqNode("div", { class: eClass.viewerContentsWrapper });
        const $overflowContainer = jqNode("div", { class: eClass.overflowContainer });
        const $contents = jqNode("div", { class: eClass.overflowContents }).append(_this.contents);
        $overflowContainer.append($contents).appendTo($contentsWrapper);
        eb.listAppend(_this.viewer, [$header, $contentsWrapper]);
        jqByTag("body").append(_this.viewer);

        const headerToolsSize = $headerTools.width();
        $headerContext.css({ width: "calc(100% - " + Math.ceil(headerToolsSize) + "px)" });
        setTimeout(function() {
            _this.viewer.addClass(eClass.viewerVisible);
        });
        overflowHide();
        return this;
    },
    close: function() {
        const _this = this;
        _this.viewer.removeClass(eClass.viewerVisible);
        setTimeout(function() {
            _this.viewer.remove();
        }, 500);
        overflowShow();
        return null;
    },
    onLoad: function(func) {
        func();
        return null;
    }
};

const RegExpUtil = function(value) {
    this.value = value;
};
RegExpUtil.prototype = {
    isEnter: function() {
        const regExp = /\r\n|\n/;
        return regExp.test(this.value);
    },
    isNumber: function() {
        const regExp = /^\d*$/;
        return !isVoid(this.value) && regExp.test(this.value);
    },
    isNumberWithFullWidth: function() {
        const regExp = /^[0-9０-９]*$/;
        return regExp.test(this.value);
    },
    isNumberWithLineBreak: function() {
        const regExp = /^[\n0-9]*$/;
        return regExp.test(this.value);
    },
    isOverflow: function(size) {
        return this.value.length > size;
    },
    isYYYYMMDD: function() {
        const regExp = new RegExp("^((19|20|21)[0-9]{2})((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|([3][0-1]))$", "g");
        return regExp.test(this.value);
    },
    isNot: function(regExp) {
        return !regExp.test(this.value);
    },
    includeSpace: function() {
        const regExp = new RegExp(" |　", "g");
        return regExp.test(this.value);
    }
};

const Validation = function() {
    this.types = {
        required: "required",
        requiredWithLineBreak: "requiredWithLineBreak",
        notSpace: "notSpace",
        numeric: "numeric",
        numericWithLineBreak: "numericWithLineBreak",
        size: "size"
    };
    this.checkList = new Array();
    this.transfer = {
        size: new Object()
    };
    this.state = {
        error: false,
        message: new Array()
    };
};
Validation.prototype = {
    getTypes: function() {
        return this.types;
    },
    initLayout: function(value, label, bind) {
        const layout = {
            value: value,
            label: label,
            types: new Array(),
            actions: new Object(),
            bind: bind
        };
        return layout;
    },
    getLayout: function(initData, types, actions) {
        const layout = initData;
        layout.types = types;
        if(actions) layout.actions = actions;
        return layout;
    },
    getActionLayout: function() {
        const layout = {
            error: false,
            message: SIGN.none
        };
        return layout;
    },
    getSizeLayout: function(min, max, separator) {
        const layout = {
            size: {
                min: min ? min : 0,
                max: max ? max : 1000,
                separator: separator
            }
        };
        return layout;
    },
    getMessage: function(type, label, bind) {
        const types = this.types;
        let message = SIGN.none;
        switch(type) {
            case types.required: {
                message = concatString(label, " is required");
                break;
            }
            case types.requiredWithLineBreak: {
                message = concatString(label, " is required");
                break;
            }
            case types.notSpace: {
                message = concatString(label, " : Space is not allowed");
                break;
            }
            case types.numeric: {
                message = concatString(label, " : ", MESSAGES.allowedOnlyNumeric);
                break;
            }
            case types.numericWithLineBreak: {
                message = concatString(label, " : ", MESSAGES.allowedOnlyNumeric);
                break;
            }
            case types.size: {
                const sizeObj = accessObject(bind, ["size"]);
                if(!isVoid(sizeObj)) {
                    message = concatString(label, " : Invalid size ", SIGN.bs, "min:", sizeObj.min, SIGN.c, SIGN.ws, "max:", sizeObj.max ,SIGN.be);
                }
                break;
            }
        }
        return message;
    },
    check: function(type, value, bind) {
        const types = this.types;
        let result = true;
        switch(type) {
            case types.required: {
                if(!value) {
                    result = false;
                }
                break;
            }
            case types.requiredWithLineBreak: {
                if(!value || isVoid(getExistArray(value.split(SIGN.nl)))) {
                    result = false;
                }
                break;
            }
            case types.notSpace: {
                if(new RegExpUtil(value).includeSpace()) {
                    result = false;
                }
                break;
            }
            case types.numeric: {
                if(!new RegExpUtil(value).isNumber()) {
                    result = false;
                }
                break;
            }
            case types.numericWithLineBreak: {
                if(!new RegExpUtil(value).isNumberWithLineBreak()) {
                    result = false;
                }
                break;
            }
            case types.size: {
                const sizeObj = accessObject(bind, ["size"]);
                if(!isVoid(sizeObj)) {
                    if(!isVoid(sizeObj.separator)) {
                        getExistArray(value.split(sizeObj.separator)).some(function(v) {
                            if(v.length < sizeObj.min || v.length > sizeObj.max) {
                                result = false;
                                return true;
                            }
                        });
                    }
                    else if(value.length < sizeObj.min || value.length > sizeObj.max) {
                        result = false;
                    }
                }
                break;
            }
        }
        return result;
    },
    reset: function() {
        this.checkList = new Array();
        return this;
    },
    append: function(layoutData) {
        this.checkList.push(layoutData);
        return this;
    },
    appendList: function(list) {
        this.checkList = this.checkList.concat(list);
        return this;
    },
    exec: function() {
        const _this = this;
        const state = _this.state;
        state.error = false;
        state.message = new Array();
        _this.checkList.forEach(function(layout) {
            const value = layout.value;
            const label = layout.label;
            const types = layout.types;
            const actions = layout.actions;
            const bind = layout.bind;
            if(types.indexOf(_this.types.required) < 0 && types.indexOf(_this.types.requiredWithLineBreak) < 0 && isVoid(value)) return;
            types.some(function(type) {
                const action = getProperty(actions, type);
                if(action && typeIs(action).function) {
                    const result = action(layout);
                    if(result.error) {
                        state.error = true;
                        state.message.push(result.message);
                        return true;
                    }
                }
                else {
                    const result = _this.check(type, value, bind);
                    if(!result) {
                        const message = _this.getMessage(type, label, bind);
                        state.error = true;
                        state.message.push(message);
                        return true;
                    }
                }
            });
        });
        if(state.error) state.message = state.message.join(SIGN.br);
        return state;
    },
    balanceCheck: function() {
        const _this = this;
        const state = _this.state;
        state.error = false;
        state.message = new Array();
        const labels = _this.checkList.map(function(item) { return item.label; });
        let baseSize = 0;
        _this.checkList.some(function(item, i) {
            const valueArray = getExistArray(item.value.split(SIGN.nl));
            const size = valueArray.length;
            if(i === 0) {
                baseSize = size;
                return false;
            }
            else if(baseSize !== size) {
                state.error = true;
                return true;
            }
        });
        if(state.error) {
            state.message = concatString(labels.join(SIGN.cw), " : Different value size");
        }
        return state;
    }
};

const Encoder = function(data) {
    this.data = data;
    this.converted = null;
};
Encoder.prototype = {
    SJISArrayBufferToString: function() {
        const codes = new Uint8Array(this.data);
        const encoding = Encoding.detect(codes);
        const unicodeString = Encoding.convert(codes, { to: "unicode", from: encoding, type: "string" });
        return unicodeString;
    }
};

function getToday() {
    const d = new Date();
    const year = String(d.getFullYear());
    const month = setCharPadding(String(d.getMonth() + 1), 2);
    const date = setCharPadding(String(d.getDate()), 2);
    const hours = setCharPadding(String(d.getHours()), 2);
    const minutes = setCharPadding(String(d.getMinutes()), 2);
    const seconds = setCharPadding(String(d.getSeconds()), 2);
    const milliseconds = setCharPadding(String(d.getMilliseconds()), 3);
    return {
        year: year,
        month: month,
        date: date,
        hours: hours,
        minutes: minutes,
        seconds: seconds,
        milliseconds: milliseconds
    };
};

function getSystemDate() {
    const d = new Date();
    const year = String(d.getFullYear());
    const month = setCharPadding(String(d.getMonth() + 1), 2);
    const date = setCharPadding(String(d.getDate()), 2);
    return concatString(year, month, date);
};

function getSystemDateTime(dateSep, timeSep) {
    const ds = dateSep ? dateSep : SIGN.ssh;
    const ts = timeSep ? timeSep : SIGN.gc;
    const d = new Date();
    const year = String(d.getFullYear());
    const month = setCharPadding(String(d.getMonth() + 1), 2);
    const date = setCharPadding(String(d.getDate()), 2);
    const hours = setCharPadding(String(d.getHours()), 2);
    const minutes = setCharPadding(String(d.getMinutes()), 2);
    const seconds = setCharPadding(String(d.getSeconds()), 2);
    const fullDate = [year, month, date].join(ds);
    const fullTime = [hours, minutes, seconds].join(ts);
    return [fullDate, fullTime].join(SIGN.ws);
};

function getSystemDateTimeMilliseconds(dateSep, timeSep) {
    const ds = dateSep ? dateSep : SIGN.ssh;
    const ts = timeSep ? timeSep : SIGN.gc;
    const d = new Date();
    const year = String(d.getFullYear());
    const month = setCharPadding(String(d.getMonth() + 1), 2);
    const date = setCharPadding(String(d.getDate()), 2);
    const hours = setCharPadding(String(d.getHours()), 2);
    const minutes = setCharPadding(String(d.getMinutes()), 2);
    const seconds = setCharPadding(String(d.getSeconds()), 2);
    const milliseconds = String(d.getMilliseconds());
    const fullDate = [year, month, date].join(ds);
    const fullTime = concatString([hours, minutes, seconds].join(ts), ".", milliseconds);
    return [fullDate, fullTime].join(SIGN.ws);
};

const DateUtil = function(year, month, date, hours, minutes, seconds, milliseconds) {
    this.data = {
        year: year,
        month: month,
        date: date,
        hours: hours,
        minutes: minutes,
        seconds: seconds,
        milliseconds: milliseconds ? milliseconds : 0
    };
    this.format = {
        type1: function(o) {
            const ymd = [o.year, setCharPadding(o.month, 2), setCharPadding(o.date, 2)].join(SIGN.ssh);
            const hms = [setCharPadding(o.hours, 2), setCharPadding(o.minutes, 2), setCharPadding(o.seconds, 2)].join(SIGN.gc);
            return concatString(ymd, SIGN.ws, hms);
        },
        type2: function(o) {
            const m = [o.month, o.date, o.hours, o.minutes, o.seconds].map(function(item) {
                return setCharPadding(item, 2);
            });
            return concatString(o.year, m.join(SIGN.none));
        },
        dateParam: function(o) {
            return {
                year: o.year,
                month: setCharPadding(Number(o.month) - 1, 2),
                date: setCharPadding(o.date, 2),
                hours: setCharPadding(o.hours, 2),
                minutes: setCharPadding(o.minutes, 2),
                seconds: setCharPadding(o.seconds, 2),
                milliseconds: setCharPadding(o.milliseconds, 3)
            };
        },
        joinAll: function(o) {
            const m = [o.month, o.date, o.hours, o.minutes, o.seconds].map(function(item) {
                return setCharPadding(item, 2);
            });
            const ms = setCharPadding(o.milliseconds, 3);
            return concatString(o.year, m.join(SIGN.none), ms);
        }
    };
};
DateUtil.prototype = {
    init: function(format) {
        return new Date(format);
    },
    initParam: function(o) {
        return new Date(o.year, o.month, o.date, o.hours, o.minutes, o.seconds, o.milliseconds);
    },
    setDateObject: function(o) {
        this.data.year = o.year;
        this.data.month = o.month;
        this.data.date = o.date;
        this.data.hours = o.hours;
        this.data.minutes = o.minutes;
        this.data.seconds = o.seconds;
        this.data.milliseconds = o.milliseconds ? o.milliseconds : 0;
        return this;
    },
    getDateObject: function(d) {
        return {
            year: d.getFullYear(),
            month: d.getMonth() + 1,
            date: d.getDate(),
            hours: d.getHours(),
            minutes: d.getMinutes(),
            seconds: d.getSeconds(),
            milliseconds: d.getMilliseconds()
        };
    },
    calcDate: function(calcObj) {
        const d = this.initParam(this.format.dateParam(this.data));
        const cYear = calcObj.year ? calcObj.yaer : 0;
        const cMonth = calcObj.month ? calcObj.month : 0;
        const cDate = calcObj.date ? calcObj.date : 0;
        const cHours = calcObj.hours ? calcObj.hours : 0;
        const cMinutes = calcObj.minutes ? calcObj.minutes : 0;
        const cSeconds = calcObj.seconds ? calcObj.seconds : 0;
        const cMilliseconds = calcObj.milliseconds ? calcObj.milliseconds : 0;
        d.setFullYear(d.getFullYear() + cYear);
        d.setMonth(d.getMonth() + cMonth);
        d.setDate(d.getDate() + cDate);
        d.setHours(d.getHours() + cHours);
        d.setMinutes(d.getMinutes() + cMinutes);
        d.setSeconds(d.getSeconds() + cSeconds);
        d.setMilliseconds(d.getMilliseconds() + cMilliseconds);
        return this.getDateObject(d);
    }
};

const StringBuilder = function() {
    this.str = SIGN.none;
    this.strList = new Array();
    this.partition = SIGN.none;
};
StringBuilder.prototype = {
    sq: function(v) {
        return concatString(SIGN.sq, v, SIGN.sq);
    },
    dq: function(v) {
        return concatString(SIGN.dq, v, SIGN.dq)
    },
    setAround: function(v, s) {
        return concatString(s, v, s);
    },
    setBrackets: function(v) {
        return concatString(SIGN.bs, v, SIGN.be);
    },
    equalSameCase: function(a, b) {
        return lowerCase(String(a)) === lowerCase(String(b));
    },
    setQuery: function(list) {
        return list.join(SIGN.ws);
    },
    reset: function() {
        this.str = SIGN.none;
        this.strList = new Array();
        return this;
    },
    copy: function(v, c) {
        const list = new Array();
        for(let i = 0; i < c; i++) {
            list.push(v);
        }
        return list.join(SIGN.none);
    },
    push: function(v) {
        this.strList.push(v);
        return this;
    },
    setList: function(list) {
        this.strList = list;
        return this;
    },
    setPartition: function(p) {
        this.partition = p;
        return this;
    },
    get: function() {
        return this.strList.join(this.partition);
    }
};

const PromiseUtil = function() {
    this.task = new Array();
    this.recursiveTask = new Array();
};
PromiseUtil.prototype = {
    init: function() {
        this.task = new Array();
        return this;
    },
    push: function(exec) {
        this.task.push(exec);
        return this;
    },
    appendToRecursiveTask: function(idx, per, arry) {
        if((isVoid(idx) && isVoid(per) && isVoid(arry)) || (((idx + 1) % per === 0) || ((idx + 1) === arry.length))) {
            this.recursiveTask.push(this.task);
            this.init();
        }
        return this;
    },
    executeAll: function(successFunc, errorFunc) {
        Promise.all(this.task.map(function(exec) {
            return new Promise(function(resolve, reject) {
                return resolve(exec());
            });
        })).then(function(res) {
            successFunc(res);
        }).catch(function(e) {
            errorFunc(e);
        });
    },
    recursiveAll: function(successFunc, errorFunc) {
        const _this = this;
        const recursive = function(arry) {
            /** phase start */
            Promise.all(arry.map(function(exec) {
                return new Promise(function(resolve, reject) {
                    return resolve(exec());
                });
            })).then(function(res) {
                _this.recursiveTask.shift();
                if(_this.recursiveTask.length <= 0) {
                    /** all phases end */
                    successFunc(res);
                }
                else {
                    /** phase end */
                    recursive(_this.recursiveTask[0]);
                }
            }).catch(function(e) {
                /** phase on error */
                errorFunc(e);
            });
        }
        recursive(_this.recursiveTask[0]);
        return null;
    }
};

const ExcelUtil = function() {
    this.def = {
        execTypes: {
            read: "read"
        }
    };
    this.workbook = null;
    this.sheetNames = new Array();
    this.readExec = null;
    this.execType = null;
};
ExcelUtil.prototype = {
    getWorkbook: function() {
        return this.workbook;
    },
    getSheetNames: function() {
        const _this = this;
        if(!isVoid(_this.workbook)) {
            _this.workbook.SheetNames.forEach(function(sheetName) {
                _this.sheetNames.push(sheetName);
            });
        }
        return _this.sheetNames;
    },
    getRange: function(ws) {
        const ref = ws["!ref"];
        const range = XLSX.utils.decode_range(ref);
        return {
            c: { s: range.s.c, e: range.e.c },
            r: { s: range.s.r, e: range.e.r }
        };
    },
    getCellData: function(ws, ref) {
        const cell = ws[ref];
        const v = isVoid(cell) ? SIGN.none : cell.v;
        return v;
    },
    sheetToCsv: function(ws, option) {
        let csvData = SIGN.none;
        if(isVoid(option)) {
            csvData = XLSX.utils.sheet_to_csv(ws);
        }
        else {
            /** option: { FS: ",", RS: "\n" } */
            csvData = XLSX.utils.sheet_to_csv(ws, option);
        }
        return csvData;
    },
    readAsBinary: function() {
        const _this = this;
        const mime = TYPES.file.mime;
        _this.readExec = function(func) {
            function onReadFile(data, path, fileInfo) {
                const binary = getBinary(data);
                _this.workbook = XLSX.read(binary, { type: TYPES.file.contentType.binary, cellDates: true, cellStyles: true });
                func(_this, fileInfo);
            };
            new FileController()
            .setListener()
            .setReadType(TYPES.file.readType.arrayBuffer)
            .allowedExtensions([mime.MS_EXCEL, mime.SP_SHEET])
            .access(onReadFile);
        };
        _this.execType = _this.def.execTypes.read;
        return this;
    },
    onload: function(func) {
        if(typeIs(func).function) {
            switch(this.execType) {
                case this.def.execTypes.read: {
                    this.readExec(func);
                    break;
                }
            }
        }
        return null;
    }
};

const BinaryUtil = function() {};
BinaryUtil.prototype = {
    encode: (function(i, tbl) {
        for(i = 0, tbl = { 64: 61, 63: 47, 62: 43 }; i < 62; i++) {
            tbl[i] = i < 26 ? i + 65 : (i < 52 ? i + 71 : i - 4);
        }
        return function(arr) {
            let len, str, buf;
            if (!arr || !arr.length) {
                return "";
            }
            for (i = 0, len = arr.length, buf = [], str = ""; i < len; i += 3) {
                str += String.fromCharCode(tbl[arr[i] >>> 2], tbl[(arr[i] & 3) << 4 | arr[i + 1] >>> 4], tbl[i + 1 < len ? (arr[i + 1] & 15) << 2 | arr[i + 2] >>> 6 : 64], tbl[i + 2 < len ? (arr[i + 2] & 63) : 64]);
            }
            return str;
        };
    }()),
    decode: (function(i, tbl) {
        for (i = 0, tbl = { 61: 64, 47: 63, 43: 62 }; i < 62; i++) {
            tbl[i < 26 ? i + 65 : (i < 52 ? i + 71 : i - 4)] = i;
        }
        return function(str) {
            let j, len, arr, buf;
            if (!str || !str.length) {
                return [];
            }
            for (i = 0, len = str.length, arr = [], buf = []; i < len; i += 4) {
                for (j = 0; j < 4; j++) {
                    buf[j] = tbl[str.charCodeAt(i + j) || 0];
                }
                arr.push(buf[0] << 2 | (buf[1] & 63) >>> 4, (buf[1] & 15) << 4 | (buf[2] & 63) >>> 2, (buf[2] & 3) << 6 | buf[3] & 63);
            }
            if (buf[3] === 64) {
                arr.pop();
                if (buf[2] === 64) {
                    arr.pop();
                }
            }
            return arr;
        };
    }()),
    arrayBufferToBase64: function(arrayBuffer) {
        return this.encode(new Uint8Array(arrayBuffer));
    },
    base64ToArrayBuffer: function(base64) {
        const binary_string = window.atob(base64);
        const len = binary_string.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binary_string.charCodeAt(i);
        }
        return bytes.buffer;
    },
    stringToArrayBuffer: function(str) {
        return (new Uint16Array([].map.call(str, function(c) {
            return c.charCodeAt(0)
        }))).buffer;
    },
    stringToUnicodeList: function(str) {
        const unicodeList = new Array();
        for (let i = 0; i < str.length; i++) {
            unicodeList.push(str.charCodeAt(i));
        }
        return unicodeList;
    },
    arrayBufferToString: function(buf) {
        return String.fromCharCode.apply("", new Uint16Array(buf));
    },
    arrayBufferToStringL: function(buf) {
        const tmp = [];
        const len = 1024;
        for (let p = 0; p < buf.byteLength; p += len) {
            tmp.push(this.arrayBufferToString(buf.slice(p, p + len)));
        }
        return tmp.join("");
    }
};

const StringBuffer = function() {
    this.buffer = new Array();
};
StringBuffer.prototype = {
    append: function(str) {
        this.buffer.push(str);
        return this;
    },
    toString: function(sep) {
        const data = this.buffer.join(!isVoid(sep) ? sep : SIGN.none);
        return data;
    },
    toStringWithLine: function() {
        const data = this.buffer.join(SIGN.crlf);
        return data;
    }
};

const ArrayUtil = function() {};
ArrayUtil.prototype = {
    getIEOptionLayout: function() {
        return {
            isSameCase: false
        };
    },
    getIncludeListFrom2Array: function(actionArray, diffArray, option) {
        const _this = this;
        return actionArray.filter(function(item) {
            if(!isVoid(option)) {
                if(option.isSameCase) {
                    return _this.getUpperCaseMap(diffArray).indexOf(upperCase(item)) >= 0;
                }
            }
            else {
                return diffArray.indexOf(item) >= 0;
            }
        });
    },
    getExcludeListFrom2Array: function(actionArray, diffArray, option) {
        const _this = this;
        return actionArray.filter(function(item) {
            if(!isVoid(option)) {
                if(option.isSameCase) {
                    return _this.getUpperCaseMap(diffArray).indexOf(upperCase(item)) < 0;
                }
            }
            else {
                return diffArray.indexOf(item) < 0;
            }
        });
    },
    getUpperCaseMap: function(list) {
        return list.map(mapUpperCase);
    },
    getLowerCaseMap: function(list) {
        return list.map(mapLowerCase);
    }
};

const SpreadSheet = function() {
    this.spreadSheet = null;
    this.grid = null;
    this.settings = {
        rowHeaders: true,
        colHeaders: true,
        width: 950,
        height: 272,
        contextMenu: true,
        renderAllRows: false,
        autoWrapRow: false,
        columnSorting: false,
        sortIndicator: false,
        manualColumnMove: true,
        manualColumnResize: true,
//        afterGetRowHeader: function (col, TH) { TH.className = set class },
//        startCols: cols,
//        startRows: rows,
//        maxCols: cols,
//        maxRows: rows,
//        autoColumnSize: true,
//        autoRowSize: false,
//        stretchH: 'all',
        data: [],
        licenseKey:'non-commercial-and-evaluation'
    };
};
SpreadSheet.prototype = {
    setGrid: function(grid) {
        this.grid = grid;
        return this;
    },
    setData: function(data) {
        this.settings.data = data;
        return this;
    },
    updateSettings: function(settings) {
        const _this = this;
        if(!isVoid(settings) && typeIs(settings).object) {
            Object.keys(settings).forEach(function(key) {
                if(key === "data") return;
                _this.settings[key] = settings[key];
            });
        }
        return this;
    },
    create: function() {
        this.spreadSheet = new Handsontable(this.grid, this.settings);
        return this;
    },
    destroy: function() {
        if (!isVoid(this.spreadSheet)) {
            this.spreadSheet.destroy();
            this.spreadSheet = void 0;
        }
        return this;
    },
    getDefaultData: function(rowSize, colSize) {
        const data = new Array();
        getIterator(rowSize).forEach(function() {
            const row = new Array();
            getIterator(colSize).forEach(function() {
                row.push(null);
            });
            data.push(row);
        });
        return data;
    },
    getValidCount: function(data) {
        const lastColIdxColletion = new Array();
        let validRowIdx = -1;
        data.forEach(function(row, i) {
            let validCellIdx = -1;
            row.forEach(function(cell, j) {
                if(cell) {
                    validCellIdx = j;
                }
            });
            lastColIdxColletion.push(validCellIdx);
            if(validCellIdx >= 0) {
                validRowIdx = i;
            }
        });
        const lastColIdx = !isVoid(lastColIdxColletion) ? getMaxNumInArray(lastColIdxColletion) : -1;
        const lastRowIdx = validRowIdx;
        return {
            rowCount: lastRowIdx,
            colCount: lastColIdx
        };
    },
    getValidData: function(data) {
        const range = this.getValidCount(data);
        const validData = new Array();
        for(let i = 0; i <= range.rowCount; i++) {
            const rowData = new Array();
            for(let j = 0; j <= range.colCount; j++) {
                rowData.push(data[i][j]);
            }
            validData.push(rowData);
        }
        return validData;
    },
    getCsvData: function(data, doubleQuote) {
        const sb = new StringBuilder();
        const range = this.getValidCount(data);
        const csvData = new Array;
        for(let i = 0; i <= range.rowCount; i++) {
            const rowData = new Array();
            for(let j = 0; j <= range.colCount; j++) {
                const setData = doubleQuote ? sb.dq(data[i][j]) : data[i][j];
                rowData.push(setData);
            }
            csvData.push(rowData.join(SIGN.c));
        }
        return csvData.join(SIGN.crlf);
    }
};

const Binder = function(data) {
    this.data = data;
    this.variables = new Object();
};
Binder.prototype = {
    getBind: function(key) {
        const bind = concatString("\\$\\{", key, "\\}");
        return bind;
    },
    getBindSameCase: function(key) {
        const caseExp = concatString(SIGN.bs, upperCase(key), "|", lowerCase(key), SIGN.be);
        const bind = concatString("\\$\\{", caseExp, "\\}");
        return bind;
    },
    setVariables: function(keys, values) {
        const _this = this;
        keys.forEach(function(key, i) {
            _this.variables[key] = values[i];
        });
        return this;
    },
    convert: function(keys, values) {
        const _this = this;
        const variables = this.variables;
        let cData = this.data;
        Object.keys(variables).forEach(function(key, i) {
            const bind = _this.getBind(key);
            const regExp = new RegExp(bind, "g");
            cData = cData.replace(regExp, variables[key]);
        });
        this.variables = new Object();
        return cData;
    },
    convertSameCase: function(keys, values) {
        const _this = this;
        const variables = this.variables;
        let cData = this.data;
        Object.keys(variables).forEach(function(key, i) {
            const bind = _this.getBindSameCase(key);
            const regExp = new RegExp(bind, "g");
            cData = cData.replace(regExp, variables[key]);
        });
        this.variables = new Object();
        return cData;
    }
};
