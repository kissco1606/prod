﻿$(function () {
    init();
});