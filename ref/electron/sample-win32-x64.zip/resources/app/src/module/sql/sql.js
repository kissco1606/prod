﻿const SqlModule = function() {
    this.Define = {
        ELEMENTS: {
            id: {
                accessPage: "access-page",
                accessLogo: "access-logo",
                accessCommand: "access-command",
                sid: "sid",
                uid: "uid",
                pwd: "pwd",
                sqlHeader: "sql-header",
                sqlContents: "sql-contents",
                sqlMenuContainer: "sql-menu-container",
                headerToolsConfigIcon: "header-tools-config-icon",
                applicationPage: "application-page",
                queryCommandCard: "query-command-card",
                dataCopyCard: "data-copy-card",
                deleteDataCard: "delete-data-card",
                createUserCard: "create-user-card",
                lincErrorResolutionCard: "linc-error-resolution-card",
                exportTableCard: "export-table-card",
                importTableCard: "import-table-card",
                policyNumberFrom: "policy-number__from",
                policyNumberFromTextarea: "policy-number__from__textarea",
                policyNumberTo: "policy-number-to",
                subSid: "sub-sid",
                subUid: "sub-uid",
                subPwd: "sub-pwd",
                optionContainerDataCopy: "option-container__data-copy",
                userCode: "user-code",
                userName: "user-name",
                queryEditor: "query-editor",
                queryGridTabs: "query-grid-tabs",
                queryGridContents: "query-grid-contents",
                tab: "tab",
                queryTabs: "query-tabs",
                dataGrid: "data-grid",
                queryTimer: "query-timer",
                lincPolicyNumber: "linc-policy-number",
                exportButtonQueryCommand: "export-button__query-command",
                exportContainerQueryCommand: "export-container__query-command",
                optionTemplateNB: "option-template__nb",
                exportTableTables: "export-table__tables",
                importTableTables: "import-table__tables",
                queryCommand: {
                    setSid: "query-command__set-sid",
                    setUid: "query-command__set-uid",
                    setPwd: "query-command__set-pwd",
                    consoleName: "query-commnad__export__console-name"
                },
                queryTestCard: "query-test-card",
                queryTest: {
                    variableQuery: "query-test__variable-query",
                    execQuery: "query-test__exec-query",
                    result: "query-test__result"
                }
            },
            class: {
                commandLine: "command-line",
                accessButton: "access-button",
                accessLoadButton: "access-load-button",
                contentsContainer: "contents-container",
                commandArea: "command-area",
                editorCommandArea: "editor-command-area",
                actionArea: "action-area",
                viewArea: "view-area",
                optionCommandArea: "option-command-area",
                optionRemoveButton: "option-remove-button",
                commandLineRow: "command-line-row",
                removeRow: "remove-row",
                queryEditorTextInput: "ace_text-input",
                queryGridContainer: "query-grid-container",
                dataGrid: "data-grid",
                queryCommandExportCommandArea: "export-container__query-command-area",
                optionTemplateContainer: "option-template-container",
                optionTemplatePannel: "option-template-pannel",
                optionTemplateClose: "option-template-close",
                optionTemplateTab: "option-template-tab"
            },
            src: {
                cloudgs_dbaas: "src/assets/cloudgs_dbaas.png"
            },
            style: {
                backgroundColor: "#333",
                headerHeight: "50px",
                transitionDuration: 200
            }
        },
        CAPTIONS: {
            title: "SQL Management",
            sid: "SID",
            uid: "USER ID",
            pwd: "PASSWORD",
            queryCommand: "Query Command",
            dataCopy: "Data Copy",
            deleteData: "Delete Data",
            createUser: "Create User",
            lincErrorResolution: "Linc Error Resolution",
            exportTableTitle: "Export Table",
            importTableTitle: "Import Table",
            access: "access",
            exec: "exec",
            cancel: "cancel",
            tab: "tab",
            console: "console",
            check: "check",
            extract: "extract",
            import: "import",
            export: "export",
            template: "template",
            insert: "insert",
            commit: "commit",
            rollback: "rollback",
            delReq: "del_required",
            backup: "backup",
            option: "option",
            reset: "reset",
            back: "back",
            log: "log",
            setSid: "sid",
            setUid: "uid",
            setPwd: "pwd",
            subSid: "SID(From)",
            subUid: "UID(From)",
            subPwd: "PWD(From)",
            policyNumber: "Policy Number",
            policyNumberFrom: "Policy Number(From)",
            policyNumberTo: "Policy Number(To)",
            userCode: "User Code",
            userName: "User Name",
            create: "create",
            delete: "delete",
            exportType: "Export Type",
            consoleNameLabel: "Console Name",
            accessList: "Access List",
            add: "add",
            edit: "edit",
            name: "name",
            load: "load",
            birthday: "birthday",
            id: "id",
            extractMode: "Extract Mode",
            extractGroup: "Extract Group",
            single: "single",
            multiple: "multiple",
            skei: "skei",
            kkanri: "kkanri",
            hksiharai: "hksiharai",
            iwf: "iwf",
            deleteMode: "Delete Mode",
            deleteGroup: "Delete Group",
            include: "include",
            exclude: "exclude",
            customize: "customize",
            all: "all",
            none: "none",
            inherit: "inherit",
            path: "path",
            tables: "tables",
            read: "read",
            clear: "clear",
            query: "query",
            saveQuery: "save query",
            setting: "setting",
            queryTest: {
                title: "Query Test",
                variableQueryLabel: "Variable Query",
                execQueryLabel: "Exec Query",
                resultLabel: "Result"
            }
        },
        TYPES: {
            toolId: {
                queryCommand: "queryCommand",
                dataCopy: "dataCopy",
                deleteData: "deleteData",
                createUser: "createUser",
                lincErrorResolution: "lincErrorResolution",
                importTable: "importTable"
            },
            message: {
                required: "required",
                matchWhitespace: "match-whitespace"
            },
            page: {
                access: "access",
                application: "application"
            },
            phase: {
                queryCommand: {
                    executing: "executing",
                    complete: "complete"
                },
                dataCopy: {
                    import: "import",
                    insert: "insert",
                    commit: "commit",
                    complete: "complete"
                },
                deleteData: {
                    commit: "commit",
                    complete: "complete"
                },
                createUser: {
                    commit: "commit",
                    complete: "complete"
                },
                lincErrorResolution: {
                    commit: "commit",
                    complete: "complete"
                },
                importTable: {
                    import: "import",
                    commit: "commit",
                    complete: "complete"
                }
            },
            editor: {
                mode: {
                    sql: "ace/mode/sqlserver"
                },
                theme: {
                    monokai: "ace/theme/monokai",
                    terminal: "ace/theme/terminal",
                    twilight: "ace/theme/twilight"
                }
            },
            path: {
                export: "src/module/sql/export.json",
                worker: "src/module/sql/actions/worker.js"
            },
            action: {
                create: "create",
                delete: "delete"
            },
            export: {
                queryCommand: [
                    { label: "All", value: "all" },
                    { label: "All(without columns)", value: "all_without_columns" },
                    { label: "Separate by consoles", value: "separate_by_consoles" }
                ]
            },
            design: {
                dataCopy: {
                    extractMode: {
                        single: "single",
                        multiple: "multiple"
                    },
                    extractGroup: {
                        skei: "skei",
                        kkanri: "kkanri",
                        hksiharai: "hksiharai",
                        iwf: "iwf",
                        option: "option"
                    },
                    extractExecTypes: {
                        import: "import"
                    },
                    customize: {
                        all: "all",
                        none: "none",
                        inherit: "inherit"
                    }
                },
                deleteData: {
                    deleteMode: {
                        include: "include",
                        exclude: "exclude"
                    },
                    deleteGroup: {
                        skei: "skei",
                        kkanri: "kkanri",
                        hksiharai: "hksiharai",
                        iwf: "iwf",
                        option: "option"
                    },
                    option: {
                        delReq: "delReq",
                        backup: "backup"
                    }
                }
            }
        },
        MESSAGES: {
            locking_transaction: "Locking by other transaction",
            only_exec_select_query: "Can be excute only [SELECT] query",
            already_exits_name: "Already exists name"
        }
    };
    this.design = {
        dataCopy: {
            extractModeRadio: {
                name: "data-copy__extract-mode-radiobox",
                type: {
                    single: {
                        label: upperCase(this.Define.CAPTIONS.single, 0),
                        id: "data-copy__extract-mode-single",
                        value: this.Define.TYPES.design.dataCopy.extractMode.single,
                        isChecked: true
                    },
                    multiple: {
                        label: upperCase(this.Define.CAPTIONS.multiple, 0),
                        id: "data-copy__extract-mode-multiple",
                        value: this.Define.TYPES.design.dataCopy.extractMode.multiple,
                        isChecked: false
                    }
                }
            },
            extractGroupCheck: {
                name: "data-copy__extract-group-checkbox",
                type: {
                    skei: {
                        label: this.Define.CAPTIONS.skei,
                        id: "data-copy__extract-group-cb-skei",
                        value: this.Define.TYPES.design.dataCopy.extractGroup.skei,
                        isChecked: true
                    },
                    kkanri: {
                        label: this.Define.CAPTIONS.kkanri,
                        id: "data-copy__extract-group-cb-kkanri",
                        value: this.Define.TYPES.design.dataCopy.extractGroup.kkanri,
                        isChecked: false
                    },
                    hksiharai: {
                        label: this.Define.CAPTIONS.hksiharai,
                        id: "data-copy__extract-group-cb-hksiharai",
                        value: this.Define.TYPES.design.dataCopy.extractGroup.hksiharai,
                        isChecked: false
                    },
                    iwf: {
                        label: this.Define.CAPTIONS.iwf,
                        id: "data-copy__extract-group-cb-iwf",
                        value: this.Define.TYPES.design.dataCopy.extractGroup.iwf,
                        isChecked: false
                    }
                }
            },
            customizeRadio: {
                name: "data-copy__customize-radiobox",
                type: {
                    all: {
                        label: upperCase(this.Define.CAPTIONS.all, 0),
                        id: "data-copy__customize-all",
                        value: this.Define.TYPES.design.dataCopy.customize.all,
                        isChecked: true
                    },
                    none: {
                        label: upperCase(this.Define.CAPTIONS.none, 0),
                        id: "data-copy__customize-none",
                        value: this.Define.TYPES.design.dataCopy.customize.none,
                        isChecked: false
                    },
                    inherit: {
                        label: upperCase(this.Define.CAPTIONS.inherit, 0),
                        id: "data-copy__customize-inherit",
                        value: this.Define.TYPES.design.dataCopy.customize.inherit,
                        isChecked: false
                    }
                }
            }
        },
        deleteData: {
            deleteModeRadio: {
                name: "delete-data__delete-mode-radiobox",
                type: {
                    include: {
                        label: upperCase(this.Define.CAPTIONS.include, 0),
                        id: "delete-data__delete-mode-include",
                        value: this.Define.TYPES.design.deleteData.deleteMode.include,
                        isChecked: true
                    },
                    exclude: {
                        label: upperCase(this.Define.CAPTIONS.exclude, 0),
                        id: "delete-data__delete-mode-exclude",
                        value: this.Define.TYPES.design.deleteData.deleteMode.exclude,
                        isChecked: false
                    }
                }
            },
            deleteGroupCheck: {
                name: "delete-data__delete-group-checkbox",
                type: {
                    skei: {
                        label: this.Define.CAPTIONS.skei,
                        id: "delete-data__delete-group-cb-skei",
                        value: this.Define.TYPES.design.deleteData.deleteGroup.skei,
                        isChecked: true
                    },
                    kkanri: {
                        label: this.Define.CAPTIONS.kkanri,
                        id: "delete-data__delete-group-cb-kkanri",
                        value: this.Define.TYPES.design.deleteData.deleteGroup.kkanri,
                        isChecked: false
                    },
                    hksiharai: {
                        label: this.Define.CAPTIONS.hksiharai,
                        id: "delete-data__delete-group-cb-hksiharai",
                        value: this.Define.TYPES.design.deleteData.deleteGroup.hksiharai,
                        isChecked: false
                    },
                    iwf: {
                        label: this.Define.CAPTIONS.iwf,
                        id: "delete-data__delete-group-cb-iwf",
                        value: this.Define.TYPES.design.deleteData.deleteGroup.iwf,
                        isChecked: false
                    }
                }
            },
            optionCheck: {
                name: "delete-data__option-checkbox",
                type: {
                    delReq: {
                        label: this.Define.CAPTIONS.delReq,
                        id: "delete-data__option-cb-delReq",
                        value: this.Define.TYPES.design.deleteData.option.delReq,
                        isChecked: true
                    },
                    backup: {
                        label: this.Define.CAPTIONS.backup,
                        id: "delete-data__option-cb-backup",
                        value: this.Define.TYPES.design.deleteData.option.backup,
                        isChecked: false
                    }
                }
            }
        }
    };
    this.event = {
        dataCopy: {
            status: {
                extractMode: this.Define.TYPES.design.dataCopy.extractMode.single
            },
            element: {
                extractMode: concatString("input[name=", this.design.dataCopy.extractModeRadio.name, "]"),
                extractGroup: concatString("input[name=", this.design.dataCopy.extractGroupCheck.name, "]"),
                extractGroupChecked: concatString("input[name=", this.design.dataCopy.extractGroupCheck.name, "]:checked"),
                customizeRadio: concatString("input[name=", this.design.dataCopy.customizeRadio.name, "]"),
                customizeRadioChecked: concatString("input[name=", this.design.dataCopy.customizeRadio.name, "]:checked"),
                sid: null,
                uid: null,
                pwd: null,
                pnf: null,
                pnft: null,
                pnt: null
            },
            handler: {
               a: null
            },
            values: new Object()
        },
        deleteData: {
            element: {
                deleteMode: concatString("input[name=", this.design.deleteData.deleteModeRadio.name, "]"),
                deleteModeChecked: concatString("input[name=", this.design.deleteData.deleteModeRadio.name, "]:checked"),
                deleteGroup: concatString("input[name=", this.design.deleteData.deleteGroupCheck.name, "]"),
                deleteGroupChecked: concatString("input[name=", this.design.deleteData.deleteGroupCheck.name, "]:checked"),
                option: concatString("input[name=", this.design.deleteData.optionCheck.name, "]"),
                optionChecked: concatString("input[name=", this.design.deleteData.optionCheck.name, "]:checked"),
                pn: null
            }
        },
        createUser: {
            element: {
                userCode: null,
                userName: null
            }
        },
        lincErrorResolution: {
            element: {
                pn: null
            }
        }
    };
    this.state = {
        page: this.Define.TYPES.page.access,
        isConnecting: false,
        info: new Object(),
        lock: new Object(),
        queryCommand: {
            ui: new Object(),
            phase: null,
            timer: null,
            element: null,
            export: {
                data: null,
                type: this.Define.TYPES.export.queryCommand[0].value
            }
        },
        dataCopy: new Object(),
        deleteData: new Object(),
        createUser: new Object(),
        lincErrorResolution: new Object(),
        exportTable: new Object(),
        importTable: new Object(),
        queryTest: new Object(),
        worker: null
    };
    this.export = new Object();
};
SqlModule.prototype = {
    initSqlModule: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seSrc = _this.Define.ELEMENTS.src;
        const seStyle = _this.Define.ELEMENTS.style;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const $container = jqById(eId.container);
        $container.css({ "margin-top": seStyle.headerHeight, "background-color": seStyle.backgroundColor });
        const $header = jqNode("header", { id: getHeaderId() });
        const $contents = jqNode("div", { id: getContentsId() });
        const $headerTitle = jqNode("div", { id: eId.headerTitle });
        const $titleIcon = jqNode("i", { class: eIcon.database });
        const $titleIconSpan = jqNode("span", { id: eId.titleIcon }).append($titleIcon);
        const $titleTextSpan = jqNode("span", { id: eId.titleText }).text(captions.title);
        $headerTitle.append($titleIconSpan).append($titleTextSpan);
        const $headerTools = jqNode("div", { id: eId.headerTools });
        const $ellipsisVIconSpan = jqNode("span", { class: classes(eClass.toolsIcon, eClass.iconButton) }).append(jqNode("i", { class: eIcon.ellipsisV }));
        $ellipsisVIconSpan.click(function(e) {
            e.stopPropagation();
            _this.openMenu();
        });
        [$ellipsisVIconSpan].forEach(function(item) { $headerTools.append(item); });
        const $menuContainer = jqNode("div", { id: seId.sqlMenuContainer, class: eClass.menuContainer });
        [$headerTitle, $headerTools, $menuContainer].forEach(function(item) { $header.append(item); });
        const $screen = jqNode("div", { id: seId.accessPage, class: eClass.screen });
        const $logo = jqNode("div").append(jqNode("img", { id: seId.accessLogo, src: seSrc.cloudgs_dbaas }));
        const $command = _this.buildAccessCommand(jqNode("div", { id: seId.accessCommand }));
        $screen.append($logo).append($command);
        $contents.append($screen);
        [$header, $contents].forEach(function(item) { $container.append(item) });
        const titleIconSize = $titleIcon.width();
        const headerToolsSize = $headerTools.width();
        jqById(eId.titleIcon).css({ width: (Math.ceil(titleIconSize) + 2) + "px" });
        jqById(eId.headerTitle).css({ width: "calc(100% - " + Math.ceil(headerToolsSize) + "px)" });
        getJson(types.path.export).then(function(data) {
            _this.export = data;
            fadeIn($container);
        }).catch(function(e) {
            $container.empty();
            console.log(e);
            new Notification().error().open("Failed load module");
        });
        return this;
    },
    transition: function(type) {
        const _this = this;
        const seStyle = _this.Define.ELEMENTS.style;
        const $contents = jqById(getContentsId());
        $contents.css({ opacity: 0 });
        setTimeout(function() {
            _this.setPage(type);
            $contents.css({ opacity: 1 });
        }, seStyle.transitionDuration);
        return null;
    },
    transaction: function(id) {
        const messages = this.Define.MESSAGES;
        const lock = cloneJS(this.state.lock);
        delete lock[id];
        const error = !isVoid(lock);
        let db = null;
        if(!error) {
            db = new DBUtils().connectBegin(this.state.info);
            this.state.lock[id] = db;
        }
        return {
            error: error,
            message: messages.locking_transaction,
            db: db
        };
    },
    destroy: function(id, db, isCommit) {
        const lock = this.state.lock;
        if(!isVoid(db)) {
            if(isCommit) db.commit();
            else db.rollback();
        }
        delete lock[id];
        return null;
    },
    openMenu: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const $container = jqById(eId.container);
        const $menuContainer = jqById(seId.sqlMenuContainer);
        $container.click(function() { $menuContainer.removeClass(eClass.isVisible); });
        $menuContainer.empty();
        const $menu = jqNode("ul", { class: classes(eClass.menu, eClass.menuBottomRight) });
        const itemList = new Array();
        createMenuItem(itemList, eIcon.home, CAPTIONS.home, transitionMenu);
        if(_this.state.isConnecting) {
            const menuInfo = { sid: _this.state.info.sid, uid: _this.state.info.uid };
            const onDisconnect = function() { _this.onDisconnect(); };
            createMenuItem(itemList, eIcon.signOut, CAPTIONS.disconnect, onDisconnect);
            createMenuInfo(itemList, menuInfo);
        }
        itemList.forEach(function(item) { $menu.append(item); });
        $menuContainer.append($menu);
        setTimeout(function() { $menuContainer.addClass(eClass.isVisible); });
        return null;
    },
    createInfoObject: function(value, name) {
        return {
            value: value,
            name: name
        };
    },
    resetState: function(){
        const _event = this.event;
        const _state = this.state;
        const dataCopyEvent = _event.dataCopy;
        dataCopyEvent.status.extractMode = this.Define.TYPES.design.dataCopy.extractMode.single;
        dataCopyEvent.handler.a = null;
        _state.lock = new Object();
        _state.dataCopy = new Object();
        _state.deleteData = new Object();
        _state.createUser = new Object();
        _state.lincErrorResolution = new Object();
        _state.worker = null;
    },
    onAccess: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const pageType = _this.Define.TYPES.page;
        const loading = new Loading();
        loading.on().then(function() {
            const sid = _this.createInfoObject(jqById(seId.sid).val(), captions.sid);
            const uid = _this.createInfoObject(jqById(seId.uid).val(), captions.uid);
            const pwd = _this.createInfoObject(jqById(seId.pwd).val(), captions.pwd);
            const v = new Validation();
            const vTypes = v.getTypes();
            const sidLayout = v.getLayout(v.initLayout(sid.value, sid.name), [vTypes.required, vTypes.notSpace]);
            const uidLayout = v.getLayout(v.initLayout(uid.value, uid.name), [vTypes.required, vTypes.notSpace]);
            const pwdLayout = v.getLayout(v.initLayout(pwd.value, pwd.name), [vTypes.required, vTypes.notSpace]);
            v.reset().appendList([sidLayout, uidLayout, pwdLayout]);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            const info = {
                sid: sid,
                uid: uid,
                pwd: pwd
            };
            // new DBUtils().connect(info).close();
            appState.oracle.connection(info).then(() => {
                _this.state.isConnecting = true;
                _this.state.info = info;
                _this.transition(pageType.application);
                loading.off();
            }).catch((err) => {
                new Notification().error().open(err);
                loading.off();
            });
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    onDisconnect: function() {
        const _this = this;
        const pageType = _this.Define.TYPES.page;
        _this.resetState();
        _this.state.isConnecting = false;
        _this.state.info = new Object();
        _this.transition(pageType.access);
        return null;
    },
    pushQueryLog: function(list, query) {
        list.push(concatString(query, SIGN.sc));
        // const timeLog = concatString("-- # > Executed query at ", getSystemDateTimeMilliseconds());
        // list.push(timeLog);
        return null;
    },
    downloadLog: function(toolId) {
        const _this = this;
        const loading = new Loading();
        loading.on().then(function() {
            const logData = _this.state[toolId].log;
            const toolName = upperCase(toolId, 0);
            saveAsFile(logData.join(SIGN.crlf), TYPES.file.mime.TEXT_UTF8, concatString(toolName, "_Log_", getFileStamp(), TYPES.file.extension.txt));
            loading.off();
        }).catch(function(e) {
            new Notification.error().open(e.message);
            loading.off();
        });
        return null;
    },
    setPage: function(type) {
        const _this = this;
        const pageType = _this.Define.TYPES.page;
        const seId = _this.Define.ELEMENTS.id;
        const seSrc = _this.Define.ELEMENTS.src;
        const captions = _this.Define.CAPTIONS;
        const _event = _this.event;
        const dataCopyEvent = _event.dataCopy;
        const $contents = jqById(getContentsId());
        $contents.empty();
        switch(type) {
            case pageType.access: {
                const $screen = jqNode("div", { id: seId.accessPage, class: eClass.screen });
                const $logo = jqNode("div").append(jqNode("img", { id: seId.accessLogo, src: seSrc.cloudgs_dbaas }));
                const $command = _this.buildAccessCommand(jqNode("div", { id: seId.accessCommand }));
                $screen.append($logo).append($command);
                $contents.append($screen);
                break;
            }
            case pageType.application: {
                const $screen = jqNode("div", { id: seId.applicationPage, class: eClass.screen });
                const $cardContainer = jqNode("div", { class: eClass.cardContainer });
                const cardList = [
                    {
                        id: seId.queryCommandCard,
                        title: captions.queryCommand,
                        contents: _this.buildQueryCommand()
                    },
                    {
                        id: seId.dataCopyCard,
                        title: captions.dataCopy,
                        contents: _this.buildDataCopy()
                    },
                    {
                        id: seId.deleteDataCard,
                        title: captions.deleteData,
                        contents: _this.buildDeleteData()
                    },
                    {
                        id: seId.createUserCard,
                        title: captions.createUser,
                        contents: _this.buildCreateUser()
                    },
                    {
                        id: seId.lincErrorResolutionCard,
                        title: captions.lincErrorResolution,
                        contents: _this.buildLincErrorResolution()
                    },
                    {
                        id: seId.exportTableCard,
                        title: captions.exportTableTitle,
                        contents: _this.buildExportTable()
                    },
                    {
                        id: seId.importTableCard,
                        title: captions.importTableTitle,
                        contents: _this.buildImportTable()
                    },
                    {
                        id: seId.queryTestCard,
                        title: captions.queryTest.title,
                        contents: _this.buildQueryTest()
                    }
                ];
                cardList.forEach(function(item) {
                    $cardContainer.append(buildCard(item));
                });
                $screen.append($cardContainer);
                $contents.append($screen);
                dataCopyEvent.handler.a();
                _this.renderQueryEditor();
                break;
            }
        }
        _this.state.page = pageType;
        return null;
    },
    buildAccessCommand: function($accessCommand){
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const injector = new Object();
        const getInput = function(id, ph) {
            const $input = jqNode("input", { type: "text", id: id, placeholder: ph });
            $input.keypress(function(e) {
                const keyCode = e.which || e.keyCode;
                if(keyCode === 13) {
                    _this.onAccess();
                }
            });
            injector[id] = $input;
            return $input;
        };
        const $sid = jqNode("div", { class: seClass.commandLine }).append(getInput(seId.sid, captions[seId.sid]));
        const $uid = jqNode("div", { class: seClass.commandLine }).append(getInput(seId.uid, captions[seId.uid]));
        const $pwd = jqNode("div", { class: seClass.commandLine }).append(getInput(seId.pwd, captions[seId.pwd]));
        const getAccessButton = function() {
            const $button = jqNode("button", { class: seClass.accessButton }).text(upperCase(captions.access));
            $button.click(function() {
                _this.onAccess();
            });
            return $button;
        };
        const getLoadButton = function() {
            const $icon = jqNode("i", { class: eIcon.listAlt });
            const $button = jqNode("button", { class: seClass.accessLoadButton }).append($icon);
            $button.click(function() {
                _this.openAccessTemplate(injector);
            });
            return $button;
        };
        const $confirm = jqNode("div", { class: seClass.commandLine }).append(getAccessButton());
        const $load = jqNode("div", { class: seClass.commandLine }).append(getLoadButton());
        [$sid, $uid, $pwd, $confirm, $load].forEach(function(item) { $accessCommand.append(item); });
        return $accessCommand;
    },
    openAccessTemplate: function(elementInjector) {
        const store = new Store(storage);
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const messages = _this.Define.MESSAGES;
        const title = captions.accessList;
        const sAccessList = STRUCTURE.accessList;
        const eb = new ElementBuilder();
        const itf = new Interface(sAccessList).setRoot(store.init());
        const dialog = new Dialog();
        const $container = jqNode("div", { id: eId.interfaceListContainer });
        const buildContents = function() {
            const dAL = store.init()[itf.getKey()];
            const apply = function(info) {
                Object.keys(elementInjector).forEach(function(key) {
                    elementInjector[key].val(info[key]);
                });
                dialog.close();
            };
            const edit = function(info) {
                openAccessListEditor(info);
            };
            const remove = function(info) {
                const callback = function(warningClose) {
                    store.connect([itf.getKey(), info.name]).delete().apply();
                    buildContents();
                    store.sync();
                    warningClose();
                };
                new Notification().warning(callback).open(MESSAGES.warning_remove_record);
            };
            if(!isVoid(dAL)) {
                const $ul = jqNode("ul");
                getObjectOrderList(dAL).forEach(function(key) {
                    const info = dAL[key];
                    const $li = jqNode("li");
                    $li.click(function(e) {
                        e.stopPropagation();
                        apply(info);
                    });
                    const $viewArea = jqNode("div", { class: eClass.viewArea });
                    const $viewTable = jqNode("table");
                    const $colgroup = jqNode("colgroup");
                    const $viewHeader = jqNode("thead");
                    const $viewBody = jqNode("tbody");
                    const $nameRow = jqNode("tr");
                    const $nameCell = jqNode("th", { colspan: "3" }).text(info.name);
                    $nameRow.append($nameCell).appendTo($viewHeader);
                    const colgroupSizeStack = [100, 10, null];
                    colgroupSizeStack.forEach(function(size) {
                        $col = jqNode("col");
                        if(size) $col.attr({ width: size });
                        $colgroup.append($col);
                    });
                    const infoObj = {
                        0: { label: captions.sid },
                        1: { label: captions.uid },
                        2: { label: captions.pwd }
                    };
                    [info.sid, info.uid, info.pwd].forEach(function(item, i) {
                        const label = infoObj[i].label;
                        const $infoRow = jqNode("tr");
                        const $labelCell = jqNode("td").text(upperCase(label));
                        const $middleCell = jqNode("td").text(SIGN.gc);
                        const $valueCell = jqNode("td").text(item);
                        eb.listAppend($infoRow, [$labelCell, $middleCell, $valueCell]);
                        $viewBody.append($infoRow);
                    });
                    eb.listAppend($viewTable, [$colgroup, $viewHeader, $viewBody]);
                    $viewArea.append($viewTable);
                    const $actionArea = jqNode("div", { class: eClass.actionArea });
                    const $editIcon = eb.getFontAwesomeIcon(eIcon.edit);
                    const $removeIcon = eb.getFontAwesomeIcon(eIcon.trash);
                    const $actionTable = jqNode("table");
                    const $actionBody = jqNode("tbody");
                    [$editIcon, $removeIcon].forEach(function(item, i) {
                        const $row = jqNode("tr");
                        const $cell = jqNode("td").append(item);
                        $row.append($cell).appendTo($actionBody);
                        $cell.click(function(e) {
                            e.stopPropagation();
                            switch(i) {
                                case 0: {
                                    edit(info);
                                    break;
                                }
                                case 1: {
                                    remove(info);
                                    break;
                                }
                            }
                        });
                    });
                    $actionTable.append($actionBody).appendTo($actionArea);
                    eb.listAppend($li, [$viewArea, $actionArea]);
                    $ul.append($li);
                });
                $container.empty().append($ul);
            }
            else {
                $container.empty();
            }
        };
        const openAccessListEditor = function(editData) {
            const isEditMode = !isVoid(editData);
            const info = isEditMode ? editData : itf.getInjectData(null, null, null, null);
            const subOption = { "width": "360px", "max-height": "500px" };
            const title = isEditMode ? upperCase(captions.edit, 0) : upperCase(captions.add, 0);
            const eventInjector = new Object();
            const buildSubContents = function() {
                const $container = jqNode("div", { class: eClass.interfaceListAddContainer });
                const $table = jqNode("table");
                const itemList = [
                    { key: "name", label: upperCase(captions.name), value: info.name ? info.name : SIGN.none },
                    { key: "sid", label: upperCase(captions.sid), value: info.sid ? info.sid : SIGN.none },
                    { key: "uid", label: upperCase(captions.uid), value: info.uid ? info.uid : SIGN.none },
                    { key: "pwd", label: upperCase(captions.pwd), value: info.pwd ? info.pwd : SIGN.none }
                ];
                itemList.forEach(function(item) {
                    const $row = jqNode("tr");
                    const $label = jqNode("label").text(item.label);
                    const $input = jqNode("input", { class: eClass.applicationInput, value: item.value });
                    const $labelCell = jqNode("td").append($label);
                    const $inputCell = jqNode("td").append($input);
                    eb.listAppend($row, [$labelCell, $inputCell]);
                    $table.append($row);
                    eventInjector[item.key] = $input;
                });
                $container.append($table);
                return $container;
            };
            const callback = function(dialogClose) {
                const name = _this.createInfoObject(eventInjector.name.val(), upperCase(captions.name));
                const sid = _this.createInfoObject(eventInjector.sid.val(), captions.sid);
                const uid = _this.createInfoObject(eventInjector.uid.val(), captions.uid);
                const pwd = _this.createInfoObject(eventInjector.pwd.val(), captions.pwd);
                const v = new Validation();
                const vTypes = v.getTypes();
                const nameLayout = v.getLayout(v.initLayout(name.value, name.name), [vTypes.required, vTypes.notSpace]);
                const sidLayout = v.getLayout(v.initLayout(sid.value, sid.name), [vTypes.required, vTypes.notSpace]);
                const uidLayout = v.getLayout(v.initLayout(uid.value, uid.name), [vTypes.required, vTypes.notSpace]);
                const pwdLayout = v.getLayout(v.initLayout(pwd.value, pwd.name), [vTypes.required, vTypes.notSpace]);
                v.reset().appendList([nameLayout, sidLayout, uidLayout, pwdLayout]);
                const result = v.exec();
                if(result.error) {
                    new Notification().error().open(result.message);
                    return false;
                }
                const dAL = store.init()[itf.getKey()];
                if(!isVoid(dAL) && !isVoid(dAL[name.value]) && !(isEditMode && info.name === name.value)) {
                    new Notification().error().open(messages.already_exits_name);
                    return false;
                }
                const getOrder = function() {
                    if(isEditMode && !isVoid(dAL[info.name])) return dAL[info.name].order;
                    return getObjectMaxOrder(dAL) + 1;
                };
                const injectData = itf.getInjectData(name.value, sid.value, uid.value, pwd.value, getOrder());
                itf.inject(store, injectData, name.value);
                if(isEditMode && info.name !== name.value) store.connect([itf.getKey(), info.name]).delete().apply();
                store.connect([itf.getKey()]).set(sortObjectByOrder(store.init()[itf.getKey()])).apply();
                buildContents();
                store.sync();
                dialogClose();
            };
            const okIcon = eb.getFontAwesomeIcon(eIcon.check);
            const closeIcon = eb.getFontAwesomeIcon(eIcon.times);
            new SubDialog().setContents(title, buildSubContents(), subOption).setUserButton(okIcon, closeIcon).open(callback);
        };
        const $addButton = jqNode("button").append(eb.getFontAwesomeIcon(eIcon.plus));
        $addButton.click(function() { openAccessListEditor(); });
        buildContents();
        const option = { "width": "400px", "max-height": "530px" };
        dialog.setContents(title, $container, option).setButton([$addButton]).disableOkButton().open();
    },
    actionControllerQueryCommand: function(phase) {
        const _this = this;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.queryCommand;
        const exportType = types.export.queryCommand;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const qcState = _this.state.queryCommand;
        const $card = jqById(seId.queryCommandCard);
        const $contentsContainer = $card.find(concatString(".", eClass.appContentsContainer));
        const $actionArea = $contentsContainer.children(concatString(".", eClass.actionArea));
        const $timer = jqById(seId.queryTimer);
        const eb = new ElementBuilder();
        switch(phase) {
            case phaseType.executing: {
                const getTimerView = function(time) {
                    return concatString("Elapsed time : ", time, "sec");
                };
                qcState.element.removeClass(eClass.disable);
                qcState.element.prop("disabled", false);
                qcState.phase = phase;
                let queryTimeCounter = 0;
                $timer.text(getTimerView(queryTimeCounter));
                qcState.timer = setInterval(function() {
                    queryTimeCounter += 1;
                    const milisec = (queryTimeCounter / 10).toFixed(3);
                    $timer.text(getTimerView(milisec));
                }, 100);
                break;
            }
            case phaseType.complete: {
                jqById(seId.exportButtonQueryCommand).remove();
                const $exportButton = jqNode("button", { id: seId.exportButtonQueryCommand, class: eClass.buttonColorPositive }).text(upperCase(captions.export));
                $actionArea.append($exportButton);
                $exportButton.click(function() {
                    const callback = function(dialogClose) {
                        _this.exportQueryCommandConsoles(dialogClose);
                    };
                    const exportContents = function() {
                        const $container = jqNode("div", { id: seId.exportContainerQueryCommand });
                        const $exportTypeCommandArea = jqNode("div", { class: seClass.queryCommandExportCommandArea });
                        const $exportTypeLabel = jqNode("label").text(captions.exportType);
                        const $select = jqNode("select");
                        exportType.forEach(function(item) {
                            const $option = jqNode("option", { value: item.value }).text(item.label);
                            if(qcState.export.type === item.value) {
                                $option.attr({ selected: true });
                            }
                            $select.append($option);
                        });
                        eb.listAppend($exportTypeCommandArea, [$exportTypeLabel, $select]);
                        const $consoleNameCommandArea = jqNode("div", { class: seClass.queryCommandExportCommandArea });
                        const $consoleNameLabel = jqNode("label").text(captions.consoleNameLabel);
                        const $consoleNameInput = jqNode("textarea", { id: seId.queryCommand.consoleName });
                        eb.listAppend($consoleNameCommandArea, [$consoleNameLabel, $consoleNameInput]);
                        const cncaElement = new ElementBuilder($consoleNameCommandArea);
                        eb.listAppend($container, [$exportTypeCommandArea, $consoleNameCommandArea]);
                        const initEvent = function(v) {
                            if(v === exportType[2].value) {
                                cncaElement.removeHidden();
                            }
                            else {
                                cncaElement.setHidden();
                            }
                        };
                        $select.change(function(e) {
                            const value = e.target.value;
                            qcState.export.type = value;
                            initEvent(value);
                        });
                        initEvent(qcState.export.type);
                        return $container;
                    };
                    const contentsOption = { "width": "350px" };
                    new Dialog().setContents(upperCase(captions.export, 0), exportContents(), contentsOption).open(callback);
                });
                break;
            }
            default: {
                setTimeout(function() {
                    qcState.element.addClass(eClass.disable);
                    qcState.element.prop("disabled", true);
                    qcState.phase = null;
                    clearInterval(qcState.timer);
                });
                break;
            }
        }
        return null;
    },
    buildQueryCommand: function() {
        const _this = this;
        const qcState = _this.state.queryCommand;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: eClass.appContentsContainer });
        const $timer = jqNode("div", { id: seId.queryTimer });
        const $actionArea = jqNode("div", { class: eClass.actionArea });
        const $loadButton = jqNode("button", { class: eClass.flatButton }).append(eb.getFontAwesomeIcon(eIcon.listAlt));
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        const $cancelButton = jqNode("button", { class: classes(eClass.buttonColorOrange, eClass.disable) }).text(upperCase(captions.cancel));
        $cancelButton.prop("disabled", true);
        eb.listAppend($actionArea, [$loadButton, $execButton]);
        eb.listAppend($container, [$timer, $actionArea]);
        const itemList = [
            {
                label: upperCase(captions.setSid),
                inputType: "input",
                inputId: seId.queryCommand.setSid,
                injectId: seId.sid
            },
            {
                label: upperCase(captions.setUid),
                inputType: "input",
                inputId: seId.queryCommand.setUid,
                injectId: seId.uid
            },
            {
                label: upperCase(captions.setPwd),
                inputType: "input",
                inputId: seId.queryCommand.setPwd,
                injectId: seId.pwd
            }
        ];
        const injector = new Object();
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: eClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            eb.listAppend($commandArea, [$label, $input]);
            $container.append($commandArea);
            if(item.injectId) injector[item.injectId] = $input;
        });
        const $editorCommandArea = jqNode("div", { class: seClass.editorCommandArea });
        const $queryEditor = jqNode("div", { id: seId.queryEditor });
        const $queryGridContainer = jqNode("div", { class: seClass.queryGridContainer });
        const $queryGridTabs = jqNode("div", { id: seId.queryGridTabs });
        const $queryGridContents = jqNode("div", { id: seId.queryGridContents });
        eb.listAppend($queryGridContainer, [$queryGridTabs, $queryGridContents]);
        eb.listAppend($editorCommandArea, [$queryEditor, $queryGridContainer]);
        eb.listAppend($container, [$editorCommandArea]);
        $loadButton.click(function() {
            _this.openAccessTemplate(injector);
        });
        $execButton.click(function() {
            _this.execQueryCommand();
        });
        $cancelButton.click(function() {
            if(!qcState.phase) return false;
            _this.cancel();
            _this.actionControllerQueryCommand(null);
        });
        qcState.element = $cancelButton;
        return $container;
    },
    renderQueryEditor: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const editorTypes = _this.Define.TYPES.editor;
        try {
            const editor = ace.edit(seId.queryEditor);
            _this.state.queryEditor = editor;
            editor.setShowPrintMargin(false);
            editor.getSession().setMode(editorTypes.mode.sql);
            editor.setTheme(editorTypes.theme.monokai);
            editor.setFontSize(15);
            editor.getSession().setUseWrapMode(false);
            editor.commands.addCommand({
                name: "exec_key_event",
                exec: function() {
                    _this.execQueryCommand();
                },
                bindKey: { mac: "cmd-f", win: "ctrl-f" }
            });
        }
        catch(e) {
            console.log(e);
        }
        return null;
    },
    execQueryCommand: function() {
        const _this = this;
        const editor = _this.state.queryEditor;
        if(editor) {
            const value = editor.getValue();
            const selection = editor.getSession().doc.getTextRange(editor.selection.getRange());
            const query = selection ? selection : value;
            _this.execQuery(query);
        }
        return null;
    },
    execQuery: function(query) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const messages = _this.Define.MESSAGES;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.queryCommand;
        const qcState = _this.state.queryCommand;
        if(isVoid(query)) {
            new Notification().error().open("Not found query");
            return false;
        }
        const loading = new Loading();
        loading.on().then(function() {
            const exceptionRule = new RegExp("(((INSERT INTO))|((UPDATE).+?(SET))|((DELETE FROM))|(CREATE TABLE)|(DROP TABLE)|(TRUNCATE TABLE))", "gi");
            if(exceptionRule.test(query)) {
                new Notification().error().open(messages.only_exec_select_query);
                return false;
            }
            const queryStack = getExistArray(query.split(SIGN.sc).map(function(item) { return item.trim().replace(new RegExp("\r\nSELECT", "g"), "SELECT"); }));
            const $tabs = jqById(seId.queryGridTabs);
            const $contents = jqById(seId.queryGridContents);
            if(!isVoid(qcState.ui)) {
                _this.clearQueryCommandUI();
            }
            const uiTabIdList = new Array();
            const uiGridIdList = new Array();
            const dataList = new Array();
            const tabsStack = new Array();
            const mapping = new Object();
            const getTabId = function(idx) {
                return concatString(seId.tab, idx);
            };
            const getGridId = function(idx) {
                return concatString(seId.dataGrid, idx);
            };
            const createTabs = function(idx) {
                const tabId = getTabId(idx);
                uiTabIdList.push(tabId);
                return {
                    id: tabId,
                    text: concatString(upperCase(captions.console, 0), idx),
                    closable: true
                };
            };
            const createDataGrid = function(idx, dataSet) {
                const option = {
                    header: false,
                    toolbar: false,
                    footer: false,
                    lineNumbers: true,
                    selectColumn: false,
                    expandColumn: false
                };
                const gridId = getGridId(idx);
                uiGridIdList.push(gridId);
                dataList.push(dataSet);
                return {
                    name: gridId,
                    header: SIGN.none,
                    show: option,
                    columns: dataSet.name,
                    records: dataSet.data
                };
            };
            // _this.actionControllerQueryCommand(phaseType.executing);
            const $sid = jqById(seId.queryCommand.setSid);
            const $uid = jqById(seId.queryCommand.setUid);
            const $pwd = jqById(seId.queryCommand.setPwd);
            const setSid = _this.createInfoObject(jqById(seId.queryCommand.setSid).val(), captions.setSid);
            const setUid = _this.createInfoObject(jqById(seId.queryCommand.setUid).val(), captions.setUid);
            const setPwd = _this.createInfoObject(jqById(seId.queryCommand.setPwd).val(), captions.setPwd);
            const info = {
                sid: setSid,
                uid: setUid,
                pwd: setPwd
            };
            const accessInfo = (!isVoid(setSid.value) && !isVoid(setUid.value) && !isVoid(setPwd.value)) ? info : _this.state.info;
            const db = new DBUtils().connect(accessInfo);
            queryStack.forEach(function(query, i, a) {
                const idx = i + 1;
                const dataSet = db.executeSelectGrid(query).onEnd(a.length === idx).dataSet;
                tabsStack.push(createTabs(idx));
                const gridId = getGridId(idx);
                const $grid = jqNode("div", { id: gridId, style: "width: 100%; height: 300px;" });
                $contents.append($grid);
                mapping[getTabId(idx)] = $grid;
                const dataGrid = createDataGrid(idx, dataSet);
                $grid.w2grid(dataGrid);
                if(idx < a.length) {
                    $grid.hide();
                }
            });
            $tabs.w2tabs({
                name: seId.queryTabs,
                active: tabsStack[tabsStack.length - 1].id,
                tabs: tabsStack,
                onClick: function(e) {
                    const tabId = e.target;
                    Object.keys(mapping).forEach(function(key, i) {
                        const idx = i + 1;
                        const $iGrid = mapping[key];
                        if(tabId === key) {
                            $iGrid.show();
                            w2ui[getGridId(idx)].reload();
                        }
                        else {
                            $iGrid.hide();
                        }
                    });
                },
                onClose: function(e) {
                    const removeTab = e.target;
                    const tabUI = w2ui[seId.queryTabs];
                    const activeTab = tabUI.active;
                    const tabs = qcState.ui.tabIdList;
                    tabs.splice(tabs.indexOf(removeTab), 1);
                    if(tabs.length >= 1) {
                        if(activeTab === removeTab) {
                            const lastTab = tabs[tabs.length - 1];
                            tabUI.select(lastTab);
                            tabUI.click(lastTab);
                        }
                    }
                    else {
                        _this.clearQueryCommandUI();
                    }
                }
            });
            qcState.ui.tabIdList = uiTabIdList;
            qcState.ui.gridIdList = uiGridIdList;
            qcState.export.data = dataList;
            _this.actionControllerQueryCommand(phaseType.complete);
            loading.off();
        }).catch(function(e) {
            new Notification().error().open(e.message);
//            _this.actionControllerQueryCommand(null);
            loading.off();
        });
        return null;
    },
    exportQueryCommandConsoles: function(dialogClose) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const exportType = types.export.queryCommand;
        const qcState = _this.state.queryCommand;
        const exportState = qcState.export;
        const fileType = TYPES.file.mime.OCTET_STREAM;
        if(!exportState.data) {
            new Notification.error().open(MESSAGES.nothing_data);
            return false;
        }
        const loading = new Loading();
        loading.on().then(function() {
            const consoleData = exportState.data;
            const type = exportState.type;
            let convertedData = new Array();
            const convertColumns = function(columns) {
                return [columns.map(function(cObj) { return cObj.caption; })];
            };
            const convertData = function(data) {
                if(isVoid(data)) return [SIGN.none];
                return data.map(function(dObj) {
                    delete dObj.recid;
                    return Object.keys(dObj).map(function(key) { return dObj[key] });
                });
            };
            const headerStyle = {
                fill: {
                    patternType: "solid",
                    fgColor:{ rgb: "9E9E9E" }
                }
            };
            switch(type) {
                case exportType[0].value: {
                    const setStyle = function(R, C, cell) {
                        if(headerIndex.indexOf(R) >= 0) cell.s = headerStyle;
                    };
                    const headerIndex = new Array();
                    consoleData.forEach(function(dataSet) {
                       const columns = convertColumns(dataSet.name);
                       const data = convertData(dataSet.data);
                       headerIndex.push(convertedData.length);
                       convertedData = convertedData.concat(columns.concat(data));
                    });
                    const wb = new Workbook();
                    const ws = sheetFromArrayOfArrays(convertedData, setStyle);
                    wb.SheetNames.push(type);
                    wb.Sheets[type] = ws;
                    const wbout = XLSX.write(wb, { bookType: "xlsx", bookSST: true, type: "binary" });
                    const fileName = concatString("QueryCommand_", getFileStamp(type), TYPES.file.extension.xlsx);
                    saveAsFile(s2ab(wbout), fileType, fileName);
                    break;
                }
                case exportType[1].value: {
                    consoleData.forEach(function(dataSet) {
                       const data = convertData(dataSet.data);
                       convertedData = convertedData.concat(data);
                    });
                    const wb = new Workbook();
                    const ws = sheetFromArrayOfArrays(convertedData);
                    wb.SheetNames.push(type);
                    wb.Sheets[type] = ws;
                    const wbout = XLSX.write(wb, { bookType: "xlsx", bookSST: true, type: "binary" });
                    const fileName = concatString("QueryCommand_", getFileStamp(type), TYPES.file.extension.xlsx);
                    saveAsFile(s2ab(wbout), fileType, fileName);
                    break;
                }
                case exportType[2].value: {
                    let existConsoleName = false;
                    const consoleName = _this.createInfoObject(jqById(seId.queryCommand.consoleName).val(), captions.consoleNameLabel);
                    const cnvList = getExistArray(consoleName.value.split(SIGN.nl));
                    if(cnvList.length >= 1) {
                        if(consoleData.length !== cnvList.length) {
                            throw new Error("The number of console names is different from the number of console sheets");
                        }
                        else {
                            const result = duplicationCheckForArray(cnvList.map(mapUpperCase));
                            if(result.hasError) {
                                const dList = result.index.map(function(idx) { return cnvList[idx]; });
                                throw new Error(concatString(consoleName.name, " has duplication error", SIGN.br, dList.join(SIGN.br)));
                            }
                            else {
                                existConsoleName = true;
                            }
                        }
                    }
                    const setStyle = function(R, C, cell) {
                        if(R === 0) cell.s = headerStyle;
                    };
                    const wb = new Workbook();
                    consoleData.forEach(function(dataSet, i) {
                        const columns = convertColumns(dataSet.name);
                        const data = convertData(dataSet.data);
                        const ws_data = columns.concat(data);
                        const ws = sheetFromArrayOfArrays(ws_data, setStyle);
                        const console = existConsoleName ? cnvList[i] : concatString("Console", i + 1);
                        wb.SheetNames.push(console);
                        wb.Sheets[console] = ws;
                    });
                    const wbout = XLSX.write(wb, { bookType: "xlsx", bookSST: true, type: "binary" });
                    const fileName = concatString("QueryCommand_", getFileStamp(type), TYPES.file.extension.xlsx);
                    saveAsFile(s2ab(wbout), fileType, fileName);
                    break;
                }
            }
            dialogClose();
            loading.off();
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    clearQueryCommandUI: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const qcState = _this.state.queryCommand;
        const $tabs = jqById(seId.queryGridTabs);
        const $contents = jqById(seId.queryGridContents);
        if(w2ui[seId.queryTabs]) {
            w2ui[seId.queryTabs].destroy();
        }
        qcState.ui.gridIdList.forEach(function(gridId) {
            if(w2ui[gridId]) {
                w2ui[gridId].destroy();
            }
        });
        $tabs.empty();
        $contents.empty();
        _this.state.queryCommand.ui = new Object();
        _this.actionControllerQueryCommand(null);
        return null;
    },
    buildDataCopy: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const dcdt = types.design.dataCopy;
        const dataCopyDesign = _this.design.dataCopy;
        const _event = _this.event;
        const dataCopyEvent = _event.dataCopy;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: seClass.contentsContainer });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $loadButton = jqNode("button", { class: eClass.flatButton }).append(eb.getFontAwesomeIcon(eIcon.listAlt));
        const $checkButton = jqNode("button", { class: eClass.buttonColorBrown }).text(upperCase(captions.check));
        const $extractButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.extract));
        const $importButton = jqNode("button", { class: eClass.buttonColorCyan }).text(upperCase(captions.import));
        eb.listAppend($actionArea, [$loadButton, $checkButton, $extractButton, $importButton]);
        $container.append($actionArea);
        const emr = dataCopyDesign.extractModeRadio;
        const egc = dataCopyDesign.extractGroupCheck;
        const cr = dataCopyDesign.customizeRadio;
        const extractModeRadioItemList = [getItemListObject(emr, dcdt.extractMode.single), getItemListObject(emr, dcdt.extractMode.multiple)];
        const $emrCommandArea = jqNode("div", { class: seClass.commandArea });
        const $emrItem = eb.createRadio(extractModeRadioItemList).getItem();
        const $emrLabel = jqNode("label").css("line-height", "2.5").text(captions.extractMode);
        const $emrMain = jqNode("div", { class: eClass.fullWidth }).append($emrItem);
        eb.listAppend($emrCommandArea, [$emrLabel, $emrMain]);
        const extractGroupCheckItemList = [getItemListObject(egc, dcdt.extractGroup.skei), getItemListObject(egc, dcdt.extractGroup.kkanri), getItemListObject(egc, dcdt.extractGroup.hksiharai)];
        const $egcCommandArea = jqNode("div", { class: seClass.commandArea });
        const $egcItem = eb.createCheckbox(extractGroupCheckItemList).getItem();
        const $egcLabel = jqNode("label").css("line-height", "2.5").text(captions.extractGroup);
        const $egcMain = jqNode("div", { class: eClass.fullWidth }).append($egcItem);
        eb.listAppend($egcCommandArea, [$egcLabel, $egcMain]);
        const customizeRadioItemList = [getItemListObject(cr, dcdt.customize.all), getItemListObject(cr, dcdt.customize.none), getItemListObject(cr, dcdt.customize.inherit)];
        const $crCommandArea = jqNode("div", { class: seClass.commandArea });
        const $crItem = eb.createRadio(customizeRadioItemList).getItem();
        const $crLabel = jqNode("label").css("line-height", "2.5").text(upperCase(captions.customize, 0));
        const $crMain = jqNode("div", { class: eClass.fullWidth }).append($crItem);
        eb.listAppend($crCommandArea, [$crLabel, $crMain]);
        eb.listAppend($container, [$emrCommandArea, $egcCommandArea, $crCommandArea]);
        const setEvent = function() {
            const initInputType = function(mode) {
                switch(mode) {
                    case emr.type.single.value: {
                        jqById(seId.policyNumberFrom).parent().removeClass(eClass.hide);
                        jqById(seId.policyNumberFromTextarea).parent().addClass(eClass.hide);
                        break;
                    }
                    case emr.type.multiple.value: {
                        jqById(seId.policyNumberFrom).parent().addClass(eClass.hide);
                        jqById(seId.policyNumberFromTextarea).parent().removeClass(eClass.hide);
                        break;
                    }
                }
            };
            const emrElement = dataCopyEvent.element.extractMode;
            new EventHandler($(emrElement)).addEvent("change", function(e) {
                const target = e.target;
                dataCopyEvent.status.extractMode = target.value;
                initInputType(target.value);
            });
            initInputType(dataCopyEvent.status.extractMode);
        };
        dataCopyEvent.handler.a = setEvent;
        const itemList = [
            {
                label: captions.subSid,
                inputType: "input",
                inputId: seId.subSid,
                injectId: seId.sid
            },
            {
                label: captions.subUid,
                inputType: "input",
                inputId: seId.subUid,
                injectId: seId.uid
            },
            {
                label: captions.subPwd,
                inputType: "input",
                inputId: seId.subPwd,
                injectId: seId.pwd
            },
            {
                label: captions.policyNumberFrom,
                inputType: "input",
                inputId: seId.policyNumberFrom,
                injectId: null
            },
            {
                label: captions.policyNumberFrom,
                inputType: "textarea",
                inputId: seId.policyNumberFromTextarea,
                injectId: null
            },
            {
                label: captions.policyNumberTo,
                inputType: "textarea",
                inputId: seId.policyNumberTo,
                injectId: null
            }
        ];
        const injector = new Object();
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: seClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            eb.listAppend($commandArea, [$label, $input]);
            $container.append($commandArea);
            if(item.injectId) injector[item.injectId] = $input;
            switch(item.inputId) {
                case seId.subSid: {
                    dataCopyEvent.element.sid = $input;
                    break;
                }
                case seId.subUid: {
                    dataCopyEvent.element.uid = $input;
                    break;
                }
                case seId.subPwd: {
                    dataCopyEvent.element.pwd = $input;
                    break;
                }
                case seId.policyNumberFrom: {
                    dataCopyEvent.element.pnf = $input;
                    break;
                }
                case seId.policyNumberFromTextarea: {
                    dataCopyEvent.element.pnft = $input;
                    break;
                }
                case seId.policyNumberTo: {
                    dataCopyEvent.element.pnt = $input;
                    break;
                }
            }
            if(!isVoid(dataCopyEvent.values[item.inputId])) {
                $input.val(dataCopyEvent.values[item.inputId]);
            }
            dataCopyEvent.values[item.inputId] = SIGN.none;
        });
        $loadButton.click(function() {
            _this.openAccessTemplate(injector);
        });
        $checkButton.click(function() {
            _this.checkDataCopy();
        });
        $extractButton.click(function() {
            _this.extractDataCopy();
        });
        $importButton.click(function() {
            _this.importDataCopy();
        });
        return $container;
    },
    buildOptionContents: function(optionData) {
        const _this = this;
        const dataCopyState = _this.state.dataCopy;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const $container = jqNode("div", { id: seId.optionContainerDataCopy });
        const $commandArea = jqNode("div", { class: seClass.optionCommandArea });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $addButton = jqNode("button").append(jqNode("i", { class: eIcon.plus }));
        $addButton.click(function() {
            $commandArea.append(_this.createOptionCommandLine());
            jqByClass(eClass.dialogContents).scrollTop(function() { return this.scrollHeight; });
        });
        $actionArea.append($addButton);
        const data = optionData ? optionData : dataCopyState.option;
        if(data) {
            data.forEach(function(item) {
                $commandArea.append(_this.createOptionCommandLine(item.table, item.script));
            });
        }
        [$commandArea, $actionArea].forEach(function(item) { $container.append(item); });
        return $container;
    },
    createOptionCommandLine: function(table, script) {
        const _this = this;
        const seClass = _this.Define.ELEMENTS.class;
        const $commandLine = jqNode("div", { class: seClass.commandLine });
        const $removeRow = jqNode("div", { class: classes(seClass.commandLineRow, seClass.removeRow) });
        const $removeButton = jqNode("button", { class: seClass.optionRemoveButton }).append(jqNode("i", { class: eIcon.trash }))
        $removeRow.append($removeButton);
        const $inputRow = jqNode("div", { class: seClass.commandLineRow });
        const $inputLabel = jqNode("label").text("Table");
        const $input = jqNode("input", { type: "text" });
        const $textareaRow = jqNode("div", { class: seClass.commandLineRow });
        const $textareaLabel = jqNode("label").text("Script");
        const placeholder = "@column\nvalue1\nvalue2...($null: remove, $eq: pass)";
        const $textarea = jqNode("textarea", { placeholder: placeholder });
        if(table && script) {
            $input.val(table);
            $textarea.val(script);
        }
        [$inputLabel, $input].forEach(function(item) {
            $inputRow.append(item);
        });
        [$textareaLabel, $textarea].forEach(function(item) {
            $textareaRow.append(item);
        });
        [$removeRow, $inputRow, $textareaRow].forEach(function(item) {
            $commandLine.append(item);
        });
        $removeButton.click(function() {
            $commandLine.remove();
        });
        return $commandLine;
    },
    actionControllerDataCopy: function(phase) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.dataCopy;
        const transactionId = types.toolId.dataCopy;
        const _event = _this.event;
        const dataCopyEvent = _event.dataCopy;
        const dataCopyDesign = _this.design.dataCopy;
        const $card = jqById(seId.dataCopyCard);
        const $cardContents = $card.find(concatString(".", eClass.cardContents));
        const $contentsContainer = $card.find(concatString(".", seClass.contentsContainer));
        const $actionArea = $contentsContainer.children(concatString(".", seClass.actionArea));
        const $checkButton = jqNode("button", { class: eClass.buttonColorBrown }).text(upperCase(captions.check));
        const $extractButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.extract));
        const $insertButton = jqNode("button", { class: eClass.buttonColorPositive }).text(upperCase(captions.insert));
        const $optionButton = jqNode("button", { class: eClass.buttonColorEnergized }).text(upperCase(captions.option));
        const $commitButton = jqNode("button", { class: eClass.buttonColorDark }).text(upperCase(captions.commit));
        const $rollbackButton = jqNode("button", { class: eClass.buttonColorDark }).text(upperCase(captions.rollback));
        const $logButton = jqNode("button", { class: eClass.buttonColorPositive }).text(upperCase(captions.log));
        const $saveQueryButton = jqNode("button", { class: eClass.buttonColorBlueGrey }).text(upperCase(captions.query));
        const $exportButton = jqNode("button", { class: eClass.buttonColorCalm }).text(upperCase(captions.export));
        const $backupButton = jqNode("button", { class: eClass.buttonColorRoyal }).text(upperCase(captions.backup));
        const $backButton = jqNode("button", { class: eClass.buttonColorOrange }).text(upperCase(captions.back));
        const $resetButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.reset));
        const eb = new ElementBuilder();
        const propOption = eb.getPropOptionLayout();
        let itemList = new Array();
        switch(phase) {
            case phaseType.import: {
                itemList = [$checkButton, $extractButton, $backButton, $resetButton];
                propOption.readonlyList = ["sid", "uid", "pwd"];
                eb.setElementDisable(dataCopyEvent.element, propOption);
                break;
            }
            case phaseType.insert: {
                itemList = [$insertButton, $optionButton, $saveQueryButton, $exportButton, $backupButton, $backButton, $resetButton];
                propOption.disableList = ["extractMode", "extractGroup", "customizeRadio"];
                propOption.readonlyList = ["sid", "uid", "pwd", "pnf", "pnft", "pnt"];
                eb.setElementDisable(dataCopyEvent.element, propOption);
                break;
            }
            case phaseType.commit: {
                itemList = [$commitButton, $rollbackButton, $logButton, $saveQueryButton, $exportButton, $backupButton, $backButton, $resetButton];
                break;
            }
            case phaseType.complete: {
                itemList = [$logButton, $saveQueryButton, $exportButton, $backupButton, $backButton, $resetButton];
                break;
            }
        }
        $actionArea.empty();
        itemList.forEach(function(item) {
            $actionArea.append(item);
        });
        $checkButton.click(function() {
            _this.checkDataCopy();
        });
        $extractButton.click(function() {
            _this.extractDataCopy(phase);
        });
        $insertButton.click(function() {
            _this.insertDataCopy();
        });
        $optionButton.click(function() {
            _this.openOptionDataCopy();
        });
        $commitButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db, true);
            _this.actionControllerDataCopy(phaseType.complete);
            new Notification().complete().open("Data copy successfully");
        });
        $rollbackButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.actionControllerDataCopy(phaseType.insert);
        });
        $logButton.click(function() {
            _this.downloadLog(transactionId);
        });
        $saveQueryButton.click(function() {
            _this.saveQueryDataCopy();
        });
        $exportButton.click(function() {
            _this.exportToExcelDataCopy();
        });
        $backupButton.click(function() {
            _this.backupDataCopy();
        });
        $backButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.state.dataCopy = new Object();
            Object.keys(dataCopyEvent.values).forEach(function(key) {
                dataCopyEvent.values[key] = jqById(key).val();
            });
            const temp = {
                extractMode: [dataCopyEvent.status.extractMode],
                extractGroup: new Array(),
                customize: [$(dataCopyEvent.element.customizeRadioChecked).val()]
            };
            $(dataCopyEvent.element.extractGroupChecked).each(function() {
                temp.extractGroup.push($(this).val());
            });
            $cardContents.html(_this.buildDataCopy());
            const setList = [
                { key: "extractMode", ele: dataCopyEvent.element.extractMode },
                { key: "extractGroup", ele: dataCopyEvent.element.extractGroup },
                { key: "customize", ele: dataCopyEvent.element.customizeRadio }
            ];
            setList.forEach(function(item) {
                $(item.ele).each(function() {
                    if(temp[item.key].indexOf($(this).val()) >= 0) {
                        $(this).prop({ checked: true });
                    }
                    else {
                        $(this).prop({ checked: false });
                    }
                });
            });
            dataCopyEvent.handler.a();
        });
        $resetButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.state.dataCopy = new Object();
            dataCopyEvent.values = new Object();
            $cardContents.html(_this.buildDataCopy());
            dataCopyEvent.status.extractMode = types.design.dataCopy.extractMode.single;
            dataCopyEvent.handler.a();
        });
        return null;
    },
    backupDataCopy: function() {
        const _this = this;
        const extractedData = _this.state.dataCopy.extractedData;
        const fileDefine = TYPES.file;
        const loading = new Loading();
        loading.on().then(function() {
            const parts = JSON.stringify(extractedData);
            const fileName = concatString(getFileStamp("Backup"), fileDefine.extension.txt);
            const mime = TYPES.file.mime.TEXT_UTF8;
            saveAsFile(parts, mime, fileName);
            loading.off();
        }).catch(function(e) {
            new Notification.error().open(e.message);
            loading.off();
        });
        return null;
    },
    openOptionDataCopy: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const optionContents = _this.buildOptionContents();
        const option = { "min-width": "400px", "max-height": "530px" };
        const callback = function(dialogClose) {
            _this.saveOptionDataCopy(dialogClose);
        };
        const $templateButton = jqNode("button").text(upperCase(captions.template));
        const $export = jqNode("button").text(upperCase(captions.export));
        const $import = jqNode("button").text(upperCase(captions.import));
        $templateButton.click(function() {
            _this.openTemplateDataCopy();
        });
        $export.click(function() {
            const fileData = _this.saveOptionDataCopy();
            if(fileData) {
                if(isVoid(fileData.data)) {
                    new Notification().error().open(MESSAGES.nothing_data);
                    return false;
                }
                saveAsFile(JSON.stringify(fileData.data), TYPES.file.mime.TEXT_UTF8, concatString(getFileStamp("OptionData"), TYPES.file.extension.txt));
            }
        });
        $import.click(function() {
            const onReadFile = function(data) {
                try {
                    const parsedData = JSON.parse(data);
                    const structureCheck = function() {
                        let isCorrect = true;
                        parsedData.some(function(item) {
                            if(!(!isVoid(item.table) && typeIs(item.table).string) || !(!isVoid(item.script) && typeIs(item.script).string)) {
                                isCorrect = false;
                                return true;
                            }
                        });
                        return isCorrect;
                    };
                    if(parsedData.length >= 1 && structureCheck()) {
                        const $container = jqById(seId.optionContainerDataCopy).parent();
                        $container.empty().append(_this.buildOptionContents(parsedData));
                    }
                    else {
                        new Notification().error().open(MESSAGES.incorrect_data);
                    }
                }
                catch(e) {
                    new Notification().error().open(MESSAGES.incorrect_data);
                }
            };
            new FileController().setListener().allowedExtensions([TYPES.file.mime.TEXT]).access(onReadFile);
        });
        new Dialog().setContents(upperCase(captions.option, 0), optionContents, option).setButton([$import, $export, $templateButton]).open(callback);
        return null;
    },
    openTemplateDataCopy: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const template = _this.export.dataCopy.template;
        const dataCopyState = _this.state.dataCopy;
        const extractTableList = _this.getExtractTableListDataCopy(dataCopyState.ref.extractGroupStack);
        const $templateContainer = jqNode("div", { class: seClass.optionTemplateContainer });
        const $pannel = jqNode("div", { class: seClass.optionTemplatePannel });
        const $closeButton = jqNode("div", { class: seClass.optionTemplateClose });
        const $closeIcon = jqNode("i", { class: eIcon.timesCircle });
        $closeIcon.click(function() { $templateContainer.remove(); });
        $closeButton.append($closeIcon);
        $pannel.append($closeButton);
        const applyTemplate = function(menu) {
            const exec = function(viewerClose, data, state) {
                const $optionContainer = jqById(seId.optionContainerDataCopy);
                const $commandLines = $optionContainer.find(concatString(".", seClass.commandLine));
                const option = new Array();
                $commandLines.each(function(i, item) {
                    const $input = $(item).find("input");
                    const $textarea = $(item).find("textarea");
                    const table = _this.createInfoObject($input.val());
                    const script = _this.createInfoObject($textarea.val());
                    option.push({ table: table.value, script: script.value });
                });
                const result = {
                    error: false,
                    message: new Array()
                };
                const templateStack = new Array();
                const sb = new StringBuilder();
                template[menu].forEach(function(item) {
                    if(!item.enable || compareIndexOf(extractTableList, item.table) < 0) return;
                    const scriptInfo = {
                        isExist: false,
                        data: new Array()
                    };
                    item.columns.forEach(function(c) {
                        let cData = concatString("@", c);
                        const prop = accessObjectProperty(data, [item.table, c]);
                        if(!isVoid(prop)) {
                            scriptInfo.isExist = true;
                            cData = concatString(cData, SIGN.nl, prop);
                        }
                        scriptInfo.data.push(cData);
                    });
                    if(!scriptInfo.isExist) return;
                    const obj = {
                        table: item.table,
                        script: scriptInfo.data.join(SIGN.nl)
                    };
                    templateStack.push(obj);
                    if(find(item.table, option, ["table"], upperCase).isExist) {
                        result.error = true;
                        result.message.push(item.table);
                    }
                });
                if(result.error) {
                    const aet = "Already exists table";
                    const message = concatString(aet, SIGN.br, SIGN.br, result.message.join(SIGN.br));
                    new Notification().error().open(message);
                    return false;
                }
                const $commandArea = $optionContainer.find(concatString(".", seClass.optionCommandArea));
                templateStack.forEach(function(item) {
                    $commandArea.append(_this.createOptionCommandLine(item.table, item.script));
                });
                jqByClass(eClass.dialogContents).scrollTop(function() { return this.scrollHeight; });
                if(typeIs(viewerClose).function) {
                    dataCopyState.template[menu] = state;
                    viewerClose();
                }
            };
            const flag = _this.optionTemplateAction(menu, exec, $templateContainer);
            if(!flag) return false;
            exec();
        };
        Object.keys(template).forEach(function(menu) {
            const $labelButton = jqNode("div", { class: seClass.optionTemplateTab }).text(menu);
            $labelButton.click(function() { applyTemplate(menu); });
            $pannel.append($labelButton);
        });
        $templateContainer.append($pannel);
        jqByTag("body").append($templateContainer);
        return null;
    },
    optionTemplateAction: function(menu, sync, $templateContainer) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const dataCopyExport = _this.export.dataCopy;
        const exportTableListObject = dataCopyExport.tableListObject;
        const exportDefineSet = dataCopyExport.defineSet;
        const templateRules = dataCopyExport.templateRules;
        const dataCopyState = _this.state.dataCopy;
        const extractedData = dataCopyState.extractedData;
        const insertDataStatic = dataCopyState.insertDataStatic;
        const extractMap = dataCopyState.extractMap;
        const extractGroupStack = dataCopyState.ref.extractGroupStack;
        const eb = new ElementBuilder();
        const edst = exportDefineSet.table;
        const edsc = exportDefineSet.column;
        const edsbt = exportDefineSet.baseTable;
        const edswg = exportDefineSet.wg;
        const edsukt = exportDefineSet.ukt;
        let continueFlag = true;
        if(isVoid(dataCopyState.template)) dataCopyState.template = new Object();
        switch(menu) {
            case "Name_Birth": {
                continueFlag = false;
                const sb = new StringBuilder();
                const oDB = new DBUtils();
                const rules = templateRules[menu];
                const toList = dataCopyState.toList;
                const tables = rules.tables;
                const isContractorAvailable = true;
                const baseTableObject = exportDefineSet.baseTable;
                const getBaseTable = function(o) {
                    const wgTableKeyList = Object.keys(o).filter(function(key) {
                        return !isVoid(o[key].wg) && extractGroupStack.indexOf(o[key].wg) >= 0;
                    });
                    return o[wgTableKeyList[0]].table;
                };
                const baseTable = getBaseTable(baseTableObject);
                if(baseTable === edst.hktKihon) {
                    const msg = sb.reset().setList(["This data can not use", menu, "template"]).setPartition(SIGN.ws).get();
                    new Notification().error().open(msg);
                    break;
                }
                const def = {
                    target: {
                        insured: "insured",
                        contractor: "contractor",
                        customer: "customer",
                        contractorOnExist: "contractor_onExist",
                        receiver: "receiver",
                        requiredContractor: "required_contractor",
                        requiredContractorOnWeb: "required_contractor_onWeb",
                        requiredContractorOnWebOrPL: "required_contractor_onWebOrPaperLess"
                    },
                    elements: {
                        setting: {
                            labels: {
                                increment: "Increment",
                                exceptionSequence: "Exception Sequence"
                            },
                            increment: {
                                checkbox: {
                                    name: "increment-checkbox",
                                    label: "Auto increment",
                                    id: "auto-increment-checkbox_id"
                                },
                                count: {
                                    name: "increment-count",
                                    label: "Count",
                                    id: "auto-increment-count_id"
                                }
                            },
                            exceptionSequence: {
                                id: "opt-nb__setting-exception-sequence_id",
                                placeholder: "ex) 1,2,3... or 1-3,4...",
                                inputClass: "setting-exception-sequence_class"
                            },
                            labelClass: "label",
                            class: "setting"
                        },
                        name: {
                            labels: {
                                identifier: "Identifier",
                                id: "ID",
                                number: "Number",
                                digit: "Digit",
                                nameKana: "Name Kana",
                                nameKanji: "Name Kanji",
                                lastNameKana: "Last Name Kana",
                                firstNameKana: "First Name Kana",
                                lastNameKanji: "Last Name Kanji",
                                firstNameKanji: "First Name kanji"
                            },
                            ids: {
                                id: "name-id",
                                number: "name-number",
                                digit: "digit",
                                lastNameKana: "name-lastNameKana",
                                firstNameKana: "name-firstNameKana",
                                lastNameKanji: "name-lastNameKanji",
                                firstNameKanji: "name-firstNameKanji"
                            },
                            class: "name"
                        },
                        birthday: {
                            label: "Birthday",
                            id: "birthday",
                            class: "birth",
                            format: "YYYYMMDD"
                        }
                    },
                    keys: {
                        nameKana: "name_kana",
                        nameKanji: "name_kanji",
                        birthday: "birthday",
                        age: "age",
                        nameKanaL: "name_kana_l",
                        nameKanaF: "name_kana_f"
                    }
                };
                const settingDef = def.elements.setting;
                const nameDef = def.elements.name;
                const birthDef = def.elements.birthday;
                const initState = function() {
                    return {
                        increment: {
                            available: true,
                            count: SIGN.none
                        },
                        exceptionSequence: SIGN.none,
                        insured: {
                            name: {
                                id: SIGN.none,
                                number: SIGN.none,
                                digit: SIGN.none,
                                kana: { lastName: "ヒセイ", firstName: "ヒメイ" },
                                kanji: { lastName: "被姓", firstName: "被名" }
                            },
                            birthday: SIGN.none
                        },
                        contractor: {
                            name: {
                                id: SIGN.none,
                                number: SIGN.none,
                                digit: SIGN.none,
                                kana: { lastName: "ケイセイ", firstName: "ケイメイ" },
                                kanji: { lastName: "契姓", firstName: "契名" }
                            },
                            birthday: SIGN.none
                        }
                    };
                };
                const nbState = cloneJS(!isVoid(dataCopyState.template[menu]) ? dataCopyState.template[menu] : initState());
                const getAuth = function(id, w) { return concatString(id, SIGN.ub, w); };
                const executeList = isContractorAvailable ? [def.target.insured, def.target.contractor] : [def.target.insured];
                const $container = jqNode("div", { id: seId.optionTemplateNB });
                const $settingSection = jqNode("div", { class: eClass.viewerSection });
                const $settingTitle = jqNode("div", { class: eClass.sectionTitle }).text(upperCase(captions.setting, 0));
                const $settingContainer = jqNode("div").css({ "padding-top": "10px" });
                const $incrementLine = jqNode("div", { class: classes(seClass.commandLine, settingDef.class) });
                const $incrementLabel = jqNode("label", { class: settingDef.labelClass }).css({ "padding-bottom": "10px" }).text(settingDef.labels.increment);
                const incrementCheckboxItemList = [
                    {
                        label: settingDef.increment.checkbox.label,
                        attributes: {
                            id: settingDef.increment.checkbox.id,
                            name: settingDef.increment.checkbox.name,
                            value: SIGN.none
                        },
                        isChecked: nbState.increment.available,
                        optionClass: SIGN.none
                    }
                ];
                const $incrementCheckboxItem = eb.createCheckbox(incrementCheckboxItemList).getItem();
                const $incrementCountInput = jqNode("input", { id: settingDef.increment.count.id, class: eClass.applicationInput, placeholder: settingDef.increment.count.label, value: nbState.increment.count });
                $incrementCountInput.css({ "width": "50px", "margin-left": "10px", "margin-bottom": "5px" });
                new EventHandler($incrementCountInput).addInputEvent(function(e, value) {
                    const exp = new RegExpUtil(value);
                    if(!exp.isNumber() || exp.isOverflow(3)) return false;
                });
                eb.listAppend($incrementLine, [$incrementLabel, $incrementCheckboxItem, $incrementCountInput]);
                const $exceptionSequenceLine = jqNode("div", { class: classes(seClass.commandLine, settingDef.class) });
                const $exceptionSequenceLabel = jqNode("label", { class: settingDef.labelClass }).text(settingDef.labels.exceptionSequence);
                const $exceptionSequenceInput = jqNode("input", { id: settingDef.exceptionSequence.id, class: classes(eClass.applicationInput, settingDef.exceptionSequence.inputClass), placeholder: settingDef.exceptionSequence.placeholder, value: nbState.exceptionSequence });
                eb.listAppend($exceptionSequenceLine, [$exceptionSequenceLabel, $exceptionSequenceInput]);
                eb.listAppend($settingContainer, [$incrementLine, $exceptionSequenceLine]);
                $container.append(eb.listAppend($settingSection, [$settingTitle, $settingContainer]));
                const buildContents = function() {
                    executeList.forEach(function(targetId) {
                        const state = nbState[targetId];
                        const $section = jqNode("div", { class: eClass.viewerSection });
                        const $title = jqNode("div", { class: eClass.sectionTitle }).text(upperCase(targetId, 0));
                        const $targetContainer = jqNode("div").css({ "padding-top": "10px" });
                        const $nameIdentifierLine = jqNode("div", { class: classes(seClass.commandLine, nameDef.class) });
                        const $nameIdentifierLabel = jqNode("label").text(nameDef.labels.identifier);
                        const $nameIdInput = jqNode("input", { id: getAuth(targetId, nameDef.ids.id), class: eClass.applicationInput, placeholder: nameDef.labels.id, value: state.name.id });
                        const $nameNumberInput = jqNode("input", { id: getAuth(targetId, nameDef.ids.number), class: eClass.applicationInput, placeholder: nameDef.labels.number, value: state.name.number }).css("width", "80px");
                        new EventHandler($nameNumberInput).addInputEvent(function(e, value) {
                            const exp = new RegExpUtil(value);
                            if(!exp.isNumberWithFullWidth() || exp.isOverflow(3)) return false;
                        });
                        const $digitInput = jqNode("input", { id: getAuth(targetId, nameDef.ids.digit), class: eClass.applicationInput, placeholder: nameDef.labels.digit, value: state.name.digit }).css("width", "80px");
                        new EventHandler($digitInput).addInputEvent(function(e, value) {
                            const exp = new RegExpUtil(value);
                            if(!exp.isNumberWithFullWidth() || exp.isOverflow(1) || toNumber(value) >= 4) return false;
                        });
                        eb.listAppend($nameIdentifierLine, [$nameIdentifierLabel, $nameIdInput, $nameNumberInput, $digitInput]);
                        const $nameKanaLine = jqNode("div", { class: classes(seClass.commandLine, nameDef.class) });
                        const $nameKanaLabel = jqNode("label").text(nameDef.labels.nameKana);
                        const $nameKanaLastNameInput = jqNode("input", { id: getAuth(targetId, nameDef.ids.lastNameKana), class: eClass.applicationInput, placeholder: nameDef.labels.lastNameKana, value: state.name.kana.lastName });
                        const $nameKanaFirstNameInput = jqNode("input", { id: getAuth(targetId, nameDef.ids.firstNameKana), class: eClass.applicationInput, placeholder: nameDef.labels.firstNameKana, value: state.name.kana.firstName });
                        eb.listAppend($nameKanaLine, [$nameKanaLabel, $nameKanaLastNameInput, $nameKanaFirstNameInput]);
                        const $nameKanjiLine = jqNode("div", { class: classes(seClass.commandLine, nameDef.class) });
                        const $nameKanjiLabel = jqNode("label").text(nameDef.labels.nameKanji);
                        const $nameKanjiLastNameInput = jqNode("input", { id: getAuth(targetId, nameDef.ids.lastNameKanji), class: eClass.applicationInput, placeholder: nameDef.labels.lastNameKanji, value: state.name.kanji.lastName });
                        const $nameKanjiFirstNameInput = jqNode("input", { id: getAuth(targetId, nameDef.ids.firstNameKanji), class: eClass.applicationInput, placeholder: nameDef.labels.firstNameKanji, value: state.name.kanji.firstName });
                        eb.listAppend($nameKanjiLine, [$nameKanjiLabel, $nameKanjiLastNameInput, $nameKanjiFirstNameInput]);
                        const $birthLine = jqNode("div", { class: classes(seClass.commandLine, birthDef.class) });
                        const $birthLabel = jqNode("label").text(birthDef.label);
                        const $birthInput = jqNode("textarea", { id: getAuth(targetId, birthDef.id), class: eClass.applicationTextarea, placeholder: birthDef.format }).val(state.birthday);
                        eb.listAppend($birthLine, [$birthLabel, $birthInput]);
                        eb.listAppend($targetContainer, [$nameIdentifierLine, $nameKanaLine, $nameKanjiLine, $birthLine]);
                        $container.append(eb.listAppend($section, [$title, $targetContainer]));
                    });
                };
                const initIncrementCount = function($element) {
                    if(!$element) return false;
                    const available = nbState.increment.available;
                    if(available) $element.addClass(eClass.readonly).prop("readonly", true);
                    else $element.removeClass(eClass.readonly).prop("readonly", false);
                };
                const setEvent = function() {
                    executeList.forEach(function(targetId) {
                        const incrementCheckboxElement = concatString("input[name=", settingDef.increment.checkbox.name, "]");
                        new EventHandler($(incrementCheckboxElement)).addEvent("change", function(e) {
                            const target = e.target;
                            const available = target.checked;
                            nbState.increment.available = available;
                            const $incrementCountInput = jqById(settingDef.increment.count.id);
                            initIncrementCount($incrementCountInput);
                        });
                    });
                };
                const callback = function(viewerClose) {
                    try {
                        const keys = def.keys;
                        const templatePrintObject = new Object();
                        nbState.increment.count = jqById(settingDef.increment.count.id).val();
                        nbState.exceptionSequence = jqById(settingDef.exceptionSequence.id).val();
                        executeList.forEach(function(targetId) {
                            nbState[targetId].name.id = jqById(getAuth(targetId, nameDef.ids.id)).val();
                            nbState[targetId].name.number = jqById(getAuth(targetId, nameDef.ids.number)).val();
                            nbState[targetId].name.digit = jqById(getAuth(targetId, nameDef.ids.digit)).val();
                            nbState[targetId].name.kana.lastName = jqById(getAuth(targetId, nameDef.ids.lastNameKana)).val();
                            nbState[targetId].name.kana.firstName = jqById(getAuth(targetId, nameDef.ids.firstNameKana)).val();
                            nbState[targetId].name.kanji.lastName = jqById(getAuth(targetId, nameDef.ids.lastNameKanji)).val();
                            nbState[targetId].name.kanji.firstName = jqById(getAuth(targetId, nameDef.ids.firstNameKanji)).val();
                            nbState[targetId].birthday = jqById(getAuth(targetId, birthDef.id)).val();
                        });
                        const getState = function(targetId) {
                            return nbState[targetId];
                        };
                        const targetState = {
                            insured: getState(def.target.insured),
                            contractor: getState(def.target.contractor)
                        };
                        const calcAge = function(inputDate, submissionDate) {
                            if(isVoid(inputDate)) return SIGN.none;
                            else if(inputDate === VARIABLE.eq) return VARIABLE.eq;
                            const exp = new RegExpUtil(submissionDate);
                            if(!exp.isYYYYMMDD()) {
                                throw new Error("Submission date format is invalid");
                            }
                            const inYear = Number(inputDate.substr(0, 4));
                            const inMonth = Number(inputDate.substr(4, 2));
                            const inDate = Number(inputDate.substr(6, 2));
                            const smYear = Number(submissionDate.substr(0, 4));
                            const smMonth = Number(submissionDate.substr(4, 2));
                            const smDate = Number(submissionDate.substr(6, 2));
                            const calcY = smYear - inYear;
                            const calcM = smMonth - inMonth;
                            const calcD = smDate - inDate;
                            if(calcY < 0) return null;
                            else if(calcY <= 0) {
                                if(calcM < 0) return null;
                                if(calcM === 0 && calcD < 0) return null;
                            }
                            if(calcM > 0) return String(calcY);
                            if(calcD > 0) {
                                if(calcY === 0) return String(calcY);
                                return String(calcY - 1);
                            }
                            return String(calcY);
                        };
                        const v = new Validation();
                        const vTypes = v.getTypes();
                        const checkAllResult = {
                            error: false,
                            messageList: new Array()
                        };
                        const optionObj = {
                            size: {
                                data: { n: toList.length, type: "data" },
                                count: { n: 0, type: "count" },
                                birthday: { n: 0, type: "birthday" }
                            },
                            types: { data: "d", count: "c", birthday: "b" },
                            baseType: null,
                            baseSize: 0,
                            baseSizeN: 0
                        };
                        const increment = nbState.increment;
                        const exceptionSequence = nbState.exceptionSequence;
                        let exceptionSequenceList = new Array();
                        const settingMsgStack = new Array();
                        if(!increment.available) {
                            const incrementCount = _this.createInfoObject(increment.count, settingDef.increment.count.label);
                            const outOfRangeValidate = function() {
                                const actionLayout = v.getActionLayout();
                                if(Number(increment.count) > toList.length) {
                                    actionLayout.error = true;
                                    actionLayout.message = concatString(settingDef.increment.count.label, " out of range");
                                }
                                return actionLayout;
                            };
                            const actionObj = { "outOfRange": outOfRangeValidate };
                            const incrementCountLayout = v.getLayout(v.initLayout(incrementCount.value, incrementCount.name), [vTypes.required, vTypes.notSpace, vTypes.numeric, "outOfRange"], actionObj);
                            const result = v.reset().append(incrementCountLayout).exec();
                            if(result.error) {
                                checkAllResult.error = true;
                                settingMsgStack.push(result.message);
                            }
                        }
                        if(!isVoid(exceptionSequence)) {
                            let hasError = false;
                            const label = settingDef.labels.exceptionSequence;
                            const esList = exceptionSequence.split(SIGN.c);
                            esList.some(function(n) {
                                const isNumber = new RegExpUtil(n).isNumber();
                                if(!isNumber) {
                                    const gn = n.split(SIGN.dash);
                                    const isNumberOnGn = gn.filter(function(gnn) {
                                        return new RegExpUtil(gnn).isNumber();
                                    });
                                    if((gn.length !== 2) || (isNumberOnGn.length !== 2) || (gn[0] > gn[1])) {
                                        checkAllResult.error = true;
                                        settingMsgStack.push(concatString(label, " : ", MESSAGES.invalid_format));
                                        hasError = true;
                                        return true;
                                    }
                                    else {
                                        for(let i = Number(gn[0]); i <= Number(gn[1]); i++) {
                                            exceptionSequenceList.push(i);
                                        }
                                    }
                                }
                                else {
                                    exceptionSequenceList.push(Number(n));
                                }
                            });
                            if(!hasError) {
                                const result = duplicationCheckForArray(exceptionSequenceList);
                                if(result.hasError) {
                                    checkAllResult.error = true;
                                    settingMsgStack.push(concatString(label, " : Duplication error [", result.data.join(SIGN.cw), "]"));
                                }
                                else if(getMaxNumInArray(exceptionSequenceList) > (increment.available ? toList.length : Number(increment.count))) {
                                    checkAllResult.error = true;
                                    settingMsgStack.push(concatString(label, " out of range"));
                                }
                            }
                        }
                        if(checkAllResult.error) {
                            const targetLabel = concatString(SIGN.abs, upperCase(captions.setting, 0), SIGN.abe, SIGN.br);
                            checkAllResult.messageList.push(targetLabel + settingMsgStack.join(SIGN.br));
                        }
                        const checkValueObject = new Object();
                        executeList.forEach(function(targetId) {
                            checkValueObject[targetId] = {
                                nameGroup: new Array(),
                                nameDependentForm: new Array(),
                                birthday: new Array()
                            };
                            const state = nbState[targetId];
                            v.reset();
                            const checkList = [
                                {
                                    label: concatString(nameDef.labels.identifier, " > ", nameDef.labels.id),
                                    value: state.name.id,
                                    type: nameDef.ids.id,
                                    isNameGroup: true,
                                    isNameDependentForm: false,
                                    enable: true
                                },
                                {
                                    label: concatString(nameDef.labels.identifier, " > ", nameDef.labels.number),
                                    value: state.name.number,
                                    type: nameDef.ids.number,
                                    isNameGroup: true,
                                    isNameDependentForm: false,
                                    enable: true
                                },
                                {
                                    label: concatString(nameDef.labels.identifier, " > ", nameDef.labels.digit),
                                    value: state.name.digit,
                                    type: nameDef.ids.digit,
                                    isNameGroup: false,
                                    enable: true
                                },
                                {
                                    label: concatString(nameDef.labels.nameKana, " > ", nameDef.labels.lastNameKana),
                                    value: state.name.kana.lastName,
                                    type: nameDef.ids.lastNameKana,
                                    isNameGroup: true,
                                    isNameDependentForm: true,
                                    enable: true
                                },
                                {
                                    label: concatString(nameDef.labels.nameKana, " > ", nameDef.labels.firstNameKana),
                                    value: state.name.kana.firstName,
                                    type: nameDef.ids.firstNameKana,
                                    isNameGroup: true,
                                    isNameDependentForm: true,
                                    enable: true
                                },
                                {
                                    label: concatString(nameDef.labels.nameKanji, " > ", nameDef.labels.lastNameKanji),
                                    value: state.name.kanji.lastName,
                                    type: nameDef.ids.lastNameKanji,
                                    isNameGroup: true,
                                    isNameDependentForm: true,
                                    enable: true
                                },
                                {
                                    label: concatString(nameDef.labels.nameKanji, " > ", nameDef.labels.firstNameKanji),
                                    value: state.name.kanji.firstName,
                                    type: nameDef.ids.firstNameKanji,
                                    isNameGroup: true,
                                    isNameDependentForm: true,
                                    enable: true
                                },
                                {
                                    label: birthDef.label,
                                    value: state.birthday,
                                    type: birthDef.id,
                                    isNameGroup: false,
                                    enable: true
                                }
                            ];
                            const nameGroupSize = checkList.filter(function(item) { return item.isNameGroup && item.enable; }).length;
                            const nameDependentFormSize = checkList.filter(function(item) { return item.isNameGroup && item.isNameDependentForm && item.enable; }).length;
                            checkList.forEach(function(item, i) {
                                if(!item.enable) return;
                                let layout = null;
                                const checkValueList = getExistArray(item.value.split(SIGN.nl));
                                const checkValue = checkValueList.join();
                                if(item.type === nameDef.ids.number || item.type === nameDef.ids.digit) {
                                    layout = v.getLayout(v.initLayout(item.value, item.label), [vTypes.notSpace, vTypes.numeric]);
                                }
                                else if(item.type === birthDef.id) {
                                    if(!isVoid(checkValue)) {
                                        const formatValidate = function() {
                                            const actionLayout = v.getActionLayout();
                                            const messageStack = new Array();
                                            checkValueList.forEach(function(bd, j, arry) {
                                                if(!isVoid(bd)) {
                                                    if(bd === VARIABLE.eq) return;
                                                    const exp = new RegExpUtil(bd);
                                                    const fromKey = extractMap[Object.keys(extractMap)[j]];
                                                    if(isVoid(fromKey)) return;
                                                    const mosKihonData = oDB.where(extractedData[fromKey], edst.mosKihon);
                                                    const submissionDate = mosKihonData.ref[edsc.mosYmd][0];
                                                    if(!exp.isYYYYMMDD()) {
                                                        actionLayout.error = true;
                                                        messageStack.push(concatString("[Line", setCharPadding(String(j + 1), String(arry.length).length), "]", item.label, " : ", MESSAGES.invalid_format, sb.setBrackets(bd)));
                                                    }
                                                    else if(typeIs(calcAge(bd, submissionDate)).null) {
                                                        actionLayout.error = true;
                                                        messageStack.push(concatString("[Line", setCharPadding(String(j + 1), String(arry.length).length), "]", item.label, " is over the submission date(", submissionDate, ")"));
                                                    }
                                                }
                                            });
                                            actionLayout.message = messageStack.join(SIGN.br);
                                            return actionLayout;
                                        };
                                        const outOfRangeValidate = function() {
                                            const actionLayout = v.getActionLayout();
                                            if(checkValueList.length > toList.length) {
                                                actionLayout.error = true;
                                                actionLayout.message = concatString(item.label, " out of range");
                                            }
                                            return actionLayout;
                                        };
                                        const actionObj = { "format": formatValidate, "outOfRange": outOfRangeValidate };
                                        layout = v.getLayout(v.initLayout(item.value, item.label), ["format", "outOfRange"], actionObj);
                                        optionObj.size.birthday.n = checkValueList.length;
                                    }
                                }
                                else {
                                    layout = v.getLayout(v.initLayout(item.value, item.label), [vTypes.notSpace]);
                                }
                                if(!isVoid(checkValue)) {
                                    if(item.isNameGroup) {
                                        checkValueObject[targetId].nameGroup.push(checkValue);
                                        if(item.isNameDependentForm) {
                                            checkValueObject[targetId].nameDependentForm.push(checkValue);
                                        }
                                    }
                                    else {
                                        checkValueObject[targetId].birthday.push(checkValue);
                                    }
                                }
                                if(!isVoid(layout)) v.append(layout);
                            });
                            const result = v.exec();
                            const targetLabel = concatString(SIGN.abs, upperCase(targetId, 0), SIGN.abe, SIGN.br);
                            if(result.error) {
                                checkAllResult.error = true;
                                checkAllResult.messageList.push(targetLabel + result.message);
                            }
                            else {
                                const cvo = checkValueObject[targetId];
                                if((cvo.nameGroup.length + cvo.birthday.length) <= 0) {
                                    checkAllResult.error = true;
                                    checkAllResult.messageList.push(targetLabel + "Please input name or birthday");
                                }
                                else if(cvo.nameDependentForm.length >= 1 && cvo.nameDependentForm.length < nameDependentFormSize) {
                                    checkAllResult.error = true;
                                    checkAllResult.messageList.push(targetLabel + "The name input field(Kana&Kanji) is not complete");
                                }
                            }
                        });
                        if(checkAllResult.error) {
                            throw new Error(checkAllResult.messageList.join(concatString(SIGN.br, SIGN.br)));
                        }
                        else {
                            exceptionSequenceList = exceptionSequenceList.sort(function(a, b) {
                                if(a < b) return -1;
                                else if(a > b) return 1;
                                return 0;
                            });
                            if(!increment.available) {
                                optionObj.size.count.n = Number(increment.count);
                                optionObj.size.data.n = 0;
                            }
                            const sizeCollection = Object.keys(optionObj.size).map(function(key) { return optionObj.size[key]; });
                            sizeCollection.reduce(function(prev, curr, i) {
                                if(prev.n >= curr.n) {
                                    optionObj.baseType = optionObj.types[prev.type];
                                    optionObj.baseSize = prev.n;
                                    return prev;
                                }
                                else {
                                    optionObj.baseType = optionObj.types[curr.type];
                                    optionObj.baseSize = curr.n;
                                    return curr;
                                }
                            });
                            if(optionObj.baseType === optionObj.types.birthday) {
                                const os = optionObj.size;
                                optionObj.baseSizeN = !increment.available ? os.count.n : os.data.n;
                            }
                            else {
                                optionObj.baseSizeN = optionObj.baseSize;
                            }
                            const generator = function(fromData, table, column, c, toIdx, tableSelData, kokykKanrenData, baseData, sequence) {
                                const dataStack = new Array();
                                const type = c.type;
                                const target = c.target;
                                const separator = c.separator;
                                const wg = Object.keys(exportTableListObject).filter(function(key) {
                                    const tableList = exportTableListObject[key];
                                    if(compareIndexOf(tableList, table) >= 0) {
                                        return true;
                                    }
                                })[0];
                                const isCustomer = target === def.target.customer;
                                const keihiKbn = kokykKanrenData.ref[edsc.keihiKbn];
                                const isSameKeihi = keihiKbn.length === 1 && keihiKbn[0] == 3;
                                const mosKbn = Number(baseData.ref[edsc.mosKbn][0]);
                                const isWeb = mosKbn === 4;
                                const isPaperLess = mosKbn === 5;
                                const setDataByKeihi = function(insuredData, contractorData) {
                                    if(isSameKeihi) {
                                        dataStack.push(insuredData);
                                    }
                                    else if(keihiKbn.length >= 2) {
                                        keihiKbn.forEach(function(kbn) {
                                            switch(Number(kbn)) {
                                                case 1: {
                                                    if(!isVoid(contractorData)) {
                                                        dataStack.push(contractorData);
                                                    }
                                                    break;
                                                }
                                                case 2: {
                                                    if(!isVoid(insuredData)) {
                                                        dataStack.push(insuredData);
                                                    }
                                                    break;
                                                }
                                            }
                                        });
                                    }
                                };
                                const getId = function(state) {
                                    const n = state.name.number;
                                    const d = isVoid(state.name.digit) ? 3 : state.name.digit;
                                    const num = isVoid(n) ? SIGN.none : setCharPadding(Number(n) + sequence, d);
                                    return concatString(state.name.id, num);
                                };
                                if([keys.nameKana, keys.nameKanji, keys.nameKanaF, keys.nameKanaL].indexOf(type) >= 0 && toIdx < optionObj.baseSizeN) {
                                    const getName = function(ti) {
                                        const state = targetState[ti];
                                        const o = {
                                            identifier: getId(state),
                                            lastName: SIGN.none,
                                            firstName: SIGN.none
                                        };
                                        switch(type) {
                                            case keys.nameKana: {
                                                o.lastName = concatString(o.identifier, state.name.kana.lastName);
                                                o.firstName = concatString(o.identifier, state.name.kana.firstName);
                                                break;
                                            }
                                            case keys.nameKanji: {
                                                o.lastName = concatString(o.identifier, state.name.kanji.lastName);
                                                o.firstName = concatString(o.identifier, state.name.kanji.firstName);
                                                break;
                                            }
                                            case keys.nameKanaF: {
                                                o.firstName = concatString(o.identifier, state.name.kana.firstName);
                                                break;
                                            }
                                            case keys.nameKanaL: {
                                                o.firstName = concatString(o.identifier, state.name.kana.lastName);
                                                break;
                                            }
                                        }
                                        const fullName = [o.lastName, o.firstName].join(separator);
                                        return toFullWidth(fullName);
                                    };
                                    const insuredName = getName(def.target.insured);
                                    const contractorName = getName(def.target.contractor);
                                    if(isCustomer) {
                                        setDataByKeihi(insuredName, contractorName);
                                    }
                                    else {
                                        const scData = tableSelData.ref[column];
                                        const pushData = function(data) {
                                            scData.forEach(function() {
                                                dataStack.push(data);
                                            });
                                        };
                                        switch(target) {
                                            case def.target.insured: {
                                                pushData(insuredName);
                                                break;
                                            }
                                            case def.target.contractor: {
                                                pushData(contractorName);
                                                break;
                                            }
                                            case def.target.contractorOnExist: {
                                                pushData(isSameKeihi ? SIGN.none : contractorName);
                                                break;
                                            }
                                            case def.target.receiver: {
                                                const uktSyuKbnList = tableSelData.ref[edsc.uktSyuKbn];
                                                const uktNameKana = edsukt.name.kana;
                                                const uktNameKanji = edsukt.name.kanji;
                                                const receiverStack = new Array();
                                                const getReceiverName = function(uktSyuKbn) {
                                                    const state = targetState[def.target.insured];
                                                    const o = {
                                                        identifier: getId(state),
                                                        lastName: SIGN.none,
                                                        firstName: SIGN.none
                                                    };
                                                    switch(type) {
                                                        case keys.nameKana: {
                                                            const lastName = uktNameKana.lastName[uktSyuKbn];
                                                            const firstName = uktNameKana.firstName[uktSyuKbn];
                                                            o.lastName = isVoid(lastName) ? SIGN.none : concatString(o.identifier, lastName);
                                                            o.firstName = isVoid(firstName) ? SIGN.none : concatString(o.identifier, firstName);
                                                            break;
                                                        }
                                                        case keys.nameKanji: {
                                                            const lastName = uktNameKanji.lastName[uktSyuKbn];
                                                            const firstName = uktNameKanji.firstName[uktSyuKbn];
                                                            o.lastName = isVoid(lastName) ? SIGN.none : concatString(o.identifier, lastName);
                                                            o.firstName = isVoid(firstName) ? SIGN.none : concatString(o.identifier, firstName);
                                                            break;
                                                        }
                                                    }
                                                    if(isVoid(o.lastName) || isVoid(o.firstName)) {
                                                        return SIGN.none;
                                                    }
                                                    const fullName = [o.lastName, o.firstName].join(separator);
                                                    return toFullWidth(fullName);
                                                };
                                                scData.forEach(function(item, i) {
                                                    const uktSyuKbn = !isVoid(c.uktSyuKbn) ? c.uktSyuKbn : uktSyuKbnList[i];
                                                    if(isVoid(item)) {
                                                        dataStack.push(item);
                                                        return;
                                                    }
                                                    dataStack.push(getReceiverName(uktSyuKbn));
                                                });
                                                break;
                                            }
                                            case def.target.requiredContractor: {
                                                pushData(isSameKeihi ? insuredName : contractorName);
                                                break;
                                            }
                                            case def.target.requiredContractorOnWeb: {
                                                if(isWeb) {
                                                    pushData(isSameKeihi ? insuredName : contractorName);
                                                }
                                                break;
                                            }
                                            case def.target.requiredContractorOnWebOrPL: {
                                                if(isWeb || isPaperLess) {
                                                    pushData(isSameKeihi ? insuredName : contractorName);
                                                }
                                                break;
                                            }
                                        }
                                    }
                                }
                                else if(type === keys.birthday) {
                                    const getBirthDay = function(ti) {
                                        switch(ti) {
                                            case def.target.requiredContractor: {
                                                ti = isSameKeihi ? def.target.insured : def.target.contractor;
                                                break;
                                            }
                                            case def.target.contractorOnExist: {
                                                ti = isSameKeihi ? SIGN.none : def.target.contractor;
                                                break;
                                            }
                                            case def.target.requiredContractorOnWeb: {
                                                if(isWeb) {
                                                    ti = isSameKeihi ? def.target.insured : def.target.contractor;
                                                }
                                                break;
                                            }
                                            case def.target.requiredContractorOnWebOrPL: {
                                                if(isWeb || isPaperLess) {
                                                    ti = isSameKeihi ? def.target.insured : def.target.contractor;
                                                }
                                                break;
                                            }
                                        }
                                        const state = targetState[ti];
                                        if(isVoid(state)) return null;
                                        const ba = state.birthday.split(SIGN.nl);
                                        return ba.length <= 0 ? SIGN.none : ba[toIdx];
                                    };
                                    if(isCustomer) {
                                        const insuredBirthday = getBirthDay(def.target.insured);
                                        const contractorBirthday = getBirthDay(def.target.contractor);
                                        setDataByKeihi(insuredBirthday, contractorBirthday);
                                    }
                                    else {
                                        dataStack.push(getBirthDay(target));
                                    }
                                }
                                else if(type === keys.age) {
                                    const submissionDate = baseData.ref[edsc.mosYmd][0];
                                    const getAge = function(ti) {
                                        switch(ti) {
                                            case def.target.requiredContractor: {
                                                ti = isSameKeihi ? def.target.insured : def.target.contractor;
                                                break;
                                            }
                                            case def.target.contractorOnExist: {
                                                ti = isSameKeihi ? SIGN.none : def.target.contractor;
                                                break;
                                            }
                                        }
                                        const state = targetState[ti];
                                        if(isVoid(state)) return null;
                                        const ba = state.birthday.split(SIGN.nl);
                                        return ba.length <= 0 ? SIGN.none : calcAge(ba[toIdx], submissionDate);
                                    };
                                    if(isCustomer) {
                                        const insuredAge = getAge(def.target.insured);
                                        const contractorAge = getAge(def.target.contractor);
                                        setDataByKeihi(insuredAge, contractorAge);
                                    }
                                    else {
                                        dataStack.push(getAge(target, submissionDate));
                                    }
                                }
                                const mapFunc = function(item) {
                                    if(isVoid(item)) {
                                        return VARIABLE.eq;
                                    }
                                    return item;
                                };
                                const convertedData = dataStack.map(mapFunc);
                                return convertedData.length >= 1 ? convertedData.join(SIGN.nl) : SIGN.none;
                            };
                            const sequenceMap = {
                                list: new Array(),
                                data: new Object()
                            };
                            const getSequence = function(i) {
                                const esl = exceptionSequenceList;
                                if(isVoid(sequenceMap.data[i])) {
                                    sequenceMap.data[i] = i;
                                    let count = 0;
                                    const calc = function() {
                                        const v = (i + 1) + count;
                                        const idx = esl.indexOf(v);
                                        const sIdx = sequenceMap.list.indexOf(v);
                                        if(idx >= 0 || sIdx >= 0) {
                                            count++;
                                            calc();
                                        }
                                        else {
                                            sequenceMap.list.push(v);
                                            sequenceMap.data[i] = v - 1;
                                        }
                                    };
                                    calc();
                                }
                                return sequenceMap.data[i];
                            };
                            Object.keys(tables).forEach(function(table) {
                                templatePrintObject[table] = new Object();
                                const co = new Object();
                                const ins = getProperty(insertDataStatic, table);
                                if(isVoid(ins)) return;
                                let expSeq = 0;
                                Object.keys(ins).some(function(toKey, toIdx) {
                                    if(toIdx >= optionObj.baseSize) {
                                        return true;
                                    }
                                    const sequence = getSequence(toIdx);
                                    const fromKey = extractMap[toKey];
                                    const fromData = extractedData[fromKey];
                                    const exd = getProperty(fromData, table);
                                    if(!isVoid(exd)) {
                                        const t = getProperty(tables, table);
                                        const tableSelData = oDB.where(fromData, table);
                                        const kokykKanrenData = oDB.where(fromData, edst.kokykKanren);
                                        const baseData = oDB.where(fromData, baseTable);
                                        Object.keys(t).forEach(function(column) {
                                            const c = getProperty(t, column);
                                            if(isVoid(co[column])) {
                                                co[column] = new Object();
                                            }
                                            const inData = generator(fromData, table, column, c, toIdx, tableSelData, kokykKanrenData, baseData, sequence);
                                            co[column][toKey] = isVoid(inData) ? VARIABLE.eq : inData;
                                        });
                                    }
                                });
                                Object.keys(co).forEach(function(column) {
                                    const dataMap = Object.keys(co[column]).map(function(toKey) {
                                        return co[column][toKey];
                                    });
                                    const existSize = dataMap.filter(function(item) {
                                        if(!isVoid(item) && item !== VARIABLE.eq) {
                                            return true;
                                        }
                                    }).length;
                                    templatePrintObject[table][column] = existSize >= 1 ? dataMap.join(SIGN.nl) : SIGN.none;
                                });
                            });
                        }
                        sync(viewerClose, templatePrintObject, nbState);
                    }
                    catch(e) {
                        new Notification().error().open(e.message);
                    }
                };
                buildContents();
                initIncrementCount($incrementCountInput);
                new Viewer().setContents(menu, $container).open(callback).onLoad(setEvent);
                break;
            }
            default: {
                continueFlag = true;
                break;
            }
        }
        $templateContainer.remove();
        return continueFlag;
    },
    checkDataCopy: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const _event = _this.event;
        const dataCopyEvent = _event.dataCopy;
        const dataCopyExport = _this.export.dataCopy;
        const exportDefineSet = dataCopyExport.defineSet;
        const baseTable = exportDefineSet.baseTable;
        const edsc = exportDefineSet.column;
        const sb = new StringBuilder();
        const status = {
            hasError: false,
            msgList: new Array(),
            db: null
        };
        const loading = new Loading();
        loading.on().then(function() {
            const policyNumberTo = _this.createInfoObject(jqById(seId.policyNumberTo).val(), captions.policyNumberTo);
            const v = new Validation();
            const vTypes = v.getTypes();
            const policyNumberToLayout = v.getLayout(v.initLayout(policyNumberTo.value, policyNumberTo.name, v.getSizeLayout(11, 11, SIGN.nl)), [vTypes.requiredWithLineBreak, vTypes.notSpace, vTypes.numericWithLineBreak, vTypes.size]);
            v.reset().append(policyNumberToLayout);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            const pnt = policyNumberTo.value;
            const pntList = getExistArray(pnt.split(SIGN.nl));
            const dCheck = duplicationCheckForArray(pntList);
            if(dCheck.hasError) {
                const dMsg = [concatString("Policy Number(To) has duplication error", SIGN.br)].concat(dCheck.data).join(SIGN.br);
                throw new Error(dMsg);
            }
            const extractGroupStack = new Array();
            $(dataCopyEvent.element.extractGroupChecked).each(function() {
                extractGroupStack.push($(this).val());
            });
            const inConditions = pntList.map(function(item) { return concatString(SIGN.sq, item, SIGN.sq); }).join(SIGN.cw);
            const queryCollection = new Array();
            Object.keys(baseTable).forEach(function(key) {
                const item = baseTable[key];
                if(item.required || extractGroupStack.indexOf(item.wg) >= 0) {
                    const query = sb.setQuery(["SELECT", edsc.policyNumber, "FROM", item.table, "WHERE", edsc.policyNumber, "IN (", inConditions, ")"]);
                    queryCollection.push(query);
                }
            });
            status.db = new DBUtils().connect(_this.state.info);
            queryCollection.forEach(function(query) {
                const dataSet = status.db.executeSelect(query).dataSet;
                if(dataSet.count >= 1) {
                    const pnList = dataSet.data.map(function(record) { return record[0]; });
                    status.hasError = true;
                    status.msgList = status.msgList.concat(pnList);
                }
            });
            const ngMsg = concatString("Already exists", SIGN.br);
            const okMsg = "You can use these";
            if(status.hasError) {
                throw new Error(concatString(ngMsg, removeDuplicationArray(status.msgList).join(SIGN.br)));
            }
            else {
                new Notification().complete().open(okMsg);
            }
            if(!isVoid(status.db)) {
                status.db.close();
            }
            loading.off();
        }).catch(function(e) {
            if(!isVoid(status.db)) {
                status.db.close();
            }
            new Notification().error().open(e.message);
            loading.off();
        });
    },
    importDataCopy: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.dataCopy;
        const _event = _this.event;
        const dataCopyEvent = _event.dataCopy;
        const dataCopyState = _this.state.dataCopy;
        const onReadFile = function(data) {
            let isImporting = true;
            let isSingleMode = true;
            let pnfElementId = SIGN.none;
            switch(dataCopyEvent.status.extractMode) {
                case types.design.dataCopy.extractMode.single:{
                    pnfElementId = seId.policyNumberFrom;
                    isSingleMode = true;
                    break;
                }
                case types.design.dataCopy.extractMode.multiple: {
                    pnfElementId = seId.policyNumberFromTextarea;
                    isSingleMode = false;
                    break;
                }
            }
            try {
                const importData = JSON.parse(data);
                isImporting = false;
                const fromKeyList = Object.keys(importData);
                const fromKeyString = fromKeyList.join(SIGN.nl);
                if(fromKeyList.length <= 0) {
                    throw new Error(MESSAGES.incorrect_data);
                }
                else if(fromKeyList.length === 1 && !isSingleMode) {
                    throw new Error("This data can be import only on single mode");
                }
                else if(fromKeyList.length >= 2 && isSingleMode) {
                    throw new Error("This data can be import only on multiple mode");
                }
                else {
                    const policyNumberFrom = _this.createInfoObject(fromKeyString, captions.policyNumberFrom);
                    const v = new Validation();
                    const vTypes = v.getTypes();
                    const policyNumberFromLayout = v.getLayout(v.initLayout(policyNumberFrom.value, policyNumberFrom.name, v.getSizeLayout(11, 11, SIGN.nl)), [vTypes.required, vTypes.notSpace, vTypes.numericWithLineBreak, vTypes.size]);
                    v.reset().append(policyNumberFromLayout);
                    const result = v.exec();
                    if(result.error) {
                        throw new Error(MESSAGES.incorrect_data);
                    }
                }
                jqById(pnfElementId).val(fromKeyString);
                _this.state.dataCopy.ref = createObject("import", {
                    fromKeyList: fromKeyList,
                    data: importData
                });
                _this.actionControllerDataCopy(phaseType.import);
            }
            catch(e) {
                const errMsg = isImporting ? MESSAGES.incorrect_data : e.message;
                new Notification().error().open(errMsg);
            }
        };
        new FileController().setListener().allowedExtensions([TYPES.file.mime.TEXT]).access(onReadFile);
        return null;
    },
    getDataCopySelectQuery: function(table, pn, isFromDelete, isInclude) {
        const _this = this;
        const dataCopyExport = _this.export.dataCopy;
        const keySet = dataCopyExport.keySet;
        const defineSet = dataCopyExport.defineSet;
        const edst = defineSet.table;
        const edsc = defineSet.column;
        const sb = new StringBuilder();
        let query = "";
        const clause = !isFromDelete ? " = " : (isInclude ? " IN " : " NOT IN ");
        const clauseIn = !isFromDelete ? " IN " : (isInclude ? " IN " : " NOT IN ");
        const clauseEx = !isFromDelete ? " = " : " IN ";
        const existsClause = !isFromDelete ? " EXISTS " : (isInclude ? " EXISTS " : " NOT EXISTS ");
        const defaultKey = queryEscape(keySet.defaultKey);
        const getValue = function(func) {
            if(!isFromDelete) {
                return typeIs(func).function ? sb.sq(func(pn)) : sb.sq(pn);
            }
            else {
                const pnMap = pn.map(function(p) {
                    return typeIs(func).function ? sb.sq(func(p)) : sb.sq(p);
                }).join(", ");
                return concatString(SIGN.bs, pnMap, SIGN.be);
            }
        };
        if(!getProperty(keySet, table)) {
            query = concatString("SELECT * FROM ", table, " WHERE ", defaultKey, clause, getValue());
        }
        else {
            const key = queryEscape(getProperty(keySet, table).key);
            const type = getProperty(keySet, table).type;
            switch(type) {
                case 0: {
                    const joinCond = concatString("A.", key, " = ", "B.", key);
                    const mainCond = concatString("B.", edsc.policyNumber, clauseEx, getValue());
                    query = concatString("SELECT * FROM ", table, " A WHERE", existsClause, "(SELECT * FROM ", edst.kokykKanren, " B WHERE ", joinCond, " AND ", mainCond, ")");
                    break;
                }
                case 1: {
                    const slice1 = function(v) { return v.slice(1, v.length - 1); };
                    const slice2 = function(v) { return v.slice(0, 1); };
                    const withCond = !isFromDelete ? concatString(" AND S_HATUBANKEY = ", getValue(slice2)) : SIGN.none;
                    query = concatString("SELECT * FROM ", table, " WHERE ", key, clause, getValue(slice1), withCond);
                    break;
                }
                case 2: {
                    const joinCond = concatString("A.", key, " = ", "B.", key);
                    const mainCond = concatString("B.", edsc.policyNumber, clauseEx, getValue());
                    query = concatString("SELECT * FROM ", table, " A WHERE", existsClause, "(SELECT * FROM ", edst.mosKihon, " B WHERE ", joinCond, " AND ", mainCond, ")");
                    break;
                }
                case 3: {
                    const joinCond = concatString("A.", key, " = ", "B.", key);
                    const mainCond = concatString("B.", edsc.policyNumber, clauseEx, getValue());
                    query = concatString("SELECT * FROM ", table, " A WHERE", existsClause, "(SELECT * FROM ", edst.hktHb, " B WHERE ", joinCond, " AND ", mainCond, ")");
                    break;
                }
                case 4: {
                    const joinCond = concatString("A.", key, " = ", "B.", key);
                    const mainCond = concatString("B.", edsc.policyNumber, clauseEx, getValue());
                    query = concatString("SELECT * FROM ", table, " A WHERE", existsClause, "(SELECT * FROM ", edst.hktKsnHb, " B WHERE ", joinCond, " AND ", mainCond, ")");
                    break;
                }
                case 5: {
                    const sort = !isFromDelete ? concatString(" ORDER BY ", edsc.kctlId) : SIGN. none;
                    query = concatString("SELECT * FROM ", table, " WHERE ", key, clause, getValue(), sort);
                    break;
                }
                case 6: {
                    const subQuery = concatString("(SELECT ", edsc.kctlId, " FROM ", edst.iwfKctl, " WHERE ", defaultKey, clauseEx, getValue(), ")");
                    const sort = !isFromDelete ? concatString(" ORDER BY ", edsc.docId) : SIGN. none;
                    query = concatString("SELECT * FROM ", table, " WHERE ", key, clauseIn, subQuery, sort);
                    break;
                }
                case 7: {
                    const subQuery = concatString("(SELECT ", edsc.kctlId, " FROM ", edst.iwfKctl, " WHERE ", defaultKey, clauseEx, getValue(), ")");
                    query = concatString("SELECT * FROM ", table, " WHERE ", key, clauseIn, subQuery);
                    break;
                }
                case 8: {
                    const subQuery1 = concatString("(SELECT ", edsc.kctlId, " FROM ", edst.iwfKctl, " WHERE ", defaultKey, clauseEx, getValue(), ")");
                    const subQuery2 = concatString("(SELECT ", edsc.docId, " FROM ", edst.iwfDocument, " WHERE ", edsc.kctlId, " IN ", subQuery1, ")");
                    query = concatString("SELECT * FROM ", table, " WHERE ", key, clauseIn, subQuery2);
                    break;
                }
                case 9: {
                    const subQuery1 = concatString("(SELECT ", edsc.kctlId, " FROM ", edst.iwfKctl, " WHERE ", defaultKey, clauseEx, getValue(), ")");
                    const subQuery2 = concatString("(SELECT ", edsc.docId, " FROM ", edst.iwfDocument, " WHERE ", edsc.kctlId, " IN ", subQuery1, ")");
                    const subQuery3 = concatString("(SELECT ", edsc.docPageId, " FROM ", edst.iwfPage, " WHERE ", edsc.docId, " IN ", subQuery2, ")");
                    query = concatString("SELECT * FROM ", table, " WHERE ", key, clauseIn, subQuery3);
                    break;
                }
            }
        }
        return query;
    },
    getExtractTableListDataCopy: function(extractGroupStack, tableObject) {
        const _this = this;
        const dataCopyExport = _this.export.dataCopy;
        const isDefExec = isVoid(tableObject);
        const to = isDefExec ? dataCopyExport.tableListObject : tableObject;
        const listMap = isDefExec ? ["required"].concat(extractGroupStack) : extractGroupStack;
        const getExportTableList = function(key) {
            return getProperty(to, key);
        };
        const extractTableList = listMap.map(function(tableListKey) {
            return getExportTableList(tableListKey);
        }).reduce(function(pre, curr) {
            return pre.concat(curr);
        });
        return extractTableList;
    },
    getExtractTableListDeleteData: function(extractGroupStack, tableObject) {
        const _this = this;
        const dataCopyExport = _this.export.dataCopy;
        const isDefExec = isVoid(tableObject);
        const to = isDefExec ? dataCopyExport.tableListObject : tableObject;
        const listMap = extractGroupStack;
        const getExportTableList = function(key) {
            return getProperty(to, key);
        };
        const extractTableList = listMap.map(function(tableListKey) {
            return getExportTableList(tableListKey);
        }).reduce(function(pre, curr) {
            return pre.concat(curr);
        });
        return extractTableList;
    },
    extractDataCopy: function(phase) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.dataCopy;
        const designType = types.design.dataCopy;
        const _event = _this.event;
        const dataCopyEvent = _event.dataCopy;
        const dataCopyExport = _this.export.dataCopy;
        const exportDefineSet = dataCopyExport.defineSet;
        const edst = exportDefineSet.table;
        const edsc = exportDefineSet.column;
        const dataCopyState = _this.state.dataCopy;
        const sb = new StringBuilder();
        let isSingleMode = true;
        let pnfElementId = SIGN.none;
        switch(dataCopyEvent.status.extractMode) {
            case types.design.dataCopy.extractMode.single:{
                pnfElementId = seId.policyNumberFrom;
                isSingleMode = true;
                break;
            }
            case types.design.dataCopy.extractMode.multiple: {
                pnfElementId = seId.policyNumberFromTextarea;
                isSingleMode = false;
                break;
            }
        }
        const loading = new Loading();
        loading.on().then(function() {
            let pnf, pnt;
            let pnfList = new Array();
            let pntList = new Array();
            let extractedData = new Object();
            const extractMap = new Object();
            const isImport = phase === phaseType.import;
            const subSid = _this.createInfoObject(jqById(seId.subSid).val(), captions.subSid);
            const subUid = _this.createInfoObject(jqById(seId.subUid).val(), captions.subUid);
            const subPwd = _this.createInfoObject(jqById(seId.subPwd).val(), captions.subPwd);
            const policyNumberFrom = _this.createInfoObject(jqById(pnfElementId).val(), captions.policyNumberFrom);
            const policyNumberTo = _this.createInfoObject(jqById(seId.policyNumberTo).val(), captions.policyNumberTo);
            const v = new Validation();
            const vTypes = v.getTypes();
            const subSidLayout = v.getLayout(v.initLayout(subSid.value, subSid.name), [vTypes.required, vTypes.notSpace]);
            const subUidLayout = v.getLayout(v.initLayout(subUid.value, subUid.name), [vTypes.required, vTypes.notSpace]);
            const subPwdLayout = v.getLayout(v.initLayout(subPwd.value, subPwd.name), [vTypes.required, vTypes.notSpace]);
            const policyNumberFromLayout = v.getLayout(v.initLayout(policyNumberFrom.value, policyNumberFrom.name, v.getSizeLayout(11, 11, SIGN.nl)), [vTypes.requiredWithLineBreak, vTypes.notSpace, vTypes.numericWithLineBreak, vTypes.size]);
            const policyNumberToLayout = v.getLayout(v.initLayout(policyNumberTo.value, policyNumberTo.name, v.getSizeLayout(11, 11, SIGN.nl)), [vTypes.requiredWithLineBreak, vTypes.notSpace, vTypes.numericWithLineBreak, vTypes.size]);
            let layoutList = new Array();
            if(isImport) {
                layoutList = [policyNumberFromLayout, policyNumberToLayout];
            }
            else {
                layoutList = [subSidLayout, subUidLayout, subPwdLayout, policyNumberFromLayout, policyNumberToLayout];
            }
            v.reset().appendList(layoutList);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            pnf = policyNumberFrom.value;
            pnt = policyNumberTo.value;
            pnfList = getExistArray(pnf.split(SIGN.nl));
            pntList = getExistArray(pnt.split(SIGN.nl));
            if(pntList.length >= 1000) {
                const lMsg = "More than 1000 items of data can not be copy";
                throw new Error(lMsg);
            }
            const dCheck = duplicationCheckForArray(pntList);
            if(dCheck.hasError) {
                const dMsg = [concatString("Policy Number(To) has duplication error", SIGN.br)].concat(dCheck.data).join(SIGN.br);
                throw new Error(dMsg);
            }
            if(!isSingleMode && pnfList.length != pntList.length) {
                const mMsg = "Policy Number(From) and Policy Number(To) do not match";
                throw new Error(mMsg);
            }
            const extractGroupStack = new Array();
            $(dataCopyEvent.element.extractGroupChecked).each(function() {
                extractGroupStack.push($(this).val());
            });
            if(extractGroupStack.length <= 0) {
                const egMsg = concatString(captions.extractGroup, " is required");
                throw new Error(egMsg);
            }
            const customizeType = $(dataCopyEvent.element.customizeRadioChecked).val();
            pntList.forEach(function(toKey, i) {
                extractMap[toKey] = isSingleMode ? pnfList[0] : pnfList[i];
            });
            if(!(extractGroupStack.length === 1 && extractGroupStack.indexOf(designType.extractGroup.skei) >= 0 && customizeType === designType.customize.all)) {
                extractGroupStack.unshift(designType.extractGroup.iwf);
            }
            const extractTableList = _this.getExtractTableListDataCopy(extractGroupStack);
            dataCopyState.extractMap = extractMap;
            const actionStatus = {
                extractError: false,
                insertError: false,
                message: new Array()
            };
            if(isImport) {
                extractedData = cloneJS(dataCopyState.ref.import.data);
                Object.keys(extractedData).forEach(function(key) {
                    const t = extractedData[key];
                    const countStack = new Array();
                    Object.keys(t).forEach(function(table) {
                        if(compareIndexOf(extractTableList, table) < 0) {
                            delete t[table];
                        }
                        else {
                            countStack.push(getProperty(t, table).count);
                        }
                    });
                    if(countStack.reduce(function(a, b) { return a + b; }) <= 0) {
                        actionStatus.extractError = true;
                        actionStatus.message = [concatString(fromKey, " : Nothing extracted data")];
                    }
                });
            }
            else {
                dataCopyState.ref = new Object();
                const info = {
                    sid: subSid,
                    uid: subUid,
                    pwd: subPwd
                };
                const subDB = new DBUtils().connect(info);
                const extractedPnfStack = new Array();
                pnfList.forEach(function(fromKey) {
                    if(extractedPnfStack.indexOf(fromKey) < 0) {
                        extractedPnfStack.push(fromKey);
                        extractedData[fromKey] = new Object();
                    }
                    const countStack = new Array();
                    extractTableList.some(function(table, i, a) {
                        const query = _this.getDataCopySelectQuery(table, fromKey);
                        const dataSet = subDB.executeSelect(query).dataSet;
                        extractedData[fromKey][table] = dataSet;
                        if(dataSet.error) {
                            actionStatus.extractError = true;
                            actionStatus.message = ["Extract failed"];
                        }
                        countStack.push(dataSet.count);
                        return dataSet.error;
                    });
                    if(countStack.reduce(function(a, b) { return a + b; }) <= 0) {
                        actionStatus.extractError = true;
                        actionStatus.message = [concatString(fromKey, " : Nothing extracted data")];
                    }
                });
                subDB.close();
            }
            if(actionStatus.extractError) {
                throw new Error(actionStatus.message.join(SIGN.br));
            }
            const db = new DBUtils().connect(_this.state.info);
            const rules = dataCopyExport.rules;
            const defaultKey = dataCopyExport.keySet.defaultKey;
            const insertData = new Object();
            dataCopyState.applyInfo = new Object();
            const du = new DateUtil();
            const todayObj = getToday();
            const cnQuery = sb.setQuery(["SELECT", edsc.kokNo, "FROM", edst.kokykKanren, "UNION SELECT", edsc.kokNo, "FROM", edst.nayoseKihon]);
            const mpQuery = sb.setQuery(["SELECT", edsc.myPageUserId, "FROM", edst.dtMypageUser]);
            const applyIdList = [
                { query: cnQuery, key: "customerNumber", rand: true },
                { query: mpQuery, key: "myPageUser", rand: false },
                { query: null, key: "accountNumber", rand: true },
                { query: null, key: "timeStamp", rand: false },
                { query: null, key: "collection", rand: false },
                { query: null, key: "kctl", rand: false },
                { query: null, key: "docId", rand: false },
                { query: null, key: "docPageId", rand: false }
            ];
            applyIdList.forEach(function(item, i) {
                const dataSet = !isVoid(item.query) ? db.executeSelect(item.query).dataSet : { data: [] };
                const setId = item.rand ? Math.floor(Math.random() * 9999) + (i === 0 ? 10000000 : 1000000) : todayObj;
                dataCopyState.applyInfo[item.key] = {
                    id: setId,
                    data: dataSet.data.map(function(row) { return toString(row[0]); }),
                    idList: new Array(),
                    idMap: new Object(),
                    table: new Object(),
                    pointer: 0
                }
            });
            Object.keys(dataCopyState.extractMap).forEach(function(toKey) {
                const fromKey = dataCopyState.extractMap[toKey];
                Object.keys(extractedData[fromKey]).forEach(function(table) {
                    if(compareIndexOf(extractTableList, table) < 0) {
                        return;
                    }
                    const dataSet = getProperty(extractedData[fromKey], table);
                    const count = dataSet.count;
                    if(count >= 1) {
                        const name = dataSet.name;
                        const data = dataSet.data;
                        const applyData = new Array();
                        const keyIndex = compareIndexOf(name, defaultKey);
                        data.forEach(function(record) {
                            const applyRecord = cloneJS(record);
                            if(keyIndex >= 0) {
                                applyRecord[keyIndex] = toKey;
                            }
                            applyData.push(applyRecord);
                        });
                        if(!isVoid(getProperty(rules, table))) {
                            Object.keys(getProperty(rules, table)).forEach(function(column) {
                                const applyType = accessObjectProperty(rules, [table, column]);
                                if(applyType.enable) {
                                    const expInherit = applyType.parameter.inherit;
                                    const expNoneExcept = applyType.parameter.noneExcept;
                                    switch(customizeType) {
                                        case designType.customize.none: {
                                            if(!expNoneExcept) {
                                                return;
                                            }
                                            break;
                                        }
                                        case designType.customize.inherit: {
                                            if(expInherit) {
                                                return;
                                            }
                                            break;
                                        }
                                    }
                                    const applyIndex = compareIndexOf(name, column);
                                    dataCopyState.applyIndex = applyIndex;
                                    _this.applyRulesDataCopy(applyType, applyData, table, column, db, name, extractedData[fromKey], toKey);
                                }
                            });
                        }
                        const dataObj = {
                            name: name,
                            data: applyData
                        };
                        if(isVoid(getProperty(insertData, table))) {
                            insertData[table] = createObject(toKey, dataObj);
                        }
                        else {
                            insertData[table][toKey] = dataObj;
                        }
                    }
                });
            });
            db.close();
            dataCopyState.extractedData = extractedData;
            dataCopyState.insertData = insertData;
            dataCopyState.insertDataStatic = cloneJS(insertData);
            dataCopyState.ref.isSingleMode = isSingleMode;
            dataCopyState.ref.extractGroupStack = extractGroupStack;
            dataCopyState.toList = pntList;
            _this.actionControllerDataCopy(phaseType.insert);
            loading.off();
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    applyRulesDataCopy: function(applyType, applyData, table, column, db, nameData, exd, toKey) {
        const _this = this;
        const dataCopyExport = _this.export.dataCopy;
        const defineSet = dataCopyExport.defineSet;
        const edst = defineSet.table;
        const edsc = defineSet.column;
        const state = _this.state.dataCopy;
        const applyInfo = state.applyInfo;
        const sb = new StringBuilder();
        if(isVoid(applyInfo.collection.table[table])) {
            applyInfo.collection.table = createObject(table, new Object);
        }
        switch(applyType.name) {
            case "identifyCustomerNumber": {
                if(isVoid(applyInfo.customerNumber.idMap[toKey])) {
                    applyInfo.customerNumber.idMap[toKey] = new Array();
                }
                const identifier = applyInfo.customerNumber.id;
                const status = { p: applyInfo.customerNumber.pointer };
                const collection = new Array();
                applyData.forEach(function(record, i) {
                    let count = 0;
                    while(count <= 99999999) {
                        status.p = status.p + count;
                        const idStr = toString(identifier + status.p);
                        if(applyInfo.customerNumber.data.indexOf(idStr) < 0 && applyInfo.customerNumber.idList.indexOf(idStr) < 0) {
                            applyInfo.customerNumber.idList.push(idStr);
                            collection.push(idStr);
                            record[state.applyIndex] = idStr;
                            status.p++;
                            break;
                        }
                        count++;
                    }
                });
                applyInfo.customerNumber.idMap[toKey] = collection;
                applyInfo.customerNumber.pointer = status.p;
                break;
            }
            case "getIdentifierCustomerNumber": {
                applyData.forEach(function(record, i) {
                    record[state.applyIndex] = applyInfo.customerNumber.idMap[toKey][i];
                });
                break;
            }
            case "identifyAccountNumber": {
                if(isVoid(applyInfo.accountNumber.data)) {
                    const query = sb.setQuery(["SELECT", edsc.kouzaNo, "FROM", edst.stHrkmKouzaKanri]);
                    const dataSet = db.executeSelect(query).dataSet;
                    applyInfo.accountNumber.data = dataSet.data.map(function(row) { return toString(row[0]); });
                }
                if(isVoid(applyInfo.accountNumber.idMap[toKey])) {
                    applyInfo.accountNumber.idMap[toKey] = new Array();
                }
                const identifier = applyInfo.accountNumber.id;
                const status = { p: applyInfo.accountNumber.pointer };
                const collection = new Array();
                applyData.forEach(function(record, i) {
                    let count = 0;
                    while(count <= 99999999) {
                        status.p = status.p + count;
                        const idStr = toString(identifier + status.p);
                        if(applyInfo.accountNumber.data.indexOf(idStr) < 0 && applyInfo.accountNumber.idList.indexOf(idStr) < 0) {
                            applyInfo.accountNumber.idList.push(idStr);
                            collection.push(idStr);
                            record[state.applyIndex] = idStr;
                            status.p++;
                            break;
                        }
                        count++;
                    }
                });
                applyInfo.accountNumber.idMap[toKey] = collection;
                applyInfo.accountNumber.pointer = status.p;
                break;
            }
            case "changeTo": {
                applyData.forEach(function(record) {
                    record[state.applyIndex] = applyType.parameter.to;
                });
                break;
            }
            case "deleteExceptByAdProcedure": {
                let i = applyData.length;
                const adProcedureList = applyType.parameter.adProcedureList;
                while(i--) {
                    const rowData = applyData[i][state.applyIndex];
                    if(adProcedureList.indexOf(rowData) < 0) {
                        const nKctlIdIdx = nameData.indexOf(edsc.kctlId);
                        const nKctlId = applyData[i][nKctlIdIdx];
                        const oKctlId = getObjectKeyByValue(applyInfo.kctl.idMap, nKctlId);
                        delete applyInfo.kctl.idMap[oKctlId];
                        applyData.splice(i, 1);
                    }
                }
                break;
            }
            case "setPolicyNumberHead": {
                applyData.forEach(function(record, i) {
                    record[state.applyIndex] = toKey.slice(0, 1);
                });
                break;
            }
            case "slicePolicyNumber": {
                applyData.forEach(function(record, i) {
                    record[state.applyIndex] = toKey.slice(1, toKey.length - 1);
                });
                break;
            }
            case "identifyKctlId": {
                if(isVoid(applyInfo.kctl.data)) {
                    const query = sb.setQuery(["SELECT", column, "FROM", table]);
                    const dataSet = db.executeSelect(query).dataSet;
                    applyInfo.kctl.data = dataSet.data.map(function(row) { return toString(row[0]); });
                }
                if(isVoid(applyInfo.kctl.idMap[toKey])) {
                    applyInfo.kctl.idMap[toKey] = new Object();
                }
                const o = applyInfo.timeStamp.id;
                o.milliseconds = String(0);
                const du = new DateUtil().setDateObject(o);
                const status = { p: applyInfo.kctl.pointer };
                applyData.forEach(function(record, i) {
                    let count = 0;
                    while(count <= 99999999) {
                        status.p = status.p + count;
                        const idStr = du.format.joinAll(du.calcDate({ milliseconds: status.p }));
                        if(applyInfo.kctl.data.indexOf(idStr) < 0 && applyInfo.kctl.idList.indexOf(idStr) < 0) {
                            applyInfo.kctl.idList.push(idStr);
                            applyInfo.kctl.idMap[toKey][record[state.applyIndex]] = idStr;
                            record[state.applyIndex] = idStr;
                            status.p++;
                            break;
                        }
                        count++;
                    }
                });
                applyInfo.kctl.pointer = status.p;
                break;
            }
            case "getIdentifierKctlId": {
                const idMap = applyInfo.kctl.idMap[toKey];
                applyData.reduceRight(function(c, record, i, array) {
                    const idStr = idMap[record[state.applyIndex]];
                    if(!isVoid(idStr)) {
                        record[state.applyIndex] = idStr;
                    }
                    else {
                        array.splice(i, 1);
                    }
                }, []);
                break;
            }
            case "identifyDocId": {
                if(isVoid(applyInfo.docId.data)) {
                    const query = sb.setQuery(["SELECT", column, "FROM", table]);
                    const dataSet = db.executeSelect(query).dataSet;
                    applyInfo.docId.data = dataSet.data.map(function(row) { return toString(row[0]); });
                }
                if(isVoid(applyInfo.docId.idMap[toKey])) {
                    applyInfo.docId.idMap[toKey] = new Object();
                }
                const o = applyInfo.timeStamp.id;
                o.milliseconds = String(0);
                const du = new DateUtil().setDateObject(o);
                const status = { p: applyInfo.docId.pointer };
                applyData.forEach(function(record, i) {
                    let count = 0;
                    while(count <= 99999999) {
                        status.p = status.p + count;
                        const idStr = du.format.joinAll(du.calcDate({ milliseconds: status.p }));
                        if(applyInfo.docId.data.indexOf(idStr) < 0 && applyInfo.docId.idList.indexOf(idStr) < 0) {
                            applyInfo.docId.idList.push(idStr);
                            applyInfo.docId.idMap[toKey][record[state.applyIndex]] = idStr;
                            record[state.applyIndex] = idStr;
                            status.p++;
                            break;
                        }
                        count++;
                    }
                });
                applyInfo.docId.pointer = status.p;
                break;
            }
            case "getIdentifierDocId": {
                const idMap = applyInfo.docId.idMap[toKey];
                if(!isVoid(idMap)) {
                    applyData.reduceRight(function(c, record, i, array) {
                        const idStr = idMap[record[state.applyIndex]];
                        if(!isVoid(idStr)) {
                            record[state.applyIndex] = idStr;
                        }
                        else {
                            array.splice(i, 1);
                        }
                    }, []);
                }
                else {
                    if(isVoid(applyInfo.docId.data)) {
                        const query = sb.setQuery(["SELECT", column, "FROM", table]);
                        const dataSet = db.executeSelect(query).dataSet;
                        applyInfo.docId.data = dataSet.data.map(function(row) { return toString(row[0]); });
                    }
                    if(isVoid(applyInfo.docId.idMap[toKey])) {
                        applyInfo.docId.idMap[toKey] = new Array();
                    }
                    const o = applyInfo.timeStamp.id;
                    o.milliseconds = String(0);
                    const du = new DateUtil().setDateObject(o);
                    const status = { p: applyInfo.docId.pointer };
                    applyData.forEach(function(record, i) {
                        let count = 0;
                        while(count <= 99999999) {
                            status.p = status.p + count;
                            const idStr = du.format.joinAll(du.calcDate({ milliseconds: status.p }));
                            if(applyInfo.docId.data.indexOf(idStr) < 0 && applyInfo.docId.idList.indexOf(idStr) < 0) {
                                applyInfo.docId.idList.push(idStr);
                                applyInfo.docId.idMap[toKey][record[state.applyIndex]] = idStr;
                                record[state.applyIndex] = idStr;
                                status.p++;
                                break;
                            }
                            count++;
                        }
                    });
                    applyInfo.docId.pointer = status.p;
                }
                break;
            }
            case "identifyDocPageId": {
                if(isVoid(applyInfo.docPageId.data)) {
                    const query = sb.setQuery(["SELECT", column, "FROM", table]);
                    const dataSet = db.executeSelect(query).dataSet;
                    applyInfo.docPageId.data = dataSet.data.map(function(row) { return toString(row[0]); });
                }
                if(isVoid(applyInfo.docPageId.idMap[toKey])) {
                    applyInfo.docPageId.idMap[toKey] = new Object();
                }
                const o = applyInfo.timeStamp.id;
                o.milliseconds = String(0);
                const du = new DateUtil().setDateObject(o);
                const status = { p: applyInfo.docPageId.pointer };
                applyData.forEach(function(record, i) {
                    let count = 0;
                    while(count <= 99999999) {
                        status.p = status.p + count;
                        const idStr = du.format.joinAll(du.calcDate({ milliseconds: status.p }));
                        if(applyInfo.docPageId.data.indexOf(idStr) < 0 && applyInfo.docPageId.idList.indexOf(idStr) < 0) {
                            applyInfo.docPageId.idList.push(idStr);
                            applyInfo.docPageId.idMap[toKey][record[state.applyIndex]] = idStr;
                            record[state.applyIndex] = idStr;
                            status.p++;
                            break;
                        }
                        count++;
                    }
                });
                applyInfo.docPageId.pointer = status.p;
                break;
            }
            case "getIdentifierDocPageId": {
                const idMap = applyInfo.docPageId.idMap[toKey];
                if(!isVoid(idMap)) {
                    applyData.reduceRight(function(c, record, i, array) {
                        const idStr = idMap[record[state.applyIndex]];
                        if(!isVoid(idStr)) {
                            record[state.applyIndex] = idStr;
                        }
                        else {
                            array.splice(i, 1);
                        }
                    }, []);
                }
                else {
                    if(isVoid(applyInfo.docPageId.data)) {
                        const query = sb.setQuery(["SELECT", column, "FROM", table]);
                        const dataSet = db.executeSelect(query).dataSet;
                        applyInfo.docPageId.data = dataSet.data.map(function(row) { return toString(row[0]); });
                    }
                    if(isVoid(applyInfo.docPageId.idMap[toKey])) {
                        applyInfo.docPageId.idMap[toKey] = new Array();
                    }
                    const o = applyInfo.timeStamp.id;
                    o.milliseconds = String(0);
                    const du = new DateUtil().setDateObject(o);
                    const status = { p: applyInfo.docPageId.pointer };
                    applyData.forEach(function(record, i) {
                        let count = 0;
                        while(count <= 99999999) {
                            status.p = status.p + count;
                            const idStr = du.format.joinAll(du.calcDate({ milliseconds: status.p }));
                            if(applyInfo.docPageId.data.indexOf(idStr) < 0 && applyInfo.docPageId.idList.indexOf(idStr) < 0) {
                                applyInfo.docPageId.idList.push(idStr);
                                applyInfo.docPageId.idMap[toKey][record[state.applyIndex]] = idStr;
                                record[state.applyIndex] = idStr;
                                status.p++;
                                break;
                            }
                            count++;
                        }
                    });
                    applyInfo.docPageId.pointer = status.p;
                }
                break;
            }
            case "getIdentifierTimeStamp": {
                const tableState = applyInfo.timeStamp.table;
                if(isVoid(tableState[table])) {
                    const query = sb.setQuery(["SELECT", column, "FROM", table]);
                    const dataSet = db.executeSelect(query).dataSet;
                    applyInfo.timeStamp.table[table] = {
                        data: dataSet.data.map(function(row) { return toString(row[0]); }),
                        idList: new Array(),
                        pointer: 0
                    };
                }
                const o = applyInfo.timeStamp.id;
                o.milliseconds = String(0);
                const du = new DateUtil().setDateObject(o);
                const status = { p: tableState[table].pointer };
                applyData.forEach(function(record, i) {
                    let count = 0;
                    while(count <= 99999999) {
                        status.p = status.p + count;
                        const idStr = du.format.joinAll(du.calcDate({ milliseconds: status.p }));
                        if(tableState[table].data.indexOf(idStr) < 0 && tableState[table].idList.indexOf(idStr) < 0) {
                            tableState[table].idList.push(idStr);
                            record[state.applyIndex] = idStr;
                            status.p++;
                            break;
                        }
                        count++;
                    }
                });
                tableState[table].pointer = status.p;
                break;
            }
            case "identifyMyPageUserId": {
                const oDB = new DBUtils();
                const ref = oDB.where(exd, table).ref;
                const myPageUserId = ref[edsc.myPageUserId][0];
                applyInfo.myPageUser.isWeb = !isVoid(myPageUserId);
                if(applyInfo.myPageUser.isWeb) {
                    if(isVoid(applyInfo.myPageUser.idMap[toKey])) {
                        applyInfo.myPageUser.idMap[toKey] = new Array();
                    }
                    const o = applyInfo.myPageUser.id;
                    o.milliseconds = String(0);
                    const du = new DateUtil().setDateObject(o);
                    const status = { p: applyInfo.myPageUser.pointer };
                    const collection = new Array();
                    applyData.forEach(function(record, i) {
                        let count = 0;
                        while(count <= 99999999) {
                            status.p = status.p + count;
                            const idStr = du.format.joinAll(du.calcDate({ milliseconds: status.p }));
                            if(applyInfo.myPageUser.data.indexOf(idStr) < 0 && applyInfo.myPageUser.idList.indexOf(idStr) < 0) {
                                applyInfo.myPageUser.idList.push(idStr);
                                collection.push(idStr);
                                record[state.applyIndex] = idStr;
                                status.p++;
                                break;
                            }
                            count++;
                        }
                    });
                    applyInfo.myPageUser.idMap[toKey] = collection;
                    applyInfo.myPageUser.pointer = status.p;
                }
                break;
            }
            case "getIdentifierMyPageUserId": {
                if(applyInfo.myPageUser.isWeb) {
                    applyData.forEach(function(record, i) {
                        record[state.applyIndex] = applyInfo.myPageUser.idMap[toKey][0];
                    });
                }
                break;
            }
            case "setMyPageLoginId": {
                if(applyInfo.myPageUser.isWeb) {
                    applyData.forEach(function(record, i) {
                        record[state.applyIndex] = concatString("a", toKey);
                    });
                }
                break;
            }
            case "setMyPageMail": {
                if(applyInfo.myPageUser.isWeb) {
                    applyData.forEach(function(record, i) {
                        record[state.applyIndex] = concatString("a", toKey, "@direct.test.com");
                    });
                }
                break;
            }
            case "getMaxId": {
                const setObj = {
                    maxId: {
                        list: new Array(),
                        pointer: null
                    }
                };
                if(isVoid(applyInfo.collection.table[table][column])) {
                    applyInfo.collection.table[table] = createObj(column, setObj);
                }
                else {
                    if(isVoid(applyInfo.collection.table[table][column].maxId)) {
                        applyInfo.collection.table[table][column] = mergeObject(applyInfo.collection.table[table][column], setObj);
                    }
                }
                const maxIdObj = applyInfo.collection.table[table][column].maxId;
                if(maxIdObj.pointer === null) {
                    const query = sb.setQuery(["SELECT MAX(", column, ") AS", column,  "FROM", table]);
                    const dataSet = db.executeSelect(query).dataSet;
                    const maxId = db.getColumnData(dataSet, table, column);
                    const iMaxId = isVoid(maxId) ? 0 : Number(maxId) + 1;
                    maxIdObj.pointer = iMaxId;
                }
                const status = { p: maxIdObj.pointer };
                applyData.forEach(function(record, i) {
                    let count = 0;
                    while(count <= 99999999) {
                        const setId = status.p + count;
                        if(maxIdObj.list.indexOf(setId) < 0) {
                            maxIdObj.list.push(setId);
                            record[state.applyIndex] = String(setId);
                            status.p++;
                            break;
                        }
                        count++;
                    }
                });
                maxIdObj.pointer = status.p;
                break;
            }
        }
        return null;
    },
    exportToExcelDataCopy: function() {
        const _this = this;
        const fileDefine = TYPES.file;
        const dataCopyState = _this.state.dataCopy;
        const extractMap = dataCopyState.extractMap;
        const extractedData = dataCopyState.extractedData;
        const insertData = dataCopyState.insertData;
        const isSingleMode = dataCopyState.ref.isSingleMode;
        const headerStyle = {
            fill: {
                patternType: "solid",
                fgColor:{ rgb: "9E9E9E" }
            },
            font: {
                bold: false
            },
            border: {
                top: { style: "thin", tint: 1 },
                left: { style: "thin", tint: 1 },
                right: { style: "thin", tint: 1 },
                bottom: { style: "thin", tint: 1 }
            }
        };
        const bodyStyle = {
            border: {
                top: { style: "thin", tint: 1 },
                left: { style: "thin", tint: 1 },
                right: { style: "thin", tint: 1 },
                bottom: { style: "thin", tint: 1 }
            }
        };
        const getExportData = function(refObj, table, type) {
            const o = cloneJS(refObj);
            const cd = {
                name: new Array(),
                data: new Array(),
                count: 0
            };
            const columnTypes = {
                header: "header",
                data: "data"
            };
            const setColumns = function(data, columnType, key, from) {
                switch(columnType) {
                    case columnTypes.header: {
                        data.unshift("FROM");
                        data.unshift("KEY");
                        break;
                    }
                    case columnTypes.data: {
                        data.unshift(from ? from : SIGN.none);
                        data.unshift(key ? key : SIGN.none);
                        break;
                    }
                }
            };
            switch(type) {
                case "from": {
                    Object.keys(extractMap).some(function(toKey, i) {
                        const fromKey = extractMap[toKey];
                        const t = cloneJS(o[fromKey][table]);
                        if(i === 0) {
                            cd.name = t.name;
                            setColumns(cd.name, columnTypes.header);
                        }
                        t.data.forEach(function(record) {
                            setColumns(record, columnTypes.data, fromKey);
                        });
                        cd.data = cd.data.concat(t.data);
                        cd.count += t.count;
                        return isSingleMode;
                    });
                    break;
                }
                case "to": {
                    const toObj = o[table];
                    Object.keys(toObj).forEach(function(toKey, i) {
                        const t = cloneJS(toObj[toKey]);
                        const fromKey = extractMap[toKey];
                        if(i === 0) {
                            cd.name = t.name;
                            setColumns(cd.name, columnTypes.header);
                        }
                        t.data.forEach(function(record) {
                            setColumns(record, columnTypes.data, toKey, fromKey);
                        });
                        cd.data = cd.data.concat(t.data);
                    });
                    break;
                }
            }
            return cd;
        };
        const setStyle = function(R, C, cell, count) {
            if(R === 0 || R === count + 5 || ((C === 0 || C === 1) && cell.v)) {
                cell.s = headerStyle;
            }
            else if(R <= count || R >= count + 5) {
                cell.s = bodyStyle;
            }
        };
        const loading = new Loading();
        loading.on().then(function() {
            const wb = new Workbook();
            Object.keys(insertData).forEach(function(table) {
                const from = getExportData(extractedData, table, "from");
                const to = getExportData(insertData, table, "to");
                wb.SheetNames.push(table);
                const a = new Array(from.name).concat(from.data);
                const b = getIterator(4).map(function() { return [SIGN.none]; });
                const c = new Array(to.name).concat(to.data);
                const ws_data = a.concat(b).concat(c);
                const ws = sheetFromArrayOfArrays(ws_data, setStyle, from.count);
                wb.Sheets[table] = ws;
            });
            const wbout = XLSX.write(wb, { bookType: "xlsx", bookSST: true, type: "binary" });
            const fileName = concatString(getFileStamp("DataCopyCheck"), TYPES.file.extension.xlsx);
            saveAsFile(s2ab(wbout), fileDefine.mime.OCTET_STREAM, fileName);
            loading.off();
        }).catch(function(e) {
            new Notification.error().open(e.message);
            loading.off();
        });
        return null;
    },
    saveOptionDataCopy: function(dialogClose) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const dataCopyState = _this.state.dataCopy;
        const extractTableList = _this.getExtractTableListDataCopy(dataCopyState.ref.extractGroupStack);
        const $optionContainer = jqById(seId.optionContainerDataCopy);
        const $commandLines = $optionContainer.find(concatString(".", seClass.commandLine));
        const option = new Array();
        let hasError = false;
        const messageStack = new Array();
        $commandLines.each(function(i, item) {
            const $input = $(item).find("input");
            const $textarea = $(item).find("textarea");
            const messageIndex = concatString("[", i + 1, "]");
            const table = _this.createInfoObject($input.val(), concatString(messageIndex, "Table"));
            const script = _this.createInfoObject($textarea.val(), concatString(messageIndex, "Script"));
            const v = new Validation();
            const vTypes = v.getTypes();
            const tableLayout = v.getLayout(v.initLayout(table.value, table.name), [vTypes.required, vTypes.notSpace]);
            const scriptLayout = v.getLayout(v.initLayout(script.value, script.name), [vTypes.requiredWithLineBreak]);
            v.reset().appendList([tableLayout, scriptLayout]);
            const result = v.exec();
            if(result.error) {
                messageStack.push(result.message);
                hasError = true;
            }
            else if(find(table.value, option, ["table"], upperCase).isExist) {
                messageStack.push(concatString(messageIndex, "Table has duplication error"));
                hasError = true;
            }
            else if(!find(table.value, extractTableList, null, upperCase).isExist) {
                messageStack.push(concatString(messageIndex, "Not exists table"));
                hasError = true;
            }
            else if(!script.value.match(new RegExp("@", "g"))) {
                messageStack.push(concatString(messageIndex, "Incorrect script"));
                hasError = true;
            }
            option.push({ table: table.value, script: script.value });
        });
        if(hasError) {
            new Notification().error().open(messageStack.join(SIGN.br));
            return false;
        }
        if(!dialogClose) {
            return { data: option };
        }
        const actionState = {
            msg: new Array(),
            backup: null
        };
        dataCopyState.insertData = cloneJS(dataCopyState.insertDataStatic);
        if(option.length >= 1) {
            actionState.backup = cloneJS(dataCopyState.insertData);
            const convertScript = function(script) {
                const scriptObj = new Object();
                const sc = getExistArray(script.replace(new RegExp("\n@", "g"), "@").split("@")).map(function(item) { return item.split(SIGN.nl); });
                sc.forEach(function(item) {
                    const column = item.slice(0, 1)[0];
                    const data = item.slice(1);
                    scriptObj[column] = data;
                });
                return scriptObj;
            };
            option.forEach(function(line) {
                const table = line.table;
                const script = convertScript(line.script);
                const tableData = getProperty(dataCopyState.insertData, table);
                if(isVoid(tableData)) return;
                const editData = {
                    name: new Array(),
                    data: new Array()
                };
                Object.keys(tableData).forEach(function(pn, i) {
                    if(i === 0) {
                        editData.name = editData.name.concat(tableData[pn].name);
                    }
                    editData.data = editData.data.concat(tableData[pn].data);
                });
                if(editData.data.length >= 1) {
                    Object.keys(script).forEach(function(column) {
                        const applyIndex = compareIndexOf(editData.name, column);
                        if(applyIndex < 0) {
                            actionState.msg.push(concatString("[", table, "]", column, " : Not exists column"));
                            return;
                        }
                        getExistArray(script[column]).forEach(function(s, i) {
                            if(!editData.data[i]) {
                                actionState.msg.push(concatString("[", table, "]", column, " > ", s, " : Overflow data"));
                                return;
                            }
                            else if(s === VARIABLE.eq) return;
                            editData.data[i][applyIndex] = lowerCase(s) === VARIABLE.null ? SIGN.none : s;
                        });
                    });
                }
            });
            if(actionState.msg.length >= 1) {
                dataCopyState.insertData = actionState.backup;
                new Notification().error().open(actionState.msg.join(SIGN.br));
                return false;
            }
        }
        dataCopyState.option = option;
        dialogClose();
    },
    getInsertQuery: function(table, columns, record) {
        const sb = new StringBuilder();
        const getQuery = function(t, c, v) {
            return concatString("INSERT INTO ", t, " (", c, ") VALUES (", v, ")");
        };
        const values = record.map(function(item) {
            const v = item || item == 0 ? item : "";
            return sb.sq(v);
        }).join(SIGN.cw);
        return getQuery(table, columns, values);
    },
    insertDataCopy: function() {
        const _this = this;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.dataCopy;
        const transactionId = types.toolId.dataCopy;
        const dataCopyState = _this.state.dataCopy;
        const dbTypes = new DBUtils().getTypes();
        dataCopyState.log = new Array();
        const loading = new Loading();
        loading.on().then(function() {
            const insertData = dataCopyState.insertData;
            const onTransaction = _this.transaction(transactionId);
            if(onTransaction.error) throw new Error(onTransaction.message);
            const db = onTransaction.db;
            const promise = new PromiseUtil();
            const status = {
                executeTable: SIGN.none,
                hasError: false
            };
            const successFunc = function() {
                _this.actionControllerDataCopy(phaseType.commit);
                loading.off();
            };
            const errorFunc = function(e) {
                const errorType = dbTypes.error;
                let message = e.message;
                if(message.indexOf(errorType.uniqueConstraint) >= 0) {
                    message = concatString(SIGN.abs, status.executeTable, SIGN.abe, SIGN.br, message);
                }
                _this.destroy(transactionId, db);
                new Notification().error().open(message);
                loading.off();
            };
            Object.keys(insertData).forEach(function(table) {
                dataCopyState.log.push(concatString("-- <", table, ">"));
                Object.keys(getProperty(insertData, table)).forEach(function(toKey, idx, arry) {
                    const name = getProperty(insertData, table)[toKey].name;
                    const data = getProperty(insertData, table)[toKey].data;
                    const columns = name.join(SIGN.cw);
                    data.forEach(function(record) {
                        const query = _this.getInsertQuery(table, columns, record);
                        _this.pushQueryLog(dataCopyState.log, query);
                        const exec = function() {
                            status.executeTable = table;
                            db.execute(query);
                        };
                        promise.push(exec);
                    });
                    promise.appendToRecursiveTask(idx, 10, arry);
                });
            });
            promise.recursiveAll(successFunc, errorFunc);
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    saveQueryDataCopy: function() {
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const dataCopyState = _this.state.dataCopy;
        const fileType = TYPES.file;
        const loading = new Loading();
        loading.on().then(function() {
            const zip = new JSZip();
            const insertData = dataCopyState.insertData;
            const fileList = new Array();
            Object.keys(insertData).forEach(function(table) {
                const tableStack = new Array();
                Object.keys(getProperty(insertData, table)).forEach(function(toKey, idx, arry) {
                    const name = getProperty(insertData, table)[toKey].name;
                    const data = getProperty(insertData, table)[toKey].data;
                    const columns = name.join(SIGN.cw);
                    data.forEach(function(record) {
                        const query = _this.getInsertQuery(table, columns, record);
                        tableStack.push(concatString(query, SIGN.sc));
                    });
                    const fileName = concatString([toKey, table].join(SIGN.ub), fileType.extension.sql);
                    fileList.push(fileName);
                    zip.file(fileName, tableStack.join(SIGN.crlf));
                });
            });
            const createBatchFile = function() {
                const buffer = new StringBuffer();
                buffer.append("sqlplus USERXXX_X/USERXXX_X@xora");
                return buffer.toStringWithLine();
            };
            const createAllInsertQuery = function() {
                const buffer = new StringBuffer();
                buffer.append("SET LINES 1000");
                buffer.append("SET echo on");
                buffer.append("SET verify off");
                buffer.append("SET pagesize 50000");
                buffer.append("spool ALLInsert.log");
                buffer.append("");
                fileList.forEach(function(item) {
                    const sql = concatString("@", item, SIGN.sc);
                    buffer.append(sql);
                });
                buffer.append("");
                buffer.append("spool off");
                buffer.append("set echo off");
                return buffer.toStringWithLine();
            };
            zip.file("_SQLPLUS.bat", createBatchFile());
            zip.file("ALLInsert.sql", createAllInsertQuery());
            const zipFileName = concatString(getFileStamp(upperCase(captions.query, 0)), fileType.extension.zip);
            zip.generateAsync({ type: TYPES.file.contentType.blob }).then(function(blob) {
                saveAsZipFile(blob, zipFileName);
                loading.off();
            });
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    buildDeleteData: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const dddt = types.design.deleteData;
        const deleteDataDesign = _this.design.deleteData;
        const _event = _this.event;
        const deleteDataEvent = _event.deleteData;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: seClass.contentsContainer });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $deleteButton = jqNode("button", { class: eClass.buttonColorDeepOrange }).text(upperCase(captions.delete));
        eb.listAppend($actionArea, [$deleteButton]);
        $container.append($actionArea);
        const dmr = deleteDataDesign.deleteModeRadio;
        const dgc = deleteDataDesign.deleteGroupCheck;
        const dopt = deleteDataDesign.optionCheck;
        const deleteModeRadioItemList = [getItemListObject(dmr, dddt.deleteMode.include), getItemListObject(dmr, dddt.deleteMode.exclude)];
        const $dmrCommandArea = jqNode("div", { class: seClass.commandArea });
        const $dmrItem = eb.createRadio(deleteModeRadioItemList).getItem();
        const $dmrLabel = jqNode("label").css("line-height", "2.5").text(captions.deleteMode);
        const $dmrMain = jqNode("div", { class: eClass.fullWidth }).append($dmrItem);
        eb.listAppend($dmrCommandArea, [$dmrLabel, $dmrMain]);
        const deleteGroupCheckItemList = [getItemListObject(dgc, dddt.deleteGroup.skei), getItemListObject(dgc, dddt.deleteGroup.kkanri), getItemListObject(dgc, dddt.deleteGroup.hksiharai)];
        const $dgcCommandArea = jqNode("div", { class: seClass.commandArea });
        const $dgcItem = eb.createCheckbox(deleteGroupCheckItemList).getItem();
        const $dgcLabel = jqNode("label").css("line-height", "2.5").text(captions.deleteGroup);
        const $dgcMain = jqNode("div", { class: eClass.fullWidth }).append($dgcItem);
        eb.listAppend($dgcCommandArea, [$dgcLabel, $dgcMain]);
        const optionCheckItemList = [getItemListObject(dopt, dddt.option.delReq), getItemListObject(dopt, dddt.option.backup)];
        const $doptCommandArea = jqNode("div", { class: seClass.commandArea });
        const $doptItem = eb.createCheckbox(optionCheckItemList).getItem();
        const $doptLabel = jqNode("label").css("line-height", "2.5").text(upperCase(captions.option, 0));
        const $doptMain = jqNode("div", { class: eClass.fullWidth }).append($doptItem);
        eb.listAppend($doptCommandArea, [$doptLabel, $doptMain]);
        eb.listAppend($container, [$dmrCommandArea, $dgcCommandArea, $doptCommandArea]);
        const itemList = [
            {
                label: captions.policyNumber,
                inputType: "textarea",
                inputId: seId.policyNumber
            }
        ];
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: seClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            $commandArea.append($label).append($input);
            $container.append($commandArea);
            switch(item.inputId) {
                case seId.policyNumber: {
                    deleteDataEvent.element.pn = $input;
                    break;
                }
            }
        });
        $deleteButton.click(function() {
            _this.deleteData();
        });
        return $container;
    },
    actionControllerDeleteData: function(phase) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.deleteData;
        const transactionId = types.toolId.deleteData;
        const _event = _this.event;
        const deleteDataEvent = _event.deleteData;
        const $card = jqById(seId.deleteDataCard);
        const $cardContents = $card.find(concatString(".", eClass.cardContents));
        const $contentsContainer = $card.find(concatString(".", seClass.contentsContainer));
        const $actionArea = $contentsContainer.children(concatString(".", seClass.actionArea));
        const $commitButton = jqNode("button", { class: eClass.buttonColorDark }).text(upperCase(captions.commit));
        const $logButton = jqNode("button", { class: eClass.buttonColorPositive }).text(upperCase(captions.log));
        const $resetButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.reset));
        const eb = new ElementBuilder();
        const propOption = eb.getPropOptionLayout();
        let itemList = new Array();
        switch(phase) {
            case phaseType.commit: {
                itemList = [$commitButton, $logButton, $resetButton];
                propOption.disableList = ["deleteMode", "deleteGroup", "option"];
                propOption.readonlyList = ["pn"];
                eb.setElementDisable(deleteDataEvent.element, propOption);
                break;
            }
            case phaseType.complete: {
                itemList = [$logButton, $resetButton];
                break;
            }
        }
        $actionArea.empty();
        itemList.forEach(function(item) {
            $actionArea.append(item);
        });
        $commitButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db, true);
            _this.actionControllerDeleteData(phaseType.complete);
            const message = "Data deleted successfully";
            new Notification().complete().open(message);
        });
        $logButton.click(function() {
            _this.downloadLog(transactionId);
        });
        $resetButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.state.deleteData = new Object();
            $cardContents.html(_this.buildDeleteData());
        });
        return null;
    },
    deleteData: function() {
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const dddt = types.design.deleteData;
        const phaseType = types.phase.deleteData;
        const _event = _this.event;
        const deleteDataEvent = _event.deleteData;
        const dataCopyExport = _this.export.dataCopy;
        const deleteDataState = _this.state.deleteData;
        const transactionId = types.toolId.deleteData;
        const dbTypes = new DBUtils().getTypes();
        deleteDataState.log = new Array();
        const loading = new Loading();
        loading.on().then(function() {
            const dmrElement = deleteDataEvent.element;
            const deleteMode = $(dmrElement.deleteModeChecked).val();
            const isInclude = deleteMode === dddt.deleteMode.include;
            const optionStack = new Array();
            $(dmrElement.optionChecked).each(function() {
                optionStack.push($(this).val());
            });
            const isDelReq = optionStack.indexOf(dddt.option.delReq) >= 0;
            const withBackup = optionStack.indexOf(dddt.option.backup) >= 0;
            const policyNumber = _this.createInfoObject(dmrElement.pn.val(), captions.policyNumber);
            const v = new Validation();
            const vTypes = v.getTypes();
            const policyNumberLayout = v.getLayout(v.initLayout(policyNumber.value, policyNumber.name, v.getSizeLayout(11, 11, SIGN.nl)), [vTypes.requiredWithLineBreak, vTypes.notSpace, vTypes.numericWithLineBreak, vTypes.size]);
            v.reset().append(policyNumberLayout);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            const pn = policyNumber.value;
            const pnList = getExistArray(pn.split(SIGN.nl));
            const dCheck = duplicationCheckForArray(pnList);
            if(dCheck.hasError) {
                const dMsg = [concatString("Policy Number has duplication error", SIGN.br)].concat(dCheck.data).join(SIGN.br);
                throw new Error(dMsg);
            }
            const deleteGroupStack = new Array();
            $(dmrElement.deleteGroupChecked).each(function() {
                deleteGroupStack.push($(this).val());
            });
            if(deleteGroupStack.length <= 0) {
                const egMsg = concatString(captions.deleteGroup, " is required");
                throw new Error(egMsg);
            }
            deleteGroupStack.push(dddt.deleteGroup.iwf);
            if(isDelReq) deleteGroupStack.unshift("required");
            const extractTableList = _this.getExtractTableListDeleteData(deleteGroupStack);
            const edsd = dataCopyExport.defineSet.delete;
            const arrayUtil = new ArrayUtil();
            const ieOption = arrayUtil.getIEOptionLayout();
            ieOption.isSameCase = true;
            const posteriorityTableList = arrayUtil.getIncludeListFrom2Array(edsd.posteriorityTableList, extractTableList, ieOption);
            const deleteTableList = arrayUtil.getExcludeListFrom2Array(extractTableList, posteriorityTableList, ieOption).concat(posteriorityTableList);
            const selRegExp = new RegExp("SELECT(.*?)FROM");
            const delQueryHead = "DELETE FROM";
            const onTransaction = _this.transaction(transactionId);
            if(onTransaction.error) throw new Error(onTransaction.message);
            const db = onTransaction.db;
            let executeTable = SIGN.none;
            const backupData = new Object();
            try {
                let executeFlag = false;
                deleteTableList.forEach(function(table) {
                    backupData[table] = new Object();
                    const selQuery = _this.getDataCopySelectQuery(table, pnList, true, isInclude);
                    const dataSet = db.executeSelect(selQuery).dataSet;
                    if(dataSet.count >= 1) {
                        executeFlag = true;
                        executeTable = table;
                        const delQuery = selQuery.replace(selRegExp, delQueryHead);
                        db.execute(delQuery);
                        _this.pushQueryLog(deleteDataState.log, delQuery);
                        backupData[table] = dataSet;
                    }
                });
                if(!executeFlag) {
                    throw new Error("Nothing delete data");
                }
                if(withBackup) {
                    const fileName = concatString(getFileStamp("DELETE_BK"), TYPES.file.extension.txt);
                    const p = getOutputPath(fileName);
                    new FileSystem(p.modulePath).createFolder();
                    new FileSystem(p.filePath).createFile(false, true).write(JSON.stringify(backupData));
                }
                _this.actionControllerDeleteData(phaseType.commit);
                loading.off();
            }
            catch(e) {
                const errorType = dbTypes.error;
                let message = e.message;
                if(message.indexOf(errorType.uniqueConstraint) >= 0) {
                    message = concatString(SIGN.abs, executeTable, SIGN.abe, SIGN.br, message);
                }
                _this.destroy(transactionId, db);
                throw new Error(message);
            }
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    buildCreateUser: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const _event = _this.event;
        const createUserEvent = _event.createUser;
        const createUserState = _this.state.createUser;
        const $container = jqNode("div", { class: seClass.contentsContainer });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $createButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.create));
        const $deleteButton = jqNode("button", { class: eClass.buttonColorDeepOrange }).text(upperCase(captions.delete));
        [$createButton, $deleteButton].forEach(function(item) { $actionArea.append(item); });
        $container.append($actionArea);
        const itemList = [
            {
                label: captions.userCode,
                inputType: "input",
                inputId: seId.userCode
            },
            {
                label: captions.userName,
                inputType: "input",
                inputId: seId.userName
            }
        ];
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: seClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            $commandArea.append($label).append($input);
            $container.append($commandArea);
            switch(item.inputId) {
                case seId.userCode: {
                    createUserEvent.element.userCode = $input;
                    break;
                }
                case seId.userName: {
                    createUserEvent.element.userName = $input;
                    break;
                }
            }
        });
        $createButton.click(function() {
            createUserState.actionType = types.action.create;
            _this.createUser();
        });
        $deleteButton.click(function() {
            createUserState.actionType = types.action.delete;
            _this.createUser();
        });
        createUserState.actionType = null;
        return $container;
    },
    actionControllerCreateUser: function(phase) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.createUser;
        const transactionId = types.toolId.createUser;
        const _event = _this.event;
        const createUserEvent = _event.createUser;
        const $card = jqById(seId.createUserCard);
        const $cardContents = $card.find(concatString(".", eClass.cardContents));
        const $contentsContainer = $card.find(concatString(".", seClass.contentsContainer));
        const $actionArea = $contentsContainer.children(concatString(".", seClass.actionArea));
        const $commitButton = jqNode("button", { class: eClass.buttonColorDark }).text(upperCase(captions.commit));
        const $logButton = jqNode("button", { class: eClass.buttonColorPositive }).text(upperCase(captions.log));
        const $resetButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.reset));
        const eb = new ElementBuilder();
        const propOption = eb.getPropOptionLayout();
        let itemList = new Array();
        switch(phase) {
            case phaseType.commit: {
                itemList = [$commitButton, $logButton, $resetButton];
                propOption.readonlyList = ["userCode", "userName"];
                eb.setElementDisable(createUserEvent.element, propOption);
                break;
            }
            case phaseType.complete: {
                itemList = [$logButton, $resetButton];
                break;
            }
        }
        $actionArea.empty();
        itemList.forEach(function(item) {
            $actionArea.append(item);
        });
        $commitButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db, true);
            _this.actionControllerCreateUser(phaseType.complete);
            const message = "Create user successfully";
            new Notification().complete().open(message);
        });
        $logButton.click(function() {
            _this.downloadLog(transactionId);
        });
        $resetButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.state.createUser = new Object();
            $cardContents.html(_this.buildCreateUser());
        });
        return null;
    },
    createUser: function() {
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.createUser;
        const transactionId = types.toolId.createUser;
        const _event = _this.event;
        const createUserEvent = _event.createUser;
        const createUserExport = _this.export.createUser;
        const createUserState = _this.state.createUser;
        createUserState.log = new Array();
        const loading = new Loading();
        loading.on().then(function() {
            const createUserElement = createUserEvent.element;
            const userCode = _this.createInfoObject(createUserElement.userCode.val(), captions.userCode);
            const userName = _this.createInfoObject(createUserElement.userName.val(), captions.userName);
            const v = new Validation();
            const vTypes = v.getTypes();
            const userCodeLayout = v.getLayout(v.initLayout(userCode.value, userCode.name, v.getSizeLayout(6, 6)), [vTypes.required, vTypes.notSpace, vTypes.numeric, vTypes.size]);
            const userNameLayout = v.getLayout(v.initLayout(userName.value, userName.name), [vTypes.required, vTypes.notSpace]);
            const layoutList = createUserState.actionType === types.action.delete ? [userCodeLayout] : [userCodeLayout, userNameLayout];
            v.reset().appendList(layoutList);
            const result = v.exec();
            if(result.error) {
                new Notification().error().open(result.message);
                loading.off();
                return false;
            }
            const info = _this.state.info;
            const uc = userCode.value;
            const un = userName.value;
            const tableList = createUserExport.tableList;
            const tableCode = createUserExport.tableCode;
            const keySet = createUserExport.keySet;
            const querySet = createUserExport.querySet;
            const rules = createUserExport.rules;
            const resultFlag = { insert: true, delete: true };
            const getInsertQuery = function(table) {
                const insertQueryStack = new Array();
                const qs = querySet[table];
                switch(tableCode[table]) {
                    case "1": {
                        const base = rules.base[table];
                        const spec = rules.spec;
                        let specPw = SIGN.none;
                        if(info.sid.value === spec.specPassword.sid) {
                            const db = new DBUtils().connect(info);
                            const dataSet = db.executeSelect(spec.specPassword.query).onEnd(true).dataSet;
                            specPw = db.getColumnData(dataSet, spec.specPassword.table, spec.specPassword.column);
                        }
                        const iterator = qs[base].length;
                        for(let i = 0; i < iterator; i++) {
                            const columnStack = new Array();
                            const valueStack = new Array();
                            Object.keys(qs).forEach(function(column) {
                                let value = qs[column];
                                if(typeIs(qs[column]).array) {
                                    value = qs[column][i];
                                }
                                else if(typeIs(qs[column]).object) {
                                    const prop = getProperty(qs[column], info.sid.value);
                                    if(prop) {
                                        if(info.sid.value === spec.specPassword.sid) value = specPw;
                                        else value = prop;
                                    }
                                    else {
                                        value = "1";
                                    }
                                }
                                if(rules.combine.code.indexOf(column) >= 0) {
                                    value = concatString(uc, value);
                                }
                                else if(rules.combine.name.indexOf(column) >= 0) {
                                    value = concatString(un, "@", value);
                                }
                                columnStack.push(column);
                                valueStack.push(concatString(SIGN.sq, value, SIGN.sq));
                            });
                            const n = concatString("(", columnStack.join(SIGN.cw), ")");
                            const v = concatString("(", valueStack.join(SIGN.cw), ")");
                            const query = concatString("INSERT INTO ", table, SIGN.ws, n, " VALUES ", v);
                            insertQueryStack.push(query);
                        }
                        break;
                    }
                    case "2": {
                        const iterator = 1;
                        for(let i = 0; i < iterator; i++) {
                            const columnStack = new Array();
                            const valueStack = new Array();
                            Object.keys(qs).forEach(function(column) {
                                let value = typeIs(qs[column]).array ? qs[column][i] : qs[column];
                                if(rules.combine.code.indexOf(column) >= 0) {
                                    value = concatString(uc, value);
                                }
                                else if(rules.combine.name.indexOf(column) >= 0) {
                                    value = concatString(un, "@", value);
                                }
                                columnStack.push(column);
                                valueStack.push(concatString(SIGN.sq, value, SIGN.sq));
                            });
                            const n = concatString("(", columnStack.join(SIGN.cw), ")");
                            const v = concatString("(", valueStack.join(SIGN.cw), ")");
                            const query = concatString("INSERT INTO ", table, SIGN.ws, n, " VALUES ", v);
                            insertQueryStack.push(query);
                        }
                        break;
                    }
                    case "3": {
                        const base = rules.base[table];
                        const getIterator = function(idx) {
                            return qs[base[Object.keys(base)[idx]]];
                        };
                        getIterator(0).forEach(function(a, ai) {
                            getIterator(1).forEach(function(b, bi) {
                                getIterator(2).forEach(function(c, ci) {
                                    const columnStack = new Array();
                                    const valueStack = new Array();
                                    Object.keys(qs).forEach(function(column) {
                                        columnStack.push(column);
                                    });
                                    valueStack.push(concatString(SIGN.sq, concatString(uc, a), SIGN.sq));
                                    valueStack.push(concatString(SIGN.sq, b, SIGN.sq));
                                    valueStack.push(concatString(SIGN.sq, c, SIGN.sq));
                                    const n = concatString("(", columnStack.join(SIGN.cw), ")");
                                    const v = concatString("(", valueStack.join(SIGN.cw), ")");
                                    const query = concatString("INSERT INTO ", table, SIGN.ws, n, " VALUES ", v);
                                    insertQueryStack.push(query);
                                });
                            });
                        });
                        break;
                    }
                }
                return insertQueryStack;
            };
            const getDeleteQuery = function(table) {
                const ks = keySet[table];
                const code = concatString(SIGN.sq, uc, "%", SIGN.sq);
                const condition = concatString(ks, " LIKE ", code);
                const deleteQuery = concatString("DELETE FROM ", table, " WHERE ", condition);
                return deleteQuery;
            };
            const getSelectQuery = function(table) {
                const ks = keySet[table];
                const code = concatString(SIGN.sq, uc, "%", SIGN.sq);
                const condition = concatString(ks, " LIKE ", code);
                const selectQuery = concatString("SELECT * FROM ", table, " WHERE ", condition);
                return selectQuery;
            };
            const onTransaction = _this.transaction(transactionId);
            if(onTransaction.error) throw new Error(onTransaction.message);
            const db = onTransaction.db;
            try {
                tableList.forEach(function(table) {
                    createUserState.log.push(concatString("[[", table, "]]"));
                    switch(createUserState.actionType) {
                        case types.action.create: {
                            const insertQueryList = getInsertQuery(table);
                            insertQueryList.forEach(function(query) {
                                db.execute(query);
                                _this.pushQueryLog(createUserState.log, query);
                            });
                            break;
                        }
                        case types.action.delete: {
                            if(!resultFlag.delete) return;
                            const selectQuery = getSelectQuery(table);
                            const selectData = db.executeSelect(selectQuery).dataSet;
                            if(selectData.count <= 0) {
                                resultFlag.delete = false;
                                return;
                            }
                            const query = getDeleteQuery(table);
                            db.execute(query);
                            _this.pushQueryLog(createUserState.log, query);
                            break;
                        }
                    }
                });
                if(!resultFlag.delete) throw new Error("Not exists user");
                _this.actionControllerCreateUser(phaseType.commit);
            }
            catch(e) {
                _this.destroy(transactionId, db);
                throw new Error(e.message);
            }
            loading.off();
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    buildLincErrorResolution: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const _event = _this.event;
        const lerEvent = _event.lincErrorResolution;
        const $container = jqNode("div", { class: seClass.contentsContainer });
        const $actionArea = jqNode("div", { class: seClass.actionArea });
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        [$execButton].forEach(function(item) { $actionArea.append(item); });
        $container.append($actionArea);
        const itemList = [
            {
                label: captions.policyNumber,
                inputType: "textarea",
                inputId: seId.lincPolicyNumber
            }
        ];
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: seClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            $commandArea.append($label).append($input);
            $container.append($commandArea);
            switch(item.inputId) {
                case seId.lincPolicyNumber: {
                    lerEvent.element.pn = $input;
                    break;
                }
            }
        });
        $execButton.click(function() {
            _this.solveLincError();
        });
        return $container;
    },
    actionControllerLincErrorResolution: function(phase) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const seClass = _this.Define.ELEMENTS.class;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.lincErrorResolution;
        const transactionId = types.toolId.lincErrorResolution;
        const _event = _this.event;
        const lerEvent = _event.lincErrorResolution;
        const $card = jqById(seId.lincErrorResolutionCard);
        const $cardContents = $card.find(concatString(".", eClass.cardContents));
        const $contentsContainer = $card.find(concatString(".", seClass.contentsContainer));
        const $actionArea = $contentsContainer.children(concatString(".", seClass.actionArea));
        const $commitButton = jqNode("button", { class: eClass.buttonColorDark }).text(upperCase(captions.commit));
        const $logButton = jqNode("button", { class: eClass.buttonColorPositive }).text(upperCase(captions.log));
        const $resetButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.reset));
        const eb = new ElementBuilder();
        const propOption = eb.getPropOptionLayout();
        let itemList = new Array();
        switch(phase) {
            case phaseType.commit: {
                itemList = [$commitButton, $logButton, $resetButton];
                propOption.readonlyList = ["pn"];
                eb.setElementDisable(lerEvent.element, propOption);
                break;
            }
            case phaseType.complete: {
                itemList = [$logButton, $resetButton];
                break;
            }
        }
        $actionArea.empty();
        itemList.forEach(function(item) {
            $actionArea.append(item);
        });
        $commitButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db, true);
            _this.actionControllerLincErrorResolution(phaseType.complete);
            const message = "Linc error solved successfully";
            new Notification().complete().open(message);
        });
        $logButton.click(function() {
            _this.downloadLog(transactionId);
        });
        $resetButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.state.lincErrorResolution = new Object();
            $cardContents.html(_this.buildLincErrorResolution());
        });
        return null;
    },
    solveLincError: function() {
        const _this = this;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const _event = _this.event;
        const lerEvent = _event.lincErrorResolution;
        const phaseType = types.phase.lincErrorResolution;
        const transactionId = types.toolId.lincErrorResolution;
        const lincErrorExport = _this.export.lincErrorResolution;
        const lincErrorState = _this.state.lincErrorResolution;
        lincErrorState.log = new Array();
        const loading = new Loading();
        loading.on().then(function() {
            const lerElement = lerEvent.element;
            const policyNumber = _this.createInfoObject(lerElement.pn.val(), captions.policyNumber);
            const v = new Validation();
            const vTypes = v.getTypes();
            const policyNumberLayout = v.getLayout(v.initLayout(policyNumber.value, policyNumber.name, v.getSizeLayout(11, 11, SIGN.nl)), [vTypes.requiredWithLineBreak, vTypes.notSpace, vTypes.numericWithLineBreak, vTypes.size]);
            v.reset().append(policyNumberLayout);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            const pn = policyNumber.value;
            const pnList = getExistArray(pn.split(SIGN.nl));
            const dCheck = duplicationCheckForArray(pnList);
            if(dCheck.hasError) {
                const dMsg = [concatString("Policy Number has duplication error", SIGN.br)].concat(dCheck.data).join(SIGN.br);
                throw new Error(dMsg);
            }
            const onTransaction = _this.transaction(transactionId);
            if(onTransaction.error) throw new Error(onTransaction.message);
            const db = onTransaction.db;
            try {
                pnList.forEach(function(p) {
                    lincErrorState.log.push(concatString("-- <", p, ">"));
                    const mapping = { key: concatString(SIGN.sq, p, SIGN.sq) };
                    lincErrorExport.queryList.forEach(function(query) {
                        const bindedQuery = bindQuery(query, mapping);
                        db.execute(bindedQuery);
                        _this.pushQueryLog(lincErrorState.log, bindedQuery);
                    });
                });
                _this.actionControllerLincErrorResolution(phaseType.commit);
            }
            catch(e) {
                _this.destroy(transactionId, db);
                throw new Error(e.message);
            }
            loading.off();
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    buildExportTable: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const state = _this.state.exportTable;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: eClass.appContentsContainer });
        const $actionArea = jqNode("div", { class: eClass.actionArea });
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        $container.append(eb.listAppend($actionArea, [$execButton]));
        state.injector = new Object();
        const itemList = [
            {
                label: upperCase(captions.tables, 0),
                inputType: "textarea",
                inputId: seId.exportTableTables
            }
        ];
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: eClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            $commandArea.append($label).append($input);
            $container.append($commandArea);
            state.injector[item.inputId] = $input;
        });
        $execButton.click(function() {
            _this.exportTable();
        });
        return $container;
    },
    exportTable: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const state = _this.state.importTable;
        const sb = new StringBuilder();
        const status = {
            db: null
        };
        const loading = new Loading();
        loading.on().then(function() {
            const tables = _this.createInfoObject(jqById(seId.exportTableTables).val(), upperCase(captions.tables, 0));
            const v = new Validation();
            const vTypes = v.getTypes();
            const tablesLayout = v.getLayout(v.initLayout(tables.value, tables.name), [vTypes.requiredWithLineBreak]);
            v.reset().appendList([tablesLayout]);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            status.db = new DBUtils().connect(_this.state.info);
            const dataObject = new Object();
            const tableList = getExistArray(tables.value.split(SIGN.nl));
            tableList.forEach(function(item, i, a) {
                let table, query = null;
                const queryRegExp = new RegExp("^SELECT(.*)FROM ");
                if(queryRegExp.test(item)) {
                    table = item.replace(queryRegExp, SIGN.none).split(SIGN.ws)[0];
                    query = item;
                }
                else {
                    table = item;
                    query = concatString("SELECT * FROM ", table);
                }
                const idx = i + 1;
                const dataSet = status.db.executeSelect(query).onEnd(a.length === idx).dataSet;
                dataObject[table] = dataSet;
            });
            const parts = JSON.stringify(dataObject);
            const extension = TYPES.file.extension.txt;
            const fileName = concatString(getFileStamp("ExportTable"), extension);
            const mime = TYPES.file.mime.TEXT_UTF8;
            saveAsFile(parts, mime, fileName);
            loading.off();
        }).catch(function(e) {
            if(!isVoid(status.db)) {
                status.db.close();
                status.db = null;
            }
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    actionControllerImportTable: function(phase) {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.importTable;
        const transactionId = types.toolId.importTable;
        const state = _this.state.importTable;
        const $card = jqById(seId.importTableCard);
        const $cardContents = $card.find(concatString(".", eClass.cardContents));
        const $contentsContainer = $card.find(concatString(".", eClass.appContentsContainer));
        const $actionArea = $contentsContainer.children(concatString(".", eClass.actionArea));
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        const $logButton = jqNode("button", { class: eClass.buttonColorPositive }).text(upperCase(captions.log));
        const $commitButton = jqNode("button", { class: eClass.buttonColorDark }).text(upperCase(captions.commit));
        const $rollbackButton = jqNode("button", { class: eClass.buttonColorDark }).text(upperCase(captions.rollback));
        const $resetButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.reset));
        const eb = new ElementBuilder();
        const propOption = eb.getPropOptionLayout();
        let itemList = new Array();
        switch(phase) {
            case phaseType.import: {
                itemList = [$execButton, $resetButton];
                break;
            }
            case phaseType.commit: {
                itemList = [$commitButton, $rollbackButton, $logButton, $resetButton];
                break;
            }
            case phaseType.complete: {
                itemList = [$logButton, $resetButton];
                propOption.readonlyList = [seId.importTableTables];
                eb.setElementDisable(state.injector, propOption);
                break;
            }
        }
        $actionArea.empty();
        itemList.forEach(function(item) {
            $actionArea.append(item);
        });
        $execButton.click(function() {
            _this.importTable();
        });
        $logButton.click(function() {
            _this.downloadLog(transactionId);
        });
        $commitButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db, true);
            _this.actionControllerImportTable(phaseType.complete);
            new Notification().complete().open("Table imported successfully");
        });
        $rollbackButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.actionControllerImportTable(phaseType.import);
        });
        $resetButton.click(function() {
            const db = _this.state.lock[transactionId];
            _this.destroy(transactionId, db);
            _this.state.importTable = new Object();
            $cardContents.html(_this.buildImportTable());
        });
        return null;
    },
    buildImportTable: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const state = _this.state.importTable;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: eClass.appContentsContainer });
        const $actionArea = jqNode("div", { class: eClass.actionArea });
        const $readButton = jqNode("button", { class: eClass.buttonColorOrange }).text(upperCase(captions.read));
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        $container.append(eb.listAppend($actionArea, [$readButton]));
        state.injector = new Object();
        const itemList = [
            {
                label: upperCase(captions.tables, 0),
                inputType: "textarea",
                inputId: seId.importTableTables
            }
        ];
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: eClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            $commandArea.append($label).append($input);
            $container.append($commandArea);
            state.injector[item.inputId] = $input;
        });
        $readButton.click(function() {
            _this.readTableFile();
        });
        $execButton.click(function() {
            _this.importTable();
        });
        return $container;
    },
    readTableFile: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.importTable;
        const state = _this.state.importTable;
        const onReadFile = function(data, path, fileInfo) {
            const loading = new Loading();
            loading.on().then(function() {
                const encodedData = new Encoder(data).SJISArrayBufferToString();
                const dataObj = JSON.parse(encodedData);
                state.data = dataObj;
                state.tableList = Object.keys(state.data).map(function(key) { return key; });
                state.injector[seId.importTableTables].val(state.tableList.join(SIGN.nl));
                _this.actionControllerImportTable(phaseType.import);
                loading.off();
            }).catch(function(e) {
                new Notification().error().open(e.message);
                loading.off();
            });
        };
        new FileController()
        .setListener()
        .setReadType(TYPES.file.readType.arrayBuffer)
        .allowedExtensions([TYPES.file.mime.TEXT])
        .access(onReadFile);
        return null;
    },
    importTable: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const types = _this.Define.TYPES;
        const phaseType = types.phase.importTable;
        const transactionId = types.toolId.importTable;
        const state = _this.state.importTable;
        const dbTypes = new DBUtils().getTypes();
        const sb = new StringBuilder();
        const loading = new Loading();
        loading.on().then(function() {
            const tables = _this.createInfoObject(jqById(seId.importTableTables).val(), upperCase(captions.tables, 0));
            const v = new Validation();
            const vTypes = v.getTypes();
            const tablesLayout = v.getLayout(v.initLayout(tables.value, tables.name), [vTypes.requiredWithLineBreak, vTypes.notSpace]);
            v.reset().appendList([tablesLayout]);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            state.log = new Array();
            const getQuery = function(table, name, record) {
                const columns = concatString(SIGN.bs, name.join(SIGN.cw), SIGN.be);
                const valuesMap = record.map(function(item) {
                    const v = item || item == 0 ? item : "";
                    return sb.sq(v);
                }).join(SIGN.cw);
                const values = concatString(SIGN.bs, valuesMap, SIGN.be);
                return sb.setQuery(["INSERT INTO", table, columns, "VALUES", values]);
            };
            const tableList = getExistArray(tables.value.split(SIGN.nl));
            const dataObj = state.data;
            const onTransaction = _this.transaction(transactionId);
            if(onTransaction.error) throw new Error(onTransaction.message);
            const db = onTransaction.db;
            try {
                tableList.forEach(function(table) {
                    state.log.push(concatString("-- <", table, ">"));
                    state.executeTable = table;
                    const tableData = getProperty(dataObj, table);
                    tableData.data.forEach(function(record) {
                        const query = getQuery(table, tableData.name, record);
                        _this.pushQueryLog(state.log, query);
                        db.execute(query);
                    });
                });
                loading.off();
                _this.actionControllerImportTable(phaseType.commit);
            }
            catch(e) {
                const errorType = dbTypes.error;
                let message = e.message;
                if(message.indexOf(errorType.uniqueConstraint) >= 0) {
                    message = concatString(SIGN.abs, state.executeTable, SIGN.abe, SIGN.br, message);
                }
                _this.destroy(transactionId, db);
                throw new Error(message);
            }
        }).catch(function(e) {
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    },
    buildQueryTest: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const state = _this.state.getFileDescription;
        const eb = new ElementBuilder();
        const $container = jqNode("div", { class: eClass.appContentsContainer });
        const $actionArea = jqNode("div", { class: eClass.actionArea });
        const $execButton = jqNode("button", { class: eClass.buttonColorBalanced }).text(upperCase(captions.exec));
        const $clearButton = jqNode("button", { class: eClass.buttonColorAssertive }).text(upperCase(captions.clear));
        $container.append(eb.listAppend($actionArea, [$execButton, $clearButton]));
        const itemList = [
            {
                label: captions.queryTest.variableQueryLabel,
                inputType: "textarea",
                inputId: seId.queryTest.variableQuery
            },
            {
                label: captions.queryTest.execQueryLabel,
                inputType: "textarea",
                inputId: seId.queryTest.execQuery
            },
            {
                label: captions.queryTest.resultLabel,
                inputType: "textarea",
                inputId: seId.queryTest.result
            }
        ];
        const elementStack = new Array();
        itemList.forEach(function(item) {
            const $commandArea = jqNode("div", { class: eClass.commandArea });
            const $label = jqNode("label").text(item.label);
            const $input = jqNode(item.inputType, { id: item.inputId });
            eb.listAppend($commandArea, [$label, $input]);
            $container.append($commandArea);
            elementStack.push($input);
        });
        $execButton.click(function() { _this.execQueryTest(); });
        $clearButton.click(function() {
            elementStack.forEach(function(item) { item.val(SIGN.none); });
        });
        return $container;
    },
    execQueryTest: function() {
        const _this = this;
        const seId = _this.Define.ELEMENTS.id;
        const captions = _this.Define.CAPTIONS;
        const state = _this.state.queryTest;
        const loading = new Loading();
        const status = {
            db: null
        };
        loading.on().then(function() {
            const variableQuery = _this.createInfoObject(jqById(seId.queryTest.variableQuery).val(), captions.queryTest.variableQueryLabel);
            const execQuery = _this.createInfoObject(jqById(seId.queryTest.execQuery).val(), captions.queryTest.execQueryLabel);
            const v = new Validation();
            const vTypes = v.getTypes();
            const variableQueryLayout = v.getLayout(v.initLayout(variableQuery.value, variableQuery.name), [vTypes.requiredWithLineBreak]);
            const execQueryLayout = v.getLayout(v.initLayout(execQuery.value, execQuery.name), [vTypes.requiredWithLineBreak]);
            v.reset().appendList([variableQueryLayout, execQueryLayout]);
            const result = v.exec();
            if(result.error) {
                throw new Error(result.message);
            }
            const vq = variableQuery.value;
            const eq = execQuery.value;
            const binder = new Binder(eq);
            const resultStack = new Array();
            status.db = new DBUtils().connect(_this.state.info);
            const vqDataSet = status.db.executeSelect(vq).dataSet;
            if(vqDataSet.count >= 1) {
                vqDataSet.data.forEach(function(row, j) {
                    binder.setVariables(vqDataSet.name, row);
                    const header = concatString("■Index:", j + 1, ", Variables:", JSON.stringify(binder.variables));
                    const cq = binder.convertSameCase();
                    const cqDataSet = status.db.executeSelect(cq).dataSet;
                    if(cqDataSet.count >= 1) {
                        resultStack.push(header);
                        resultStack.push(cqDataSet.name.join(SIGN.es));
                        cqDataSet.data.forEach(function(cRow) {
                            resultStack.push(cRow.join(SIGN.es));
                        });
                        resultStack.push(SIGN.nl);
                    }
                });
                status.db.close();
                const $result = jqById(seId.queryTest.result);
                $result.val(resultStack.join(SIGN.nl));
            }
            else {
                throw new Error("Nothing variable query's result set");
            }
            loading.off();
        }).catch(function(e) {
            if(!isVoid(status.db)) {
                status.db.close();
            }
            new Notification().error().open(e.message);
            loading.off();
        });
        return null;
    }
};

const DBUtils = function() {
    this.Define = {
        ADODB: {
            connection: "ADODB.Connection",
            recordset: "ADODB.Recordset",
            command: "ADODB.Command"
        },
        OLEDB: {
            provider: "Provider=OraOLEDB.Oracle;",
            dataSource: "Data Source=",
            uid: "User ID=",
            pwd: "Password="
        },
        DIRECT: {
            provider: "Provider=OraOLEDB.Oracle;",
            cid: "CID=GTU_APP",
            protocol: "PROTOCOL=",
            host: "HOST=",
            port: "PORT=",
            sid: "SID=",
            server: "SERVER=",
            uid: "User Id=",
            pwd: "Password="
        },
        DEFAULT_SET: {
            protocol: "TCP",
            host: "192.168.40.206",
            port: "1521",
            server: "DEDICATED"
        },
        TYPES: {
            connect: {
                oledb: "oledb",
                direct: "direct"
            },
            actionType: {
                query: "q",
                noneQuery: "nq"
            },
            command: {
                adCmdUnspecified: -1,
                adCmdText: 1,
                adCmdTable: 2,
                adCmdStoredProc: 4,
                adCmdFile: 256,
                adCmdTableDirect: 512,
                adVarWChar: 202,
                adParamInput: 1,
            },
            error: {
                uniqueConstraint: "ORA-00001"
            }
        }
    };
    this.driver = null;
    this.command = null;
    this.type = null;
    this.dataSet = null;
};
DBUtils.prototype = {
    getTypes: function() {
        return this.Define.TYPES;
    },
    createConnectString: function(sid, uid, pwd, type) {
        const OLEDB = this.Define.OLEDB;
        const DIRECT = this.Define.DIRECT;
        const DEFAULT_SET = this.Define.DEFAULT_SET;
        const types = this.Define.TYPES;
        const connectType = types.connect;
        const paramType = type ? type : connectType.oledb;
        const getConnectString = function(name, value) {
            return name + value + SIGN.sc;
        };
        const getDataSourceString = function(name, value) {
            return SIGN.bs + name + value + SIGN.be;
        };
        let str = "";
        switch(paramType) {
            case connectType.oledb: {
                str += OLEDB.provider;
                str += getConnectString(OLEDB.dataSource, sid);
                str += getConnectString(OLEDB.uid, uid);
                str += getConnectString(OLEDB.pwd, pwd);
                break;
            }
            case connectType.direct: {
                str += DIRECT.provider;
                str += "Data Source=(";
                str +=  "DESCRIPTION=";
                str +=   "(CID=GTU_APP)";
                str +=   "(ADDRESS_LIST=(ADDRESS="
                str +=    getDataSourceString(DIRECT.protocol, DEFAULT_SET.protocol);
                str +=    getDataSourceString(DIRECT.host, DEFAULT_SET.host);
                str +=    getDataSourceString(DIRECT.port, DEFAULT_SET.port);
                str +=   "))"
                str +=   "(CONNECT_DATA=";
                str +=    getDataSourceString(DIRECT.sid, sid);
                str +=    getDataSourceString(DIRECT.server, DEFAULT_SET.server);
                str +=   ")";
                str += ");";
                str += getConnectString(DIRECT.uid, uid);
                str += getConnectString(DIRECT.pwd, pwd);
                break;
            }
        }
        return str;
    },
    connect: function(info) {
        // const ADODB = this.Define.ADODB;
        // const types = this.Define.TYPES;
        // const connectString = this.createConnectString(info.sid.value, info.uid.value, info.pwd.value);
        // this.driver = new ActiveXObject(ADODB.connection);
        // this.driver.Open(connectString);
        // this.type = types.actionType.query;
        const oracle = appState.oracle;
        oracle.connection(info);
        return this;
    },
    connectBegin: function(info) {
        const types = this.Define.TYPES;
        this.connect(info);
        this.type = types.actionType.noneQuery;
        this.driver.BeginTrans();
        return this;
    },
    initCommand: function(query) {
        const ADODB = this.Define.ADODB;
        const types = this.Define.TYPES;
        const commandType = types.command;
        const command = new ActiveXObject(ADODB.command);
        command.ActiveConnection = this.driver;
        command.CommandType = commandType.adCmdText;
        command.Prepared = true;
        command.CommandText = query;
        this.command = command;
        return command;
    },
    execute: function(query) {
        const command = this.initCommand(query);
        command.Execute();
        this.dataSet = null;
        return null;
    },
    executeSelect: function(query) {
        const command = this.initCommand(query);
        const recordSet = command.Execute();
        this.dataSet = this.getData(recordSet);
        return this;
    },
    executeSelectGrid: function(query) {
        const command = this.initCommand(query);
        const recordSet = command.Execute();
        this.dataSet = this.getGridData(recordSet);
        return this;
    },
    getData: function(rs) {
        const dataSet = {
            error: true,
            count: 0,
            name: new Array(),
            data: new Array()
        };
        for(let i = 0; i < rs.Fields.Count; i++) {
            dataSet.name.push(rs.Fields(i).Name);
        }
        while(!rs.EOF && dataSet.count <= 1000000) {
            const valueStack = new Array();
            for(let i = 0; i < rs.Fields.Count; i++) {
                const v = !isVoid(rs.Fields(i).Value) ? rs.Fields(i).Value : SIGN.none;
                valueStack.push(v);
            }
            dataSet.data.push(valueStack);
            dataSet.count += 1;
            rs.MoveNext();
        }
        rs.Close();
        dataSet.error = false;
        return dataSet;
    },
    getGridData: function(rs) {
        const dataSet = {
            error: true,
            count: 0,
            name: new Array(),
            data: new Array()
        };
        for(let i = 0; i < rs.Fields.Count; i++) {
            const columnName = rs.Fields(i).Name;
            const field = columnName.replace(new RegExp(SIGN.ws, "g"), SIGN.none);
            const obj = {
                field: field,
                caption: columnName,
                sortable: true
            };
            dataSet.name.push(obj);
        }
        while(!rs.EOF && dataSet.count <= 1000000) {
            const valueObj = new Object();
            valueObj.recid = dataSet.count + 1;
            for(let i = 0; i < rs.Fields.Count; i++) {
                const v = !isVoid(rs.Fields(i).Value) ? rs.Fields(i).Value : SIGN.none;
                valueObj[dataSet.name[i].field] = v;
            }
            dataSet.data.push(valueObj);
            dataSet.count += 1;
            rs.MoveNext();
        }
        rs.Close();
        dataSet.error = false;
        return dataSet;
    },
    commit: function() {
        this.driver.CommitTrans();
        this.close();
        return this;
    },
    rollback: function() {
        this.driver.RollbackTrans();
        this.close();
        return this;
    },
    cancel: function() {
        this.command.Cancel();
        this.close();
        return this;
    },
    close: function() {
        // this.driver.Close();
        // this.driver = null;
        // this.command = null;
        // this.type = null;
        const oracle = appState.oracle;
        oracle.close();
        return null;
    },
    onEnd: function(condition, callback, bindParam) {
        if(condition) {
            if(!callback) {
                this.close();
            }
            else {
                callback(bindParam);
            }
        }
        return this;
    },
    setParameter: function() {
        const _this = this;
        const types = _this.Define.TYPES;
        const commandType = types.command;
        const command = _this.command;
        const argumentsList = Array.prototype.slice.call(arguments);
        command.Parameters.Refresh();
        argumentsList.forEach(function(item, i) {
            command.Parameters.Append(command.CreateParameter("?", commandType.adVarWChar, commandType.adParamInput, 100, item));
        });
        return this;
    },
    getColumnData: function(data, table, column) {
        const prop = getProperty(data, table);
        const tableData = prop ? prop : data;
        if(!tableData) return null;
        const index = compareIndexOf(tableData.name, column);
        return tableData.data[0][index];
    },
    convertToObject: function(name, data) {
        const dataObject = {
            count: data.length,
            ref: new Object()
        };
        name.forEach(function(n, i) {
            dataObject.ref[n] = data.map(function(item) {
                return item[i];
            });
        });
        return dataObject;
    },
    where: function(o, table, expression) {
        const prop = getProperty(o, table);
        if(!prop) return null;
        const name = prop.name;
        const data = prop.data;
        const getIndex = function(column) {
            return compareIndexOf(name, column);
        };
        const getDataList = function(func) {
            return data.filter(function(record) {
                return func(record);
            });
        };
        return this.convertToObject(name, typeIs(expression).function ? expression(getIndex, getDataList) : this.expressionLayout(getIndex, getDataList));
    },
    getDataByColumn: function(dataSet, column) {
        const index = compareIndexOf(dataSet.name, column);
        const data = dataSet.data.map(function(record) {
            return record[index];
        });
        return data;
    },
    getDataByIndex: function(dataSet, index) {
        const data = dataSet.data.map(function(record) {
            return record[index];
        });
        return data;
    },
    expressionLayout: function(getIndex, getDataList) {
        const con = function(record) {
            return true;
        };
        return getDataList(con);
    }
};
